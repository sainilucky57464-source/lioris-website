import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics, isSupported } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyCWRHdFe2eWERga6QG6sehG8B-WJXEM7-s",
  authDomain: "luxora-store-58762.firebaseapp.com",
  projectId: "luxora-store-58762",
  storageBucket: "luxora-store-58762.firebasestorage.app",
  messagingSenderId: "357730641920",
  appId: "1:357730641920:web:6b43af5bd9953e537e50e5",
  measurementId: "G-5C0EXV6FGT"
};

let app = null;
let db = null;
let storage = null;

try {
  app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  storage = getStorage(app);
} catch (error) {
  console.error("Firebase connection issue / initialization failed:", error);
}

export { app, db, storage };

export const initAnalytics = async () => {
  try {
    if (app && await isSupported()) {
      return getAnalytics(app);
    }
    return null;
  } catch (error) {
    console.warn("Analytics not supported:", error);
    return null;
  }
};

export default app;
