import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("LIORIS ErrorBoundary caught an uncaught crash:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-[#FDFBF7] text-[#111111] px-4 py-12 text-center font-sans">
          <div className="max-w-md w-full p-8 bg-white border border-gray-100 rounded-2xl shadow-lg space-y-6">
            <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div className="space-y-2">
              <h1 className="text-xl font-serif font-extrabold tracking-widest uppercase">LIORIS failed to load.</h1>
              <p className="text-sm text-[#caa85a] font-bold">Please refresh.</p>
            </div>
            {this.state.error && (
              <pre className="text-left bg-gray-50 p-4 rounded-xl text-xs font-mono text-red-600 overflow-auto max-h-40">
                {this.state.error.toString()}
              </pre>
            )}
            <button 
              onClick={() => window.location.reload()}
              className="w-full bg-[#111111] text-white py-3 rounded-xl text-sm font-bold tracking-widest uppercase hover:bg-black transition-all"
            >
              Refresh
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);
