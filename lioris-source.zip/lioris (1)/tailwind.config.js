/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        lioris: {
          black: "#1A1A1A",
          white: "#FFFFFF",
          lightGrey: "#FCFCFC",
          mediumGrey: "#F0F0F0",
          darkGrey: "#666666",
          gold: "#C5A059",
          goldLight: "#F5EFE4",
          goldDark: "#C5A059",
          green: "#2E7D32",
          star: "#FFB300",
          error: "#B00020"
        }
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        serif: ["Playfair Display", "serif"]
      }
    },
  },
  plugins: [],
}
