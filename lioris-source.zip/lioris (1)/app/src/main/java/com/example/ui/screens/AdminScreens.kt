package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.LiorisViewModel
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// --- HELPER METRIC CARD ---
@Composable
fun AdminMetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color = LiorisGoldDark) {
    Card(
        modifier = Modifier.width(150.dp),
        colors = CardDefaults.cardColors(containerColor = LiorisWhite),
        shape = RoundedCornerShape(2.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
            Text(text = title.uppercase(), fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}

// ==========================================
// 1. ADMIN DASHBOARD SCREEN
// ==========================================
@Composable
fun AdminDashboardScreen(viewModel: LiorisViewModel) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val banners by viewModel.activeBanners.collectAsStateWithLifecycle()

    val context = LocalContext.current

    // Compute basic statistics
    val totalSales = orders.filter { it.status != "Cancelled" }.sumOf { it.finalPayable }
    val totalOrders = orders.size
    val pendingOrders = orders.count { it.status == "Pending" }
    val lowStockCount = products.count { it.stock <= 3 }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LIORIS CONTROL CENTER",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Live boutique status & database dashboard.",
                    fontSize = 11.sp,
                    color = LiorisDarkGrey
                )
            }

            OutlinedButton(
                onClick = {
                    viewModel.reloadApp()
                    Toast.makeText(context, "Database, settings & cache reloaded safely!", Toast.LENGTH_SHORT).show()
                },
                border = BorderStroke(1.dp, LiorisGoldDark),
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = LiorisBlack),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Sync",
                    tint = LiorisGoldDark,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "RELOAD",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Metrics Horizontal Scroller
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            item { AdminMetricCard("Total Revenue", "₹${totalSales.toInt()}", Icons.Filled.CurrencyRupee) }
            item { AdminMetricCard("Total Orders", "$totalOrders", Icons.Filled.LocalShipping) }
            item { AdminMetricCard("Pending Task", "$pendingOrders", Icons.Filled.PendingActions, LiorisWarning) }
            item { AdminMetricCard("Low Stock", "$lowStockCount Items", Icons.Filled.Warehouse, LiorisError) }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Navigation controls grid
        Text(text = "MANAGEMENT WORKSPACES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(8.dp))

        val workspaceButtons = listOf(
            Triple("Products", Screen.AdminProducts, Icons.Filled.Inventory),
            Triple("Orders", Screen.AdminOrders, Icons.Filled.Receipt),
            Triple("Customers", Screen.AdminCustomers, Icons.Filled.People),
            Triple("Banners", Screen.AdminBanners, Icons.Filled.ViewCarousel),
            Triple("Coupons", Screen.AdminCoupons, Icons.Filled.LocalOffer),
            Triple("Free Gifts", Screen.AdminGifts, Icons.Filled.CardGiftcard),
            Triple("Users Wallet", Screen.AdminWallet, Icons.Filled.Wallet),
            Triple("Broadcast", Screen.AdminNotifications, Icons.Filled.Campaign),
            Triple("Store Config", Screen.AdminSettings, Icons.Filled.Settings)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            workspaceButtons.chunked(2).forEach { rowItems ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { (title, screen, icon) ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .clickable { viewModel.navigateTo(screen) },
                            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = icon, contentDescription = title, tint = LiorisBlack)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(text = title.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Recent Orders list
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "RECENT INCOMING ORDERS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
            Text(
                text = "SEE ALL",
                fontSize = 10.sp,
                color = LiorisGoldDark,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { viewModel.navigateTo(Screen.AdminOrders) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (orders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LiorisWhite)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No orders received yet.", fontSize = 11.sp, color = Color.Gray)
            }
        } else {
            orders.take(4).forEach { ord ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { viewModel.navigateTo(Screen.TrackOrder(ord.orderId)) },
                    colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Order: ${ord.orderId}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Payable: ₹${ord.finalPayable.toInt()} | ${ord.paymentMethod}", fontSize = 11.sp, color = Color.Gray)
                        }
                        Box(
                            modifier = Modifier
                                .background(LiorisGoldLight, RoundedCornerShape(2.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = ord.status.uppercase(), fontSize = 8.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 2. ADMIN PRODUCTS SCREEN
// ==========================================
@Composable
fun AdminProductsScreen(viewModel: LiorisViewModel) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showForm by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }

    // Form states
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var mrp by remember { mutableStateOf("") }
    var images by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var highlights by remember { mutableStateOf("") }
    var sizes by remember { mutableStateOf("") }
    var colors by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var trending by remember { mutableStateOf(false) }
    var newArrival by remember { mutableStateOf(false) }
    var bestSeller by remember { mutableStateOf(false) }
    var giftEligible by remember { mutableStateOf(false) }

    // Autofill when editing
    LaunchedEffect(editingProduct) {
        editingProduct?.let { p ->
            name = p.name
            category = p.category
            price = p.price.toString()
            mrp = p.mrp.toString()
            images = p.images
            description = p.description
            highlights = p.highlights
            sizes = p.sizes
            colors = p.colors
            stock = p.stock.toString()
            trending = p.trending
            newArrival = p.newArrival
            bestSeller = p.bestSeller
            giftEligible = p.giftEligible
        } ?: run {
            // Reset
            name = ""
            category = ""
            price = ""
            mrp = ""
            images = ""
            description = ""
            highlights = ""
            sizes = ""
            colors = ""
            stock = ""
            trending = false
            newArrival = false
            bestSeller = false
            giftEligible = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "MANAGE PRODUCTS", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = {
                    editingProduct = null
                    showForm = !showForm
                },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
            ) {
                Text(if (showForm) "CLOSE FORM" else "ADD PRODUCT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (showForm) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (editingProduct != null) "EDITING PRODUCT" else "NEW PRODUCT SPECIFICATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisGoldDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name *") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category (Clothing / Metal Items / Home) *") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Price *") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = mrp, onValueChange = { mrp = it }, label = { Text("MRP *") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = images, onValueChange = { images = it }, label = { Text("Image URLs (comma-separated) *") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description *") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = highlights, onValueChange = { highlights = it }, label = { Text("Bullet Highlights (comma-separated)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = sizes, onValueChange = { sizes = it }, label = { Text("Sizes (S,M,L)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = colors, onValueChange = { colors = it }, label = { Text("Colors (Gold,Slate)") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stock Quantity *") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(12.dp))

                    // Flags Checkboxes
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = trending, onCheckedChange = { trending = it })
                        Text("Trending Highlight", fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(16.dp))
                        Checkbox(checked = newArrival, onCheckedChange = { newArrival = it })
                        Text("New Arrival", fontSize = 12.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = bestSeller, onCheckedChange = { bestSeller = it })
                        Text("Best Seller", fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(16.dp))
                        Checkbox(checked = giftEligible, onCheckedChange = { giftEligible = it })
                        Text("Eligible as Free Gift", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Save Product Button
                    Button(
                        onClick = {
                            if (name.isEmpty() || category.isEmpty() || price.isEmpty() || mrp.isEmpty() || images.isEmpty() || description.isEmpty() || stock.isEmpty()) {
                                Toast.makeText(context, "Fill all required * fields!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val pVal = price.toDoubleOrNull() ?: 0.0
                            val mVal = mrp.toDoubleOrNull() ?: 0.0
                            val sVal = stock.toIntOrNull() ?: 0

                            val discVal = if (mVal > 0) ((mVal - pVal) / mVal) * 100 else 0.0

                            val prodToSave = Product(
                                id = editingProduct?.id ?: UUID.randomUUID().toString(),
                                name = name,
                                category = category,
                                price = pVal,
                                mrp = mVal,
                                discount = discVal,
                                images = images,
                                description = description,
                                highlights = highlights,
                                sizes = sizes,
                                colors = colors,
                                rating = editingProduct?.rating ?: 4.8,
                                reviewCount = editingProduct?.reviewCount ?: 24,
                                stock = sVal,
                                trending = trending,
                                newArrival = newArrival,
                                bestSeller = bestSeller,
                                giftEligible = giftEligible,
                                active = true
                            )

                            if (editingProduct != null) {
                                viewModel.adminEditProduct(prodToSave)
                            } else {
                                viewModel.adminAddProduct(prodToSave)
                            }

                            Toast.makeText(context, "Product saved successfully!", Toast.LENGTH_SHORT).show()
                            showForm = false
                            editingProduct = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                    ) {
                        Text("SAVE PRODUCT SPEC", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Render current products list
        products.forEach { prod ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = prod.images.split(",").firstOrNull(),
                        contentDescription = prod.name,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(prod.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("₹${prod.price.toInt()} | Stock: ${prod.stock} | Cat: ${prod.category}", fontSize = 11.sp, color = Color.Gray)
                    }

                    // Edit & Delete actions
                    IconButton(onClick = {
                        editingProduct = prod
                        showForm = true
                    }) {
                        Icon(imageVector = Icons.Filled.Edit, contentDescription = "Edit", tint = LiorisGoldDark)
                    }

                    IconButton(onClick = {
                        viewModel.adminDeleteProduct(prod.id)
                        Toast.makeText(context, "Product deleted", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete", tint = LiorisError)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 3. ADMIN ORDERS SCREEN & SHIPPING LABELS
// ==========================================
@Composable
fun AdminOrdersScreen(viewModel: LiorisViewModel) {
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedOrderForStatus by remember { mutableStateOf<Order?>(null) }
    var selectedOrderForLabel by remember { mutableStateOf<Order?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "INCOMING ORDERS BANK", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        if (orders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LiorisWhite)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No orders have been placed yet.", fontSize = 12.sp, color = Color.Gray)
            }
        } else {
            orders.forEach { ord ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ID: ${ord.orderId}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(ord.status.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Customer: ${ord.customerName} (+91 ${ord.phone})", fontSize = 11.sp, color = LiorisDarkGrey)
                        Text("Shipping: ${ord.address}, ${ord.city}, ${ord.state} - ${ord.pincode}", fontSize = 11.sp, color = Color.Gray)
                        Text("Payment: ${ord.paymentMethod} | Status: ${ord.paymentStatus} | Payable: ₹${ord.finalPayable.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (ord.advancePaid > 0.0) {
                            Text("COD Advance: ₹${ord.advancePaid.toInt()} | UTR: ${ord.advanceUtr}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = LiorisGoldDark)
                        }
                        if (ord.returnReason.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("⚠️ RETURN REQUEST: ${ord.returnReason}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisError)
                        }

                        Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Button(
                                onClick = { selectedOrderForStatus = ord },
                                modifier = Modifier.height(32.dp),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                                contentPadding = PaddingValues(horizontal = 10.dp)
                            ) {
                                Text("UPDATE STATUS", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { selectedOrderForLabel = ord },
                                modifier = Modifier.height(32.dp),
                                shape = RoundedCornerShape(2.dp),
                                border = BorderStroke(1.dp, LiorisBlack),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = LiorisBlack),
                                contentPadding = PaddingValues(horizontal = 10.dp)
                            ) {
                                Text("SHIPPING LABEL", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 1. Status selector dialog
        selectedOrderForStatus?.let { ord ->
            AlertDialog(
                onDismissRequest = { selectedOrderForStatus = null },
                title = { Text("Update Order Status", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                text = {
                    val statuses = listOf("Pending", "Accepted", "Packed", "Shipped", "Out for Delivery", "Delivered", "Return Requested", "Returned", "Cancelled")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        statuses.forEach { st ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LiorisLightGrey)
                                    .clickable {
                                        viewModel.adminUpdateOrderStatus(ord.orderId, st)
                                        Toast.makeText(context, "Status updated to $st!", Toast.LENGTH_SHORT).show()
                                        selectedOrderForStatus = null
                                    }
                                    .padding(12.dp)
                            ) {
                                Text(st, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // 2. Shipping Label Preview Box dialog
        selectedOrderForLabel?.let { ord ->
            AlertDialog(
                onDismissRequest = { selectedOrderForLabel = null },
                title = { Text("LIORIS SHIPPING LABEL", fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
                text = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, Color.Black)
                            .background(Color.White)
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("LIORIS LOGISTICS", fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                                Text("COD: ${if (ord.paymentMethod == "COD") "₹" + ord.finalPayable.toInt().toString() else "PREPAID"}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Divider(color = Color.Black, modifier = Modifier.padding(vertical = 8.dp))

                            Text("SHIP TO CUSTOMER:", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(ord.customerName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("+91 ${ord.phone}", fontSize = 11.sp)
                            Text("${ord.address}\n${ord.city}, ${ord.state}\nPIN: ${ord.pincode}", fontSize = 11.sp, color = Color.DarkGray)

                            Divider(color = Color.Black, modifier = Modifier.padding(vertical = 8.dp))

                            Text("SENDER: LIORIS JEWELRY & FASHION", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("7252083788 | support@lioris.in", fontSize = 10.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedOrderForLabel = null }) {
                        Text("CLOSE", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 4. ADMIN BANNERS SCREEN
// ==========================================
@Composable
fun AdminBannersScreen(viewModel: LiorisViewModel) {
    val banners by viewModel.activeBanners.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var title by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "HOME HERO BANNERS", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        // Add Banner Form Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ADD NEW HERO SLIDER BANNER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Banner Title *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("Banner Subtitle") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = image, onValueChange = { image = it }, label = { Text("Image URL *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (title.isEmpty() || image.isEmpty()) {
                            Toast.makeText(context, "Fill all required * fields!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val newBanner = Banner(
                            bannerId = UUID.randomUUID().toString(),
                            title = title,
                            subtitle = subtitle,
                            image = image,
                            link = "",
                            active = true
                        )
                        viewModel.adminAddBanner(newBanner)
                        Toast.makeText(context, "Banner saved successfully!", Toast.LENGTH_SHORT).show()
                        title = ""
                        subtitle = ""
                        image = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                ) {
                    Text("PUBLISH HOME BANNER", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Existing Banners List
        Text(text = "CURRENT ACTIVE HERO BANNERS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        banners.forEach { ban ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = ban.image,
                        contentDescription = ban.title,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ban.title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(ban.subtitle, fontSize = 10.sp, color = Color.Gray)
                    }
                    IconButton(onClick = {
                        viewModel.adminDeleteBanner(ban.bannerId)
                        Toast.makeText(context, "Banner deleted!", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete", tint = LiorisError)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 5. ADMIN COUPONS SCREEN
// ==========================================
@Composable
fun AdminCouponsScreen(viewModel: LiorisViewModel) {
    val coupons by viewModel.coupons.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var code by remember { mutableStateOf("") }
    var discType by remember { mutableStateOf("FLAT") }
    var value by remember { mutableStateOf("") }
    var minOrder by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "PROMOTIONAL DISCOUNTS & COUPONS", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        // Add Coupon Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("CREATE NEW PROMO CODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, label = { Text("Coupon Code (WELCOMENEW) *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Type selector
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { discType = "FLAT" }) {
                        RadioButton(selected = discType == "FLAT", onClick = { discType = "FLAT" })
                        Text("FLAT (₹)", fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { discType = "PERCENT" }) {
                        RadioButton(selected = discType == "PERCENT", onClick = { discType = "PERCENT" })
                        Text("PERCENT (%)", fontSize = 12.sp)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text("Discount Value (e.g., 50 or 15) *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = minOrder, onValueChange = { minOrder = it }, label = { Text("Minimum Cart Subtotal Value *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (code.isEmpty() || value.isEmpty() || minOrder.isEmpty()) {
                            Toast.makeText(context, "Fill all required * fields!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val newCoupon = Coupon(
                            code = code,
                            type = discType,
                            value = value.toDoubleOrNull() ?: 0.0,
                            minOrder = minOrder.toDoubleOrNull() ?: 0.0,
                            maxDiscount = 1000.0,
                            usageLimit = 100,
                            usedCount = 0,
                            active = true,
                            expiryDate = 0L,
                            createdAt = System.currentTimeMillis()
                        )
                        viewModel.adminAddCoupon(newCoupon)
                        Toast.makeText(context, "Coupon created!", Toast.LENGTH_SHORT).show()
                        code = ""
                        value = ""
                        minOrder = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                ) {
                    Text("ACTIVATE PROMO CODE", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Existing coupons
        Text(text = "EXISTING PROMO CODES", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        coupons.forEach { coup ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("CODE: ${coup.code}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Value: ${if (coup.type == "FLAT") "₹" else ""}${coup.value.toInt()}${if (coup.type == "PERCENT") "%" else ""} | Min: ₹${coup.minOrder.toInt()}", fontSize = 11.sp, color = Color.Gray)
                    }
                    IconButton(onClick = {
                        viewModel.adminDeleteCoupon(coup.code)
                        Toast.makeText(context, "Coupon deleted", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete", tint = LiorisError)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 6. ADMIN GIFTS SCREEN
// ==========================================
@Composable
fun AdminGiftsScreen(viewModel: LiorisViewModel) {
    val allGiftOffers by viewModel.allGiftOffers.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var giftItem by remember { mutableStateOf("") }
    var threshold by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "FREE GIFT SYSTEM", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        // Add gift campaign form card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("SETUP FREE GIFT CAMPAIGN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(value = giftItem, onValueChange = { giftItem = it }, label = { Text("Gift Product Name *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = threshold, onValueChange = { threshold = it }, label = { Text("Minimum Purchase Threshold *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = image, onValueChange = { image = it }, label = { Text("Gift Product Image URL") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (giftItem.isEmpty() || threshold.isEmpty()) {
                            Toast.makeText(context, "Fill required fields!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val newGift = GiftOffer(
                            offerId = UUID.randomUUID().toString(),
                            title = giftItem,
                            minOrderValue = threshold.toDoubleOrNull() ?: 500.0,
                            giftName = giftItem,
                            giftImage = image,
                            active = true,
                            createdAt = System.currentTimeMillis()
                        )
                        viewModel.adminAddGiftOffer(newGift)
                        Toast.makeText(context, "Gift Campaign published!", Toast.LENGTH_SHORT).show()
                        giftItem = ""
                        threshold = ""
                        image = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                ) {
                    Text("ACTIVATE GIFT OFFER", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // List active offers
        Text(text = "ACTIVE CAMPAIGNS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        allGiftOffers.forEach { go ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(go.giftName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Min Order: ₹${go.minOrderValue.toInt()}", fontSize = 11.sp, color = Color.Gray)
                    }
                    IconButton(onClick = {
                        viewModel.adminDeleteGiftOffer(go.offerId)
                        Toast.makeText(context, "Gift campaign deleted!", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete", tint = LiorisError)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 7. ADMIN WALLET ADJUSTMENT SCREEN
// ==========================================
@Composable
fun AdminWalletScreen(viewModel: LiorisViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    var searchPhoneQuery by remember { mutableStateOf("") }
    var searchedUser by remember { mutableStateOf<User?>(null) }

    var adjustAmount by remember { mutableStateOf("") }
    var adjustType by remember { mutableStateOf("CREDIT") }
    var adjustReason by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "CLIENTS WALLET CONTROLLER", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        // Search Box
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchPhoneQuery,
                onValueChange = { searchPhoneQuery = it },
                placeholder = { Text("Enter client phone (10 digits)") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    coroutineScope.launch {
                        val cleaned = LiorisRepository.cleanPhoneNumber(searchPhoneQuery)
                        val found = viewModel.db.dao().getUserByPhone(cleaned)
                        if (found != null) {
                            searchedUser = found
                            Toast.makeText(context, "User found!", Toast.LENGTH_SHORT).show()
                        } else {
                            searchedUser = null
                            Toast.makeText(context, "No registered user found with phone $cleaned", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
            ) {
                Text("SEARCH")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        searchedUser?.let { usr ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "CLIENT SPECIFICATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Name: ${usr.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Phone: +91 ${usr.phone}", fontSize = 12.sp)
                    Text("Loyalty Tier: ${usr.loyaltyLevel.uppercase()}", fontSize = 11.sp, color = Color.Gray)
                    Text("Current Wallet Cash: ₹${usr.walletBalance.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LiorisGoldDark, modifier = Modifier.padding(vertical = 4.dp))

                    Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 12.dp))

                    Text(text = "MANUALLY CREDIT / DEBIT CLIENT WALLET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { adjustType = "CREDIT" }) {
                            RadioButton(selected = adjustType == "CREDIT", onClick = { adjustType = "CREDIT" })
                            Text("Credit (+)", fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { adjustType = "DEBIT" }) {
                            RadioButton(selected = adjustType == "DEBIT", onClick = { adjustType = "DEBIT" })
                            Text("Debit (-)", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = adjustAmount, onValueChange = { adjustAmount = it }, label = { Text("Amount (₹) *") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = adjustReason, onValueChange = { adjustReason = it }, label = { Text("Reason (Custom note) *") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (adjustAmount.isEmpty() || adjustReason.isEmpty()) {
                                Toast.makeText(context, "Fill required fields!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val amt = adjustAmount.toDoubleOrNull() ?: 0.0

                            viewModel.adminAdjustWallet(usr.phone, amt, adjustReason, adjustType)
                            Toast.makeText(context, "Wallet adjustment transaction submitted!", Toast.LENGTH_SHORT).show()

                            // Update local card model UI
                            val currentBal = usr.walletBalance
                            val nextBal = if (adjustType == "CREDIT") currentBal + amt else currentBal - amt
                            searchedUser = usr.copy(walletBalance = nextBal)

                            adjustAmount = ""
                            adjustReason = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                    ) {
                        Text("SUBMIT TRANSACTION", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Divider(color = LiorisMediumGrey)
        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "REPAIR & MAINTENANCE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
        Spacer(modifier = Modifier.height(8.dp))

        var isRepairing by remember { mutableStateOf(false) }
        Button(
            onClick = {
                isRepairing = true
                viewModel.adminRepairWalletDeductions { count ->
                    isRepairing = false
                    Toast.makeText(context, "Wallet Repair Completed. $count orders repaired!", Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = LiorisGoldDark),
            shape = RoundedCornerShape(2.dp),
            enabled = !isRepairing
        ) {
            if (isRepairing) {
                CircularProgressIndicator(color = LiorisWhite, modifier = Modifier.size(20.dp))
            } else {
                Text("REPAIR WALLET DEDUCTIONS", fontWeight = FontWeight.Bold, color = LiorisWhite)
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 8. ADMIN NOTIFICATIONS BROADCASTER
// ==========================================
@Composable
fun AdminNotificationsScreen(viewModel: LiorisViewModel) {
    val context = LocalContext.current
    val adminNotifs by viewModel.allAdminNotifications.collectAsStateWithLifecycle()
    val otpLogs by viewModel.otpLogs.collectAsStateWithLifecycle()

    var targetPhone by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    var isSendingTestTelegram by remember { mutableStateOf(false) }
    var testTelegramResult by remember { mutableStateOf<String?>(null) }

    val dateFormat = remember { java.text.SimpleDateFormat("dd MMM HH:mm:ss", java.util.Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "ANNOUNCEMENTS & NOTIFICATIONS BROADCAST", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        // Card 1: In-App Notifications
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("DISPATCH IN-APP NOTIFICATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = targetPhone,
                    onValueChange = { targetPhone = it },
                    label = { Text("Target Phone (Leave empty to broadcast to ALL users)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Notification Title *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Alert Message *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (title.isEmpty() || message.isEmpty()) {
                            Toast.makeText(context, "Fill required * fields!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val cleaned = if (targetPhone.isNotEmpty()) LiorisRepository.cleanPhoneNumber(targetPhone) else ""
                        viewModel.adminSendNotification(title, message, cleaned)
                        Toast.makeText(context, "Notification processed successfully!", Toast.LENGTH_SHORT).show()

                        title = ""
                        message = ""
                        targetPhone = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                ) {
                    Text("DISPATCH PUSH MESSAGE", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Card 2: Telegram Testing
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("TELEGRAM NOTIFICATION TESTING", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(10.dp))
                Text("Send a test message to ensure the Bot Token and Chat ID integration works correctly.", fontSize = 11.sp, color = LiorisDarkGrey)
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        isSendingTestTelegram = true
                        testTelegramResult = null
                        viewModel.adminSendTestTelegramMessage { result ->
                            isSendingTestTelegram = false
                            if (result == null) {
                                testTelegramResult = "Success: Telegram notification test successful."
                            } else {
                                testTelegramResult = "Error: $result"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                    enabled = !isSendingTestTelegram
                ) {
                    if (isSendingTestTelegram) {
                        CircularProgressIndicator(color = LiorisWhite, modifier = Modifier.size(20.dp))
                    } else {
                        Text("SEND TEST TELEGRAM MESSAGE", fontWeight = FontWeight.Bold)
                    }
                }

                testTelegramResult?.let { res ->
                    Spacer(modifier = Modifier.height(12.dp))
                    val isSuccess = res.startsWith("Success")
                    Text(
                        text = res,
                        color = if (isSuccess) LiorisGreen else LiorisError,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Card 3: Telegram Notification Logs
        Text("TELEGRAM NOTIFICATION LOGS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            if (adminNotifs.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("No Telegram logs recorded yet.", fontSize = 11.sp, color = Color.Gray)
                }
            } else {
                Column(modifier = Modifier.padding(12.dp)) {
                    adminNotifs.sortedByDescending { it.createdAt }.take(20).forEach { log ->
                        val dateStr = try { dateFormat.format(java.util.Date(log.createdAt)) } catch(e: Exception) { "" }
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Order ID: ${log.orderId}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                if (log.errorMessage.isNotEmpty()) {
                                    Text("Error: ${log.errorMessage}", color = LiorisError, fontSize = 10.sp)
                                }
                                Text("Time: $dateStr", fontSize = 9.sp, color = Color.Gray)
                            }
                            val badgeColor = when (log.status) {
                                "sent" -> LiorisGreen
                                "skipped" -> Color.Gray
                                else -> LiorisError
                            }
                            Box(
                                modifier = Modifier
                                    .background(badgeColor, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(log.status.uppercase(), color = LiorisWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Card 4: OTP SMS Logs
        Text("OTP SMS GATEWAY LOGS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            if (otpLogs.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("No SMS logs recorded yet.", fontSize = 11.sp, color = Color.Gray)
                }
            } else {
                Column(modifier = Modifier.padding(12.dp)) {
                    otpLogs.sortedByDescending { it.createdAt }.take(20).forEach { log ->
                        val dateStr = try { dateFormat.format(java.util.Date(log.createdAt)) } catch(e: Exception) { "" }
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Phone: +91 ${log.phone}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("Mode: ${log.smsMode.uppercase()}", fontSize = 10.sp, color = LiorisGoldDark)
                                Text("Response: ${log.response}", fontSize = 10.sp, color = LiorisDarkGrey)
                                Text("Time: $dateStr", fontSize = 9.sp, color = Color.Gray)
                            }
                            val badgeColor = when (log.status) {
                                "success" -> LiorisGreen
                                else -> LiorisError
                            }
                            Box(
                                modifier = Modifier
                                    .background(badgeColor, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(log.status.uppercase(), color = LiorisWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 9. GLOBAL APP SETTINGS SCREEN
// ==========================================
@Composable
fun AdminSettingsScreen(viewModel: LiorisViewModel) {
    val settings by viewModel.storeSettings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var upiId by remember { mutableStateOf("") }
    var supportWhatsApp by remember { mutableStateOf("") }
    var deliveryCharge by remember { mutableStateOf("") }
    var qrImage by remember { mutableStateOf("") }
    var codAdvanceEnabled by remember { mutableStateOf(true) }
    var codAdvanceAmount by remember { mutableStateOf("50.0") }
    var otpMode by remember { mutableStateOf("test") }

    LaunchedEffect(settings) {
        upiId = settings.upiId
        supportWhatsApp = settings.supportWhatsApp
        deliveryCharge = settings.deliveryCharge.toString()
        qrImage = settings.qrImage
        codAdvanceEnabled = settings.codAdvanceEnabled
        codAdvanceAmount = settings.codAdvanceAmount.toString()
        otpMode = settings.otpMode
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "STORE CONFIGURATOR", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("GLOBAL BOUTIQUE CONSTANTS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(value = upiId, onValueChange = { upiId = it }, label = { Text("Receiver Merchant UPI ID *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = supportWhatsApp, onValueChange = { supportWhatsApp = it }, label = { Text("Customer Help Support WhatsApp Number *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = deliveryCharge, onValueChange = { deliveryCharge = it }, label = { Text("Delivery Charge for orders < ₹499 *") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(value = qrImage, onValueChange = { qrImage = it }, label = { Text("UPI QR Code Custom Image URL") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(16.dp))

                // --- OTP Mode Selector ---
                var showRealOtpWarning by remember { mutableStateOf(false) }

                if (showRealOtpWarning) {
                    AlertDialog(
                        onDismissRequest = { showRealOtpWarning = false },
                        title = {
                            Text(
                                text = "WARNING: REAL OTP CHARGES",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisError,
                                letterSpacing = 1.sp
                            )
                        },
                        text = {
                            Text(
                                text = "Real OTP mode may cost around ₹5 per SMS. Continue?",
                                fontSize = 13.sp,
                                color = LiorisDarkGrey
                            )
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    otpMode = "fast2sms_quick"
                                    showRealOtpWarning = false
                                }
                            ) {
                                Text("TURN ON", color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = {
                                    showRealOtpWarning = false
                                }
                            ) {
                                Text("CANCEL", color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                        },
                        containerColor = LiorisWhite,
                        shape = RoundedCornerShape(4.dp)
                    )
                }

                Text("OTP AUTHENTICATION SERVICE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (otpMode == "test") "TEST MODE (Free/Safe)" else "FAST2SMS REAL OTP ACTIVE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = LiorisBlack
                        )
                        Text(
                            text = if (otpMode == "test") "OTP is hardcoded to '123456' for developers and testing." else "Approx ₹5 may be charged per SMS.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    Switch(
                        checked = otpMode == "fast2sms_quick",
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                showRealOtpWarning = true
                            } else {
                                otpMode = "test"
                            }
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = LiorisGoldDark)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable COD ₹50 Advance System", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Requires customers to pay a UPI advance to secure COD orders", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = codAdvanceEnabled,
                        onCheckedChange = { codAdvanceEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = LiorisGoldDark)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                if (codAdvanceEnabled) {
                    OutlinedTextField(
                        value = codAdvanceAmount,
                        onValueChange = { codAdvanceAmount = it },
                        label = { Text("COD Advance Amount (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                Button(
                    onClick = {
                        if (upiId.isEmpty() || supportWhatsApp.isEmpty() || deliveryCharge.isEmpty()) {
                            Toast.makeText(context, "Fill required * fields!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (codAdvanceEnabled && codAdvanceAmount.isEmpty()) {
                            Toast.makeText(context, "COD Advance Amount is required!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val nextSettings = settings.copy(
                            upiId = upiId,
                            supportWhatsApp = supportWhatsApp,
                            deliveryCharge = deliveryCharge.toDoubleOrNull() ?: 50.0,
                            qrImage = qrImage,
                            codAdvanceEnabled = codAdvanceEnabled,
                            codAdvanceAmount = codAdvanceAmount.toDoubleOrNull() ?: 50.0,
                            otpMode = otpMode
                        )
                        viewModel.adminSaveSettings(nextSettings)
                        Toast.makeText(context, "Global configuration saved!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                ) {
                    Text("SAVE STORE CONFIGURATION", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 10. ADMIN CUSTOMERS SCREEN (FIRESTORE SYNCED)
// ==========================================
@Composable
fun AdminCustomersScreen(viewModel: LiorisViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var customersList by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    // Dialog states for viewing orders
    var selectedCustomerForOrders by remember { mutableStateOf<Map<String, Any>?>(null) }
    var customerOrdersList by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var isOrdersLoading by remember { mutableStateOf(false) }

    fun loadCustomers() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            try {
                if (FirestoreService.isFirebaseConfigured(context)) {
                    customersList = FirestoreService.getAllCustomers(context)
                } else {
                    errorMessage = "Firestore operation failed: Firebase not configured or connected"
                }
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Failed to fetch customers from Firestore"
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadCustomers()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "FIRESTORE CUSTOMERS", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = { loadCustomers() }) {
                Icon(imageVector = Icons.Filled.Refresh, contentDescription = "Refresh")
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = LiorisGoldDark)
            }
        } else if (errorMessage != null) {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                Text(text = errorMessage ?: "", color = LiorisError, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else if (customersList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "No customers found in Firestore.", fontSize = 12.sp, color = Color.Gray)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                customersList.forEach { cust ->
                    val phone = cust["phone"] as? String ?: ""
                    val name = cust["name"] as? String ?: ""
                    val walletBalance = (cust["walletBalance"] as? Number)?.toDouble() ?: 0.0
                    val totalOrders = (cust["totalOrders"] as? Number)?.toLong() ?: 0L
                    val totalSpent = (cust["totalSpent"] as? Number)?.toDouble() ?: 0.0
                    val role = cust["role"] as? String ?: "user"
                    
                    // Format Saved Address
                    val savedAddressMap = cust["savedAddress"] as? Map<String, Any>
                    val savedAddressStr = if (savedAddressMap != null) {
                        val addr = savedAddressMap["address"] as? String ?: ""
                        val city = savedAddressMap["city"] as? String ?: ""
                        val state = savedAddressMap["state"] as? String ?: ""
                        val pincode = savedAddressMap["pincode"] as? String ?: ""
                        if (addr.isNotEmpty()) "$addr, $city, $state - $pincode" else "No saved address"
                    } else {
                        val str = cust["savedAddress"] as? String ?: ""
                        if (str.isNotEmpty()) str else "No saved address"
                    }

                    // Format Date
                    val createdAt = cust["createdAt"]
                    val createdDateStr = if (createdAt is com.google.firebase.Timestamp) {
                        val date = createdAt.toDate()
                        SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(date)
                    } else if (createdAt is Number) {
                        SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date(createdAt.toLong()))
                    } else {
                        "N/A"
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "Phone: +91 $phone", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                if (role == "admin") {
                                    Box(
                                        modifier = Modifier
                                            .background(LiorisGoldLight, RoundedCornerShape(2.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("ADMIN", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Name: ${if (name.isEmpty()) "Guest Customer" else name}", fontSize = 11.sp, color = LiorisBlack)
                            Text(text = "Wallet: ₹${walletBalance.toInt()} | Spent: ₹${totalSpent.toInt()} | Orders: $totalOrders", fontSize = 11.sp, color = LiorisDarkGrey)
                            Text(text = "Address: $savedAddressStr", fontSize = 10.sp, color = Color.Gray)
                            Text(text = "Created: $createdDateStr", fontSize = 9.sp, color = Color.Gray)

                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Button(
                                onClick = {
                                    selectedCustomerForOrders = cust
                                    coroutineScope.launch {
                                        isOrdersLoading = true
                                        try {
                                            customerOrdersList = FirestoreService.getOrdersByCustomer(context, phone)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                        } finally {
                                            isOrdersLoading = false
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                            ) {
                                Text("VIEW CUSTOMER ORDERS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(48.dp))
            }
        }

        // Customer Orders Modal Dialog
        selectedCustomerForOrders?.let { cust ->
            val phone = cust["phone"] as? String ?: ""
            val name = cust["name"] as? String ?: ""
            AlertDialog(
                onDismissRequest = { selectedCustomerForOrders = null },
                title = { Text("Orders for ${if (name.isEmpty()) phone else name}", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Box(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                        if (isOrdersLoading) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = LiorisGoldDark)
                            }
                        } else if (customerOrdersList.isEmpty()) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No orders found for this customer.", fontSize = 12.sp, color = Color.Gray)
                            }
                        } else {
                            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                                customerOrdersList.forEach { ord ->
                                    val ordId = ord["orderId"] as? String ?: ""
                                    val amount = (ord["finalPayable"] as? Number)?.toDouble() ?: 0.0
                                    val status = ord["status"] as? String ?: "Pending"
                                    val pMethod = ord["paymentMethod"] as? String ?: "UPI"
                                    
                                    val createdAt = ord["createdAt"]
                                    val ordDateStr = if (createdAt is com.google.firebase.Timestamp) {
                                        SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(createdAt.toDate())
                                    } else if (createdAt is Number) {
                                        SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date(createdAt.toLong()))
                                    } else {
                                        "N/A"
                                    }

                                    Card(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                                        shape = RoundedCornerShape(2.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("ID: $ordId", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                Text(status.uppercase(), fontWeight = FontWeight.Bold, fontSize = 9.sp, color = LiorisGoldDark)
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text("Amount: ₹${amount.toInt()} | Pay: $pMethod", fontSize = 10.sp, color = LiorisDarkGrey)
                                            Text("Date: $ordDateStr", fontSize = 9.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedCustomerForOrders = null }) {
                        Text("CLOSE", fontWeight = FontWeight.Bold, color = LiorisBlack)
                    }
                }
            )
        }
    }
}
