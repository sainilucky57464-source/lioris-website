package com.example.ui.screens
import androidx.compose.ui.res.painterResource
import com.example.R

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.LiorisViewModel
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.flow.Flow
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiorisAppMainScreen(viewModel: LiorisViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val loggedInUser by viewModel.loggedInUser.collectAsStateWithLifecycle()
    val settings by viewModel.storeSettings.collectAsStateWithLifecycle()
    val userNotifications by viewModel.userNotifications.collectAsStateWithLifecycle()
    val cartSize = viewModel.cartItems.size
    val appError by viewModel.appError.collectAsStateWithLifecycle()

    val context = LocalContext.current

    if (appError != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Filled.ErrorOutline,
                    contentDescription = "Error",
                    tint = LiorisError,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Something went wrong.",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Please reload.",
                    fontSize = 16.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
                if (appError?.isNotEmpty() == true) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = appError ?: "",
                        fontSize = 12.sp,
                        color = Color.Red,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = { viewModel.reloadApp() },
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text(
                        text = "RELOAD LIORIS",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
        return
    }

    var showCheckoutDiscardDialog by remember { mutableStateOf(false) }

    if (showCheckoutDiscardDialog) {
        AlertDialog(
            onDismissRequest = { showCheckoutDiscardDialog = false },
            title = {
                Text(
                    text = "DISCARD CHECKOUT?",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to exit the premium checkout? Your selected luxury items will remain in the cart, but your entered checkout information will be cleared.",
                    fontSize = 14.sp,
                    color = LiorisDarkGrey
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCheckoutDiscardDialog = false
                        viewModel.navigateBack()
                    }
                ) {
                    Text("DISCARD", color = LiorisError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCheckoutDiscardDialog = false
                    }
                ) {
                    Text("CONTINUE SHOPPING", color = Color.Gray, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    androidx.activity.compose.BackHandler(enabled = currentScreen != Screen.Home && currentScreen != Screen.Splash && currentScreen != Screen.Login && currentScreen !is Screen.OrderSuccess) {
        if (currentScreen == Screen.Checkout) {
            showCheckoutDiscardDialog = true
        } else {
            viewModel.navigateBack()
        }
    }

    Scaffold(
        topBar = {
            if (currentScreen != Screen.Splash && currentScreen != Screen.Login && currentScreen !is Screen.OrderSuccess) {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "LIORIS",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisBlack,
                                letterSpacing = 3.sp,
                                fontFamily = FontFamily.Serif
                            )
                            Text(
                                text = "Discover more. Get the best.".uppercase(),
                                fontSize = 8.sp,
                                color = LiorisGoldDark,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    navigationIcon = {
                        if (currentScreen != Screen.Home) {
                            IconButton(onClick = {
                                if (currentScreen == Screen.Checkout) {
                                    showCheckoutDiscardDialog = true
                                } else {
                                    viewModel.navigateBack()
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = LiorisBlack
                                )
                            }
                        }
                    },
                    actions = {
                        // Notifications Bell
                        Box(
                            modifier = Modifier
                                .clickable {
                                    if (loggedInUser != null) {
                                        viewModel.navigateTo(Screen.Notifications)
                                    } else {
                                        viewModel.navigateTo(Screen.Login)
                                    }
                                }
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "Notifications",
                                tint = LiorisBlack
                            )
                            val unreadCount = userNotifications.count { !it.read }
                            if (unreadCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .size(14.dp)
                                        .background(LiorisError, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = unreadCount.toString(),
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Cart Action
                        IconButton(onClick = { viewModel.navigateTo(Screen.Cart) }) {
                            Box {
                                Icon(
                                    imageVector = Icons.Outlined.ShoppingBag,
                                    contentDescription = "Cart",
                                    tint = LiorisBlack
                                )
                                if (cartSize > 0) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(14.dp)
                                            .background(LiorisGold, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = cartSize.toString(),
                                            color = LiorisBlack,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = LiorisWhite)
                )
            }
        },
        bottomBar = {
            if (currentScreen != Screen.Splash && currentScreen != Screen.Login && currentScreen !is Screen.OrderSuccess) {
                NavigationBar(
                    containerColor = LiorisWhite,
                    tonalElevation = 8.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    val items = listOf(
                        Triple(Screen.Home, Icons.Filled.Home, Icons.Outlined.Home),
                        Triple(Screen.Orders, Icons.Filled.ListAlt, Icons.Outlined.ListAlt),
                        Triple(Screen.Cart, Icons.Filled.ShoppingBag, Icons.Outlined.ShoppingBag),
                        Triple(Screen.Wallet, Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
                        Triple(Screen.Profile, Icons.Filled.Person, Icons.Outlined.Person)
                    )

                    val labels = listOf("Home", "Orders", "Cart", "Wallet", "Profile")

                    items.forEachIndexed { idx, (screen, filledIcon, outlinedIcon) ->
                        val isSelected = currentScreen::class == screen::class
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(screen, clearStack = screen == Screen.Home) },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) filledIcon else outlinedIcon,
                                    contentDescription = labels[idx],
                                    tint = if (isSelected) LiorisGoldDark else LiorisBlack
                                )
                            },
                            label = {
                                Text(
                                    text = labels[idx],
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) LiorisGoldDark else LiorisBlack
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = LiorisGoldLight
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(LiorisLightGrey)
        ) {
            when (val screen = currentScreen) {
                is Screen.Splash -> SplashScreen(viewModel)
                is Screen.Login -> LoginScreen(viewModel)
                is Screen.Home -> HomeScreen(viewModel)
                is Screen.ProductDetail -> ProductDetailScreen(screen.productId, viewModel)
                is Screen.Cart -> CartScreen(viewModel)
                is Screen.Checkout -> CheckoutScreen(viewModel)
                is Screen.Orders -> OrdersScreen(viewModel)
                is Screen.OrderSuccess -> OrderSuccessScreen(screen.orderId, viewModel)
                is Screen.Wallet -> WalletScreen(viewModel)
                is Screen.Profile -> ProfileScreen(viewModel)
                is Screen.Notifications -> NotificationsScreen(viewModel)
                is Screen.TrackOrder -> TrackOrderScreen(screen.orderId, viewModel)

                // Admin Screens
                is Screen.AdminDashboard -> AdminDashboardScreen(viewModel)
                is Screen.AdminProducts -> AdminProductsScreen(viewModel)
                is Screen.AdminOrders -> AdminOrdersScreen(viewModel)
                is Screen.AdminCustomers -> AdminCustomersScreen(viewModel)
                is Screen.AdminBanners -> AdminBannersScreen(viewModel)
                is Screen.AdminCoupons -> AdminCouponsScreen(viewModel)
                is Screen.AdminGifts -> AdminGiftsScreen(viewModel)
                is Screen.AdminWallet -> AdminWalletScreen(viewModel)
                is Screen.AdminNotifications -> AdminNotificationsScreen(viewModel)
                is Screen.AdminSettings -> AdminSettingsScreen(viewModel)
            }
        }
    }
}

// ==========================================
// 0. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(viewModel: LiorisViewModel) {
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(1000)
        viewModel.onSplashFinished()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_logo),
                contentDescription = "LIORIS Logo",
                modifier = Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "LIORIS",
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = LiorisBlack,
                letterSpacing = 6.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Discover more. Get the best.",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.SansSerif,
                color = LiorisGoldDark,
                letterSpacing = 1.sp
            )
        }
    }
}

// ==========================================
// 1. PHONE OTP LOGIN SCREEN
// ==========================================
@Composable
fun LoginScreen(viewModel: LiorisViewModel) {
    val phone by viewModel.loginPhone.collectAsStateWithLifecycle()
    val otp by viewModel.loginOtp.collectAsStateWithLifecycle()
    val loginName by viewModel.loginName.collectAsStateWithLifecycle()
    val referralInput by viewModel.referralCodeInput.collectAsStateWithLifecycle()
    val isOtpSent by viewModel.isOtpSent.collectAsStateWithLifecycle()
    val error by viewModel.loginError.collectAsStateWithLifecycle()
    val successMsg by viewModel.loginSuccessMsg.collectAsStateWithLifecycle()
    val isSending by viewModel.isSendingOtp.collectAsStateWithLifecycle()
    val isVerifying by viewModel.isVerifyingOtp.collectAsStateWithLifecycle()
    val cooldown by viewModel.otpCooldown.collectAsStateWithLifecycle()
    val showQuickSmsWarning by viewModel.showQuickSmsWarning.collectAsStateWithLifecycle()
 
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    var selectedProvider by remember { mutableStateOf<String?>(null) }
    var showGoogleAccountsDialog by remember { mutableStateOf(false) }

    if (showQuickSmsWarning) {
        AlertDialog(
            onDismissRequest = { viewModel.showQuickSmsWarning.value = false },
            title = {
                Text(
                    text = "CONFIRM QUICK SMS SEND",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Text(
                    text = "Quick SMS may cost higher. Continue?",
                    fontSize = 14.sp,
                    color = LiorisDarkGrey
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.showQuickSmsWarning.value = false
                        viewModel.sendLoginOtp(forceQuick = true)
                    }
                ) {
                    Text("CONTINUE", color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.showQuickSmsWarning.value = false
                    }
                ) {
                    Text("CANCEL", color = Color.Gray, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    if (showGoogleAccountsDialog) {
        AlertDialog(
            onDismissRequest = { showGoogleAccountsDialog = false },
            title = {
                Text(
                    text = "Choose an account to continue to Lioris",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Option 1: Primary requested account
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(LiorisLightGrey)
                            .clickable {
                                showGoogleAccountsDialog = false
                                viewModel.loginWithGoogle(
                                    uid = "G_sainilucky57465",
                                    email = "sainilucky57465@gmail.com",
                                    displayName = "Lucky Saini",
                                    onSuccess = {
                                        Toast.makeText(context, "Logged in via Google", Toast.LENGTH_SHORT).show()
                                    },
                                    onFailure = { err ->
                                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                    }
                                )
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(LiorisGoldDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("L", color = LiorisWhite, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Lucky Saini", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                            Text("sainilucky57465@gmail.com", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    // Option 2: Generic tester account
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(LiorisLightGrey)
                            .clickable {
                                showGoogleAccountsDialog = false
                                viewModel.loginWithGoogle(
                                    uid = "G_tester123",
                                    email = "tester@gmail.com",
                                    displayName = "Lioris Tester",
                                    onSuccess = {
                                        Toast.makeText(context, "Logged in via Google", Toast.LENGTH_SHORT).show()
                                    },
                                    onFailure = { err ->
                                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                    }
                                )
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(LiorisBlack, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("T", color = LiorisWhite, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Lioris Tester", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                            Text("tester@gmail.com", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showGoogleAccountsDialog = false }) {
                    Text("CANCEL", color = Color.Gray, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }
 
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiorisWhite)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(40.dp))
 
        // Large Premium Branding Logo
        Image(
            painter = painterResource(id = R.drawable.img_logo),
            contentDescription = "LIORIS Logo",
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "LIORIS",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 6.sp,
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "Discover more. Get the best.",
            fontSize = 11.sp,
            color = LiorisGoldDark,
            fontWeight = FontWeight.Medium,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
        )

        if (selectedProvider == null) {
            // Options Menu Screen
            Text(
                text = "SIGN IN TO YOUR PREMIUM ACCOUNT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisDarkGrey,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Button 1: Continue with Phone (Premium solid Black)
            Button(
                onClick = { selectedProvider = "phone" },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("continue_with_phone_btn"),
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
            ) {
                Icon(
                    imageVector = Icons.Filled.Phone,
                    contentDescription = "Phone Icon",
                    tint = LiorisWhite,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text("CONTINUE WITH PHONE", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Button 2: Continue with Google (Premium outline gold)
            OutlinedButton(
                onClick = { showGoogleAccountsDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("continue_with_google_btn"),
                shape = RoundedCornerShape(2.dp),
                border = BorderStroke(1.5.dp, LiorisGoldDark),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = LiorisGoldDark)
            ) {
                Icon(
                    imageVector = Icons.Filled.AccountCircle,
                    contentDescription = "Google Icon",
                    tint = LiorisGoldDark,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text("CONTINUE WITH GOOGLE", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        } else if (selectedProvider == "phone") {
            // Login Box Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = LiorisLightGrey),
                shape = RoundedCornerShape(4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (!isOtpSent) "ENTER PHONE" else "ENTER 6-DIGIT OTP",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (!isOtpSent) "An OTP will be sent to verify your phone number." else "We sent a 6-digit code to phone ending with **${phone.takeLast(4)}**",
                        fontSize = 11.sp,
                        color = LiorisDarkGrey,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    // Name Input field (Required)
                    if (!isOtpSent) {
                        OutlinedTextField(
                            value = loginName,
                            onValueChange = { viewModel.loginName.value = it },
                            label = { Text("Your Name", fontSize = 12.sp) },
                            placeholder = { Text("John Doe") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_name_input"),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LiorisGoldDark,
                                unfocusedBorderColor = LiorisMediumGrey,
                                cursorColor = LiorisGoldDark,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            enabled = !isSending
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Phone Input field
                    OutlinedTextField(
                        value = phone,
                        onValueChange = {
                            if (it.length <= 15) viewModel.loginPhone.value = it
                        },
                        label = { Text("Phone Number", fontSize = 12.sp) },
                        placeholder = { Text("9999999999") },
                        prefix = { Text("+91 ", fontWeight = FontWeight.Bold) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_phone_input"),
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LiorisGoldDark,
                            unfocusedBorderColor = LiorisMediumGrey,
                            cursorColor = LiorisGoldDark,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        enabled = !isOtpSent && !isSending
                    )

                    if (isOtpSent) {
                        Spacer(modifier = Modifier.height(12.dp))
                        // OTP Input field
                        OutlinedTextField(
                            value = otp,
                            onValueChange = { if (it.length <= 6) viewModel.loginOtp.value = it },
                            label = { Text("6-Digit OTP", fontSize = 12.sp) },
                            placeholder = { Text("------") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_otp_input"),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LiorisGoldDark,
                                unfocusedBorderColor = LiorisMediumGrey
                            ),
                            enabled = !isVerifying
                        )
                    } else {
                        Spacer(modifier = Modifier.height(12.dp))
                        // Referral code input field (Optional) during signup
                        OutlinedTextField(
                            value = referralInput,
                            onValueChange = { viewModel.referralCodeInput.value = it },
                            label = { Text("Referral Code (Optional)", fontSize = 12.sp) },
                            placeholder = { Text("LIORIS5746ABC") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LiorisGoldDark,
                                unfocusedBorderColor = LiorisMediumGrey
                            ),
                            enabled = !isSending
                        )
                    }

                    if (error.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = error,
                            color = LiorisError,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (successMsg.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = successMsg,
                            color = LiorisGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Action Button
                    Button(
                        onClick = {
                            if (!isOtpSent) {
                                viewModel.sendLoginOtp()
                            } else {
                                viewModel.verifyLoginOtp()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("login_action_btn"),
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                        enabled = !isSending && !isVerifying
                    ) {
                        if (isSending || isVerifying) {
                            CircularProgressIndicator(color = LiorisWhite, modifier = Modifier.size(20.dp))
                        } else {
                            Text(
                                text = if (!isOtpSent) "SEND VERIFICATION CODE" else "VERIFY & LOGIN",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    // Resend OTP Section
                    if (isOtpSent) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (cooldown > 0) "Resend OTP in ${cooldown}s" else "Didn't receive OTP?",
                                fontSize = 11.sp,
                                color = LiorisDarkGrey
                            )
                            TextButton(
                                onClick = { viewModel.sendLoginOtp() },
                                enabled = cooldown == 0 && !isSending,
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = "RESEND",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (cooldown == 0) LiorisGoldDark else Color.Gray,
                                    textDecoration = TextDecoration.Underline
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Back link to other sign in choices
            TextButton(
                onClick = {
                    selectedProvider = null
                    viewModel.loginError.value = ""
                    viewModel.loginSuccessMsg.value = ""
                }
            ) {
                Text(
                    text = "← Back to Login Choices",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisGoldDark
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// ==========================================
// 2. HOME PAGE — BIG BRAND STYLE
// ==========================================
@Composable
fun HomeScreen(viewModel: LiorisViewModel) {
    val productsList by viewModel.products.collectAsStateWithLifecycle()
    val banners by viewModel.activeBanners.collectAsStateWithLifecycle()
    val activeCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val settings by viewModel.storeSettings.collectAsStateWithLifecycle()
    val loggedInUser by viewModel.loggedInUser.collectAsStateWithLifecycle()

    val context = LocalContext.current

    val categories = listOf(
        "All", "Clothing", "Metal Items", "Home", "Premium Picks",
        "Bulk Orders", "New Arrivals", "Offers", "Gifts"
    )

    // Filter products
    val filteredProducts = remember(productsList, activeCategory, searchQuery) {
        productsList.filter { p ->
            val matchesCategory = if (activeCategory == "All") {
                p.active
            } else if (activeCategory == "New Arrivals") {
                p.active && p.newArrival
            } else if (activeCategory == "Premium Picks") {
                p.active && p.trending
            } else {
                p.active && p.category.equals(activeCategory, ignoreCase = true)
            }

            val matchesSearch = if (searchQuery.isEmpty()) {
                true
            } else {
                p.name.contains(searchQuery, ignoreCase = true) ||
                        p.category.contains(searchQuery, ignoreCase = true) ||
                        p.description.contains(searchQuery, ignoreCase = true)
            }

            matchesCategory && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Support Banner Announcement
        AnnouncementBar(message = "✨ New Collection Live! Get ₹50 Welcome Bonus! ✨")

        // Gold Member Account / Wallet Balance Header as requested in the design HTML
        loggedInUser?.let { user ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(LiorisBlack, shape = RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${user.loyaltyLevel} Account".uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisGold,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹${(user.walletBalance).toInt()}.00",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            color = LiorisWhite
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "REFERRAL CODE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisWhite.copy(alpha = 0.6f),
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = user.referralCode.ifEmpty { "LIORIS788XYZ" }.uppercase(),
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = LiorisWhite
                        )
                    }
                }
            }
        }

        // Search Bar Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LiorisWhite)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("Search premium fashion & metals...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = Color.Gray
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(imageVector = Icons.Filled.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("home_search_bar"),
                shape = RoundedCornerShape(2.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LiorisGold,
                    unfocusedBorderColor = LiorisMediumGrey
                )
            )
        }

        // Categories selector horizontally
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LiorisWhite)
                .padding(bottom = 12.dp)
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = activeCategory == cat
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isSelected) LiorisBlack else LiorisLightGrey,
                                shape = RoundedCornerShape(2.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) LiorisBlack else LiorisMediumGrey,
                                shape = RoundedCornerShape(2.dp)
                            )
                            .clickable { viewModel.selectedCategory.value = cat }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat.uppercase(),
                            color = if (isSelected) LiorisWhite else LiorisBlack,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        if (searchQuery.isEmpty() && activeCategory == "All") {
            // Hero / Banner Carousel Section
            if (banners.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    // Show first banner for simplicity, in production we can auto-scroll
                    val firstBanner = banners.first()
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(firstBanner.image)
                            .crossfade(true)
                            .build(),
                        contentDescription = firstBanner.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Overlay text gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.4f))
                            .padding(20.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Column {
                            Text(
                                text = firstBanner.title.uppercase(),
                                color = LiorisWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                            if (firstBanner.subtitle.isNotEmpty()) {
                                Text(
                                    text = firstBanner.subtitle,
                                    color = LiorisGold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Trust Badges
            TrustBadgesSection()

            // Dynamic Offer Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LiorisGoldLight)
                    .clickable { viewModel.navigateTo(Screen.Wallet) }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.LocalOffer,
                        contentDescription = "Offer",
                        tint = LiorisGoldDark
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "CLAIM ₹50 SIGN-UP BONUS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisBlack,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Sign up & get instant balance. Use referral code to earn more.",
                            fontSize = 10.sp,
                            color = LiorisDarkGrey
                        )
                    }
                }
            }

            // Products grid groupings
            // Group 1: Trending
            HomeProductHorizontalRow(
                title = "TRENDING NOW",
                products = productsList.filter { p -> p.trending && p.active },
                viewModel = viewModel
            )

            // Group 2: New Arrivals
            HomeProductHorizontalRow(
                title = "NEW ARRIVALS",
                products = productsList.filter { p -> p.newArrival && p.active },
                viewModel = viewModel
            )

            // Group 3: Best Sellers
            HomeProductHorizontalRow(
                title = "BEST SELLERS",
                products = productsList.filter { p -> p.bestSeller && p.active },
                viewModel = viewModel
            )

            // Group 4: Under ₹499 Section
            HomeProductHorizontalRow(
                title = "UNDER ₹499 STORES",
                products = productsList.filter { p -> p.price < 499.0 && p.active },
                viewModel = viewModel
            )

            // Group 5: Recently Viewed
            if (viewModel.recentlyViewed.isNotEmpty()) {
                HomeProductHorizontalRow(
                    title = "RECENTLY VIEWED",
                    products = viewModel.recentlyViewed.toList(),
                    viewModel = viewModel
                )
            }

            // Group 6: Recommended for you
            HomeProductHorizontalRow(
                title = "RECOMMENDED FOR YOU",
                products = productsList.filter { p -> p.active }.shuffled(Random(12)),
                viewModel = viewModel
            )

        } else {
            // Search / Filtered List layout
            Text(
                text = "${filteredProducts.size} PREMIUM PRODUCTS FOUND",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisGoldDark,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                letterSpacing = 1.sp
            )

            if (filteredProducts.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.ShoppingBag,
                        contentDescription = "Empty list",
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Products Match Your Filter",
                        color = LiorisBlack,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Try adjusting your search query or pick another premium category.",
                        color = LiorisDarkGrey,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            } else {
                // Render products in list
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Chunk into pairs to look like a grid
                    filteredProducts.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            pair.forEach { prod ->
                                PremiumProductCard(
                                    product = prod,
                                    onProductClick = {
                                        viewModel.addToRecentlyViewed(prod)
                                        viewModel.navigateTo(Screen.ProductDetail(prod.id))
                                    },
                                    onAddToCartClick = {
                                        viewModel.addToCart(prod)
                                        Toast.makeText(context, "Added ${prod.name} to Cart!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (pair.size < 2) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun HomeProductHorizontalRow(
    title: String,
    products: List<Product>,
    viewModel: LiorisViewModel
) {
    if (products.isEmpty()) return
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title.uppercase(),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisBlack,
                letterSpacing = 1.5.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "VIEW ALL",
                fontSize = 10.sp,
                color = LiorisGoldDark,
                fontWeight = FontWeight.Bold,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier.clickable {
                    viewModel.selectedCategory.value = "All"
                    Toast.makeText(context, "Scroll down to explore!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(products) { prod ->
                PremiumProductCard(
                    product = prod,
                    onProductClick = {
                        viewModel.addToRecentlyViewed(prod)
                        viewModel.navigateTo(Screen.ProductDetail(prod.id))
                    },
                    onAddToCartClick = {
                        viewModel.addToCart(prod)
                        Toast.makeText(context, "Added ${prod.name} to Cart!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

// ==========================================
// 3. PRODUCT DETAIL PAGE
// ==========================================
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProductDetailScreen(productId: String, viewModel: LiorisViewModel) {
    val productsList by viewModel.products.collectAsStateWithLifecycle()
    val product = productsList.find { it.id == productId }
    val currentUser by viewModel.loggedInUser.collectAsStateWithLifecycle()

    val context = LocalContext.current

    if (product == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Product not found.", fontWeight = FontWeight.Bold)
        }
        return
    }

    val selectedSize by viewModel.pdpSize.collectAsStateWithLifecycle()
    val selectedColor by viewModel.pdpColor.collectAsStateWithLifecycle()

    val images = product.images.split(",")
    var activeImageIdx by remember { mutableStateOf(0) }
    var zoomActive by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiorisWhite)
            .verticalScroll(rememberScrollState())
    ) {
        // Multi Image Carousel Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(350.dp)
        ) {
            val activeImageUrl = images.getOrNull(activeImageIdx) ?: ""

            // Main Product image
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(activeImageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = product.name,
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { zoomActive = !zoomActive },
                contentScale = if (zoomActive) ContentScale.Inside else ContentScale.Crop
            )

            if (zoomActive) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(8.dp)
                ) {
                    Text("ZOOM ACTIVE - Click again to shrink", color = Color.White, fontSize = 9.sp)
                }
            }

            // Indicators
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                images.forEachIndexed { idx, _ ->
                    Box(
                        modifier = Modifier
                            .size(if (idx == activeImageIdx) 10.dp else 6.dp)
                            .background(
                                color = if (idx == activeImageIdx) LiorisGold else Color.Gray,
                                shape = CircleShape
                            )
                            .clickable { activeImageIdx = idx }
                    )
                }
            }

            // Navigation Left/Right arrows overlay
            if (images.size > 1) {
                IconButton(
                    onClick = { activeImageIdx = (activeImageIdx - 1 + images.size) % images.size },
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(8.dp)
                        .background(Color.White.copy(0.4f), CircleShape)
                ) {
                    Icon(imageVector = Icons.Filled.KeyboardArrowLeft, contentDescription = "Prev")
                }

                IconButton(
                    onClick = { activeImageIdx = (activeImageIdx + 1) % images.size },
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(8.dp)
                        .background(Color.White.copy(0.4f), CircleShape)
                ) {
                    Icon(imageVector = Icons.Filled.KeyboardArrowRight, contentDescription = "Next")
                }
            }
        }

        // Details Panel
        Column(modifier = Modifier.padding(20.dp)) {
            // Brand Category Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "LIORIS LUXURY / ${product.category.uppercase()}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisGoldDark,
                    letterSpacing = 1.5.sp
                )
                // Share action
                IconButton(onClick = {
                    shareProductOnWhatsApp(
                        context,
                        product.name,
                        product.price,
                        product.id,
                        currentUser?.referralCode ?: ""
                    )
                }) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "Share",
                        tint = LiorisBlack,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Product Title
            Text(
                text = product.name,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisBlack
            )

            // Ratings Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(top = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = "Rating",
                    tint = LiorisRatingStar,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "${product.rating} / 5.0",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack
                )
                Text(
                    text = "(${product.reviewCount} customer reviews)",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Pricing Area
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "₹${product.price.toInt()}",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack
                )
                if (product.mrp > product.price) {
                    Text(
                        text = "₹${product.mrp.toInt()}",
                        fontSize = 16.sp,
                        color = Color.Gray,
                        textDecoration = TextDecoration.LineThrough
                    )
                    Box(
                        modifier = Modifier
                            .background(LiorisGoldLight, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${product.discount.toInt()}% OFF SAVINGS",
                            color = LiorisGoldDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sizes options selector
            if (product.sizes.isNotEmpty()) {
                Text(
                    text = "SELECT SIZE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    product.sizes.split(",").forEach { s ->
                        val isSelected = selectedSize == s
                        Box(
                            modifier = Modifier
                                .background(if (isSelected) LiorisBlack else LiorisLightGrey, RoundedCornerShape(2.dp))
                                .border(1.dp, if (isSelected) LiorisBlack else LiorisMediumGrey, RoundedCornerShape(2.dp))
                                .clickable { viewModel.pdpSize.value = s }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = s,
                                color = if (isSelected) LiorisWhite else LiorisBlack,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Colors options selector
            if (product.colors.isNotEmpty()) {
                Text(
                    text = "SELECT COLOUR Accent",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    product.colors.split(",").forEach { c ->
                        val isSelected = selectedColor == c
                        Box(
                            modifier = Modifier
                                .background(if (isSelected) LiorisBlack else LiorisLightGrey, RoundedCornerShape(2.dp))
                                .border(1.dp, if (isSelected) LiorisBlack else LiorisMediumGrey, RoundedCornerShape(2.dp))
                                .clickable { viewModel.pdpColor.value = c }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = c,
                                color = if (isSelected) LiorisWhite else LiorisBlack,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Description
            Text(
                text = "PRODUCT OVERVIEW",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisBlack,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            Text(
                text = product.description,
                fontSize = 13.sp,
                color = LiorisDarkGrey,
                lineHeight = 18.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Highlights (Bullet items)
            if (product.highlights.isNotEmpty()) {
                Text(
                    text = "EXQUISITE DETAILS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                product.highlights.split(",").forEach { hl ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(LiorisGold, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = hl.trim(), fontSize = 12.sp, color = LiorisDarkGrey)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Policy & Support summary cards
            Divider(color = LiorisMediumGrey, modifier = Modifier.padding(vertical = 8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.Loop, contentDescription = "Return", tint = LiorisGoldDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Easy Returns", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text("7 days return support", fontSize = 10.sp, color = Color.Gray)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.CheckCircle, contentDescription = "COD", tint = LiorisGoldDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("COD Available", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text("Pay in cash at your door", fontSize = 10.sp, color = Color.Gray)
                }
            }
            Divider(color = LiorisMediumGrey, modifier = Modifier.padding(vertical = 12.dp))

            // Action Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Add to Cart
                Button(
                    onClick = {
                        viewModel.addToCart(product)
                        Toast.makeText(context, "Added to bag!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                    enabled = product.stock > 0
                ) {
                    Icon(imageVector = Icons.Outlined.ShoppingBag, contentDescription = "Cart")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ADD TO BAG", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Buy Now
                Button(
                    onClick = {
                        viewModel.addToCart(product)
                        viewModel.navigateTo(Screen.Cart)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisGoldDark),
                    enabled = product.stock > 0
                ) {
                    Text("BUY IT NOW", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Frequently Bought Together Section (Smart Recommendation)
            val relatedProducts = productsList.filter { it.id != product.id && it.active && it.category == product.category }.take(3)
            if (relatedProducts.isNotEmpty()) {
                Text(
                    text = "FREQUENTLY BOUGHT TOGETHER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 12.dp, top = 12.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    relatedProducts.forEach { rel ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.navigateTo(Screen.ProductDetail(rel.id)) },
                            colors = CardDefaults.cardColors(containerColor = LiorisLightGrey),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = rel.images.split(",").firstOrNull(),
                                    contentDescription = rel.name,
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(rel.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("₹${rel.price.toInt()}", fontSize = 11.sp, color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                                }
                                Icon(imageVector = Icons.Filled.ChevronRight, contentDescription = "View")
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 4. CART AND CHECKOUT
// ==========================================
@Composable
fun CartScreen(viewModel: LiorisViewModel) {
    val items = viewModel.cartItems
    val subtotal = viewModel.getCartSubtotal()
    val isEligibleGift = viewModel.isGiftUnlocked()
    val progressGift = viewModel.getGiftOfferProgress()
    val shortfallGift = viewModel.getGiftOfferShortfall()
    val giftName = viewModel.getGiftItemName()
    val activeOffers by viewModel.activeGiftOffers.collectAsStateWithLifecycle()
    val giftOffer = activeOffers.firstOrNull()

    val context = LocalContext.current
    var showGiftDetailsDialog by remember { mutableStateOf(false) }

    if (showGiftDetailsDialog && giftOffer != null) {
        AlertDialog(
            onDismissRequest = { showGiftDetailsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.CardGiftcard, contentDescription = "Gift Icon", tint = LiorisGoldDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EXCLUSIVE LIORIS GIFT",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack,
                        letterSpacing = 1.sp
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = "Gift Item: ${giftOffer.giftName}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = giftOffer.title,
                        fontSize = 12.sp,
                        color = LiorisDarkGrey
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = LiorisLightGrey)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isEligibleGift) "Congratulations! This luxury gift is yours FREE with this order." 
                               else "Unlocked on orders above ₹${giftOffer.minOrderValue.toInt()}.\nAdd premium boutique items worth ₹${shortfallGift.toInt()} more to automatically unlock and receive this elegant free gift with your delivery.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isEligibleGift) LiorisGreen else LiorisGoldDark
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showGiftDetailsDialog = false }) {
                    Text("CLOSE", color = LiorisBlack, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    if (items.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.ShoppingBag,
                contentDescription = "Empty Cart",
                tint = Color.LightGray,
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text("YOUR SHOPPING BAG IS EMPTY", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "Add exquisite items to your luxury cart to browse details and check out.",
                color = LiorisDarkGrey,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = { viewModel.navigateTo(Screen.Home) },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
            ) {
                Text("START SHOPPING", fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "YOUR SHOPPING BAG (${items.size})",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Free Gift Progress bar (Unlocker) - Luxury Prestige Theme
        if (giftOffer != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clickable { showGiftDetailsDialog = true },
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F2F2)),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, LiorisGoldLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (isEligibleGift) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.CardGiftcard,
                                    contentDescription = "Free Gift Unlock",
                                    tint = LiorisGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "FREE GIFT UNLOCKED",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = LiorisBlack
                                )
                            }
                            Text(
                                text = "UNLOCKED!",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisGold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Your luxury free gift '$giftName' has been added to your order summary.",
                            fontSize = 10.sp,
                            color = LiorisDarkGrey,
                            lineHeight = 14.sp
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.CardGiftcard,
                                    contentDescription = "Free Gift Unlock",
                                    tint = LiorisGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "FREE GIFT UNLOCK",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = LiorisBlack
                                )
                            }
                            Text(
                                text = "Add ₹${shortfallGift.toInt()} more",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisGold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { progressGift },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape),
                            color = LiorisGold,
                            trackColor = Color.White,
                        )
                    }
                }
            }
        }

        // Cart Items List
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = item.imageUrl,
                            contentDescription = item.productName,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.productName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisBlack,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (item.selectedSize.isNotEmpty() || item.selectedColor.isNotEmpty()) {
                                Text(
                                    text = "Options: ${item.selectedSize} / ${item.selectedColor}",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                            Text(
                                text = "₹${item.price.toInt()}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisGoldDark
                            )
                        }

                        // Quantity adjusters
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(onClick = { viewModel.updateCartQuantity(item, -1) }) {
                                Icon(imageVector = Icons.Filled.RemoveCircleOutline, contentDescription = "Minus", modifier = Modifier.size(18.dp))
                            }
                            Text(
                                text = item.quantity.toString(),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { viewModel.updateCartQuantity(item, 1) }) {
                                Icon(imageVector = Icons.Filled.AddCircleOutline, contentDescription = "Plus", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    Divider(color = LiorisLightGrey)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Price Summary Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ORDER BREAKDOWN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal", fontSize = 12.sp, color = LiorisDarkGrey)
                    Text("₹${subtotal.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                val deliveryCharge = viewModel.getDeliveryCharge()
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Delivery Shipping", fontSize = 12.sp, color = LiorisDarkGrey)
                    Text(if (deliveryCharge == 0.0) "FREE" else "₹${deliveryCharge.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (deliveryCharge == 0.0) LiorisGreen else LiorisBlack)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Est. Tax (Included)", fontSize = 12.sp, color = Color.Gray)
                    Text("₹0", fontSize = 12.sp)
                }

                Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Bag Value", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("₹${(subtotal + deliveryCharge).toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Checkout Button
        Button(
            onClick = {
                if (viewModel.loggedInUser.value != null) {
                    viewModel.navigateTo(Screen.Checkout)
                } else {
                    viewModel.navigateTo(Screen.Login)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("checkout_btn"),
            shape = RoundedCornerShape(2.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
        ) {
            Text("PROCEED TO CHECKOUT", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 5. CHECKOUT SCREEN WITH COUPONS, WALLETS, UPI
// ==========================================
@Composable
fun CheckoutScreen(viewModel: LiorisViewModel) {
    val user by viewModel.loggedInUser.collectAsStateWithLifecycle()
    val appliedCoupon by viewModel.appliedCoupon.collectAsStateWithLifecycle()
    val useWallet by viewModel.useWallet.collectAsStateWithLifecycle()
    val couponError by viewModel.couponError.collectAsStateWithLifecycle()
    val settings by viewModel.storeSettings.collectAsStateWithLifecycle()

    val context = LocalContext.current

    // Checkout field collectors
    val name by viewModel.checkoutName.collectAsStateWithLifecycle()
    val address by viewModel.checkoutAddress.collectAsStateWithLifecycle()
    val pincode by viewModel.checkoutPincode.collectAsStateWithLifecycle()
    val city by viewModel.checkoutCity.collectAsStateWithLifecycle()
    val state by viewModel.checkoutState.collectAsStateWithLifecycle()
    val landmark by viewModel.checkoutLandmark.collectAsStateWithLifecycle()
    val paymentMethod by viewModel.checkoutPaymentMethod.collectAsStateWithLifecycle()
    val utr by viewModel.checkoutUtr.collectAsStateWithLifecycle()

    // Checkout OTP collectors
    val chPhone by viewModel.checkoutPhone.collectAsStateWithLifecycle()
    val chOtp by viewModel.checkoutOtp.collectAsStateWithLifecycle()
    val isChOtpSent by viewModel.isCheckoutOtpSent.collectAsStateWithLifecycle()
    val isSendingChOtp by viewModel.isSendingCheckoutOtp.collectAsStateWithLifecycle()
    val isVerifyingChOtp by viewModel.isVerifyingCheckoutOtp.collectAsStateWithLifecycle()
    val chOtpError by viewModel.checkoutOtpError.collectAsStateWithLifecycle()
    val chOtpSuccess by viewModel.checkoutOtpSuccess.collectAsStateWithLifecycle()
    val chOtpCooldown by viewModel.checkoutOtpCooldown.collectAsStateWithLifecycle()

    var couponCodeInput by remember { mutableStateOf("") }
    var isPlacingOrder by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "SECURE PREMIUM CHECKOUT",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Checkout Phone Verification Block
        if (user != null && !user!!.phoneVerified) {
            // Case B: Google user with phoneVerified = false
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = LiorisLightGrey),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.5.dp, LiorisGoldDark)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VERIFY YOUR PHONE NUMBER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "To complete your secure premium purchase, please verify and link your phone number.",
                        fontSize = 11.sp,
                        color = LiorisDarkGrey,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = chPhone,
                        onValueChange = { if (it.length <= 15) viewModel.checkoutPhone.value = it },
                        label = { Text("10-Digit Phone Number", fontSize = 11.sp) },
                        prefix = { Text("+91 ", fontWeight = FontWeight.Bold) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGoldDark),
                        enabled = !isChOtpSent && !isSendingChOtp
                    )

                    if (isChOtpSent) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = chOtp,
                            onValueChange = { if (it.length <= 6) viewModel.checkoutOtp.value = it },
                            label = { Text("6-Digit OTP", fontSize = 11.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGoldDark),
                            enabled = !isVerifyingChOtp
                        )
                    }

                    if (chOtpError.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = chOtpError, color = LiorisError, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }

                    if (chOtpSuccess.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = chOtpSuccess, color = LiorisGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isChOtpSent) {
                        Button(
                            onClick = { viewModel.sendCheckoutOtp() },
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                            enabled = !isSendingChOtp
                        ) {
                            if (isSendingChOtp) {
                                CircularProgressIndicator(color = LiorisWhite, modifier = Modifier.size(18.dp))
                            } else {
                                Text("SEND VERIFICATION CODE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = { viewModel.verifyCheckoutOtp() },
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                            enabled = !isVerifyingChOtp
                        ) {
                            if (isVerifyingChOtp) {
                                CircularProgressIndicator(color = LiorisWhite, modifier = Modifier.size(18.dp))
                            } else {
                                Text("VERIFY & LINK PHONE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (chOtpCooldown > 0) "Resend OTP in ${chOtpCooldown}s" else "Didn't receive OTP?",
                                fontSize = 11.sp,
                                color = LiorisDarkGrey
                            )
                            TextButton(
                                onClick = { viewModel.sendCheckoutOtp() },
                                enabled = chOtpCooldown == 0 && !isSendingChOtp,
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = "RESEND",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (chOtpCooldown == 0) LiorisGoldDark else Color.Gray,
                                    textDecoration = TextDecoration.Underline
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Case A: Already verified phone login or linked Google login
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = LiorisLightGrey),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Filled.CheckCircle, contentDescription = "Verified", tint = LiorisGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("VERIFIED PURCHASE PHONE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LiorisDarkGrey)
                        val rawPhone = user?.phone ?: ""
                        val cleanPhone = rawPhone.filter { it.isDigit() }
                        val displayText = if (cleanPhone.length >= 10) {
                            "Verified Phone: +91 XXXXXXX${cleanPhone.takeLast(3)}"
                        } else {
                            "Verified Phone: +91 $rawPhone"
                        }
                        Text(displayText, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                    }
                }
            }
        }

        // 1. Shipping Address Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("1. DELIVERY ADDRESS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { viewModel.checkoutName.value = it },
                    label = { Text("Customer Full Name *", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("checkout_name_input"),
                    shape = RoundedCornerShape(2.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { viewModel.checkoutAddress.value = it },
                    label = { Text("Flat/Street/Full Address *", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("checkout_address_input"),
                    shape = RoundedCornerShape(2.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pincode,
                        onValueChange = { if (it.length <= 6) viewModel.checkoutPincode.value = it },
                        label = { Text("Pincode *", fontSize = 11.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("checkout_pincode_input"),
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                    )
                    OutlinedTextField(
                        value = city,
                        onValueChange = { viewModel.checkoutCity.value = it },
                        label = { Text("City *", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("checkout_city_input"),
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = state,
                        onValueChange = { viewModel.checkoutState.value = it },
                        label = { Text("State *", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                    )
                    OutlinedTextField(
                        value = landmark,
                        onValueChange = { viewModel.checkoutLandmark.value = it },
                        label = { Text("Landmark", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                    )
                }
            }
        }

        // 2. Coupons & Wallet Offers Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("2. PROMOS & OFFERS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(12.dp))

                // Wallet balance apply checkbox
                val userBalance = user?.walletBalance ?: 0.0
                if (userBalance > 0.0) {
                    val maxWalletDeduction = viewModel.getWalletAmountUsed()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisLightGrey)
                            .padding(10.dp)
                            .clickable { viewModel.useWallet.value = !useWallet },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = useWallet,
                            onCheckedChange = { viewModel.useWallet.value = it },
                            colors = CheckboxDefaults.colors(checkedColor = LiorisGoldDark)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "Use Lioris Wallet Balance",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisBlack
                            )
                            Text(
                                text = "Available: ₹${userBalance.toInt()} | Deduct: ₹${maxWalletDeduction.toInt()} (max 50%)",
                                fontSize = 10.sp,
                                color = LiorisGoldDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Coupon inputs
                if (appliedCoupon == null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = couponCodeInput,
                            onValueChange = { couponCodeInput = it.uppercase() },
                            placeholder = { Text("Coupon Code (WELCOME50)", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("coupon_input"),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                        )
                        Button(
                            onClick = {
                                viewModel.applyCoupon(couponCodeInput)
                                couponCodeInput = ""
                            },
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                        ) {
                            Text("APPLY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (couponError.isNotEmpty()) {
                        Text(
                            text = couponError,
                            color = LiorisError,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(top = 4.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisGoldLight)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Filled.LocalOffer, contentDescription = "Coupon Applied", tint = LiorisGoldDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "COUPON ${appliedCoupon!!.code} APPLIED",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = LiorisBlack
                                )
                                Text(
                                    text = "Discount value: ₹${viewModel.getCouponDiscount().toInt()}",
                                    fontSize = 9.sp,
                                    color = LiorisDarkGrey
                                )
                            }
                        }
                        IconButton(onClick = { viewModel.removeCoupon() }) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Remove")
                        }
                    }
                }
            }
        }

        // 3. Payment Method Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("3. CHOOSE PAYMENT METHOD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(12.dp))

                // Cash on Delivery Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.checkoutPaymentMethod.value = "COD" }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = paymentMethod == "COD",
                        onClick = { viewModel.checkoutPaymentMethod.value = "COD" },
                        colors = RadioButtonDefaults.colors(selectedColor = LiorisGoldDark)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Cash On Delivery (COD)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Pay in cash when you receive package", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                if (paymentMethod == "COD" && settings.codAdvanceEnabled) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisLightGrey)
                            .padding(12.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "PAY ₹${settings.codAdvanceAmount.toInt()} COD ADVANCE TO SECURE ORDER:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisGoldDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Transfer exactly ₹${settings.codAdvanceAmount.toInt()} to UPI ID:",
                                fontSize = 10.sp,
                                color = LiorisBlack
                            )
                            Text(
                                text = settings.upiId,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisGoldDark,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )

                            val qrUrl = settings.qrImage.ifEmpty { "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${settings.upiId}%26pn=Lioris%26am=${settings.codAdvanceAmount}" }
                            AsyncImage(
                                model = qrUrl,
                                contentDescription = "COD Advance QR Code",
                                modifier = Modifier
                                    .size(150.dp)
                                    .padding(8.dp),
                                contentScale = ContentScale.Fit
                            )

                            Text(
                                text = "Scan QR or use UPI ID. Submit the 12-digit UTR of your ₹${settings.codAdvanceAmount.toInt()} payment below.",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = utr,
                                onValueChange = { viewModel.checkoutUtr.value = it },
                                label = { Text("Enter 12-Digit COD Advance UTR *", fontSize = 11.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth().testTag("cod_advance_utr_input"),
                                shape = RoundedCornerShape(2.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                            )
                        }
                    }
                }

                Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 6.dp))

                // UPI Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.checkoutPaymentMethod.value = "UPI" }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = paymentMethod == "UPI",
                        onClick = { viewModel.checkoutPaymentMethod.value = "UPI" },
                        colors = RadioButtonDefaults.colors(selectedColor = LiorisGoldDark)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Instant UPI Transfer (QR / Wallet)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Pay manually to our UPI ID and submit UTR code", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                // If UPI chosen, show QR and UPI info
                if (paymentMethod == "UPI") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisLightGrey)
                            .padding(12.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "TRANSFER EXACT PAYABLE TO UPI:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisBlack
                            )
                            Text(
                                text = settings.upiId,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiorisGoldDark,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )

                            // QR Image placeholder / dynamic image
                            val qrUrl = settings.qrImage.ifEmpty { "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${settings.upiId}%26pn=Lioris%26am=${viewModel.getFinalPayableAmount()}" }
                            AsyncImage(
                                model = qrUrl,
                                contentDescription = "UPI Payment QR Code",
                                modifier = Modifier
                                    .size(150.dp)
                                    .padding(8.dp),
                                contentScale = ContentScale.Fit
                            )

                            Text(
                                text = "Scan QR or copy UPI ID to transfer using PhonePe, GPay, Paytm.",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Input UTR/Txn code
                            OutlinedTextField(
                                value = utr,
                                onValueChange = { viewModel.checkoutUtr.value = it },
                                label = { Text("Enter 12-Digit UPI Transaction ID (UTR) *", fontSize = 11.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth().testTag("utr_input"),
                                shape = RoundedCornerShape(2.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = LiorisGold)
                            )
                        }
                    }
                }

                Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 6.dp))

                // Online Card Payment
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.checkoutPaymentMethod.value = "Online" }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = paymentMethod == "Online",
                        onClick = { viewModel.checkoutPaymentMethod.value = "Online" },
                        colors = RadioButtonDefaults.colors(selectedColor = LiorisGoldDark)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Online Payment (Razorpay / Cards)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Debit/Credit Card, Netbanking, Net Wallets", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                if (paymentMethod == "Online") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisLightGrey)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Online card transactions coming soon! Please use Cash On Delivery or UPI transfer.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisWarning
                        )
                    }
                }
            }
        }

        // 4. Checkout Order Summary
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ORDER PRICE SUMMARY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Items Subtotal", fontSize = 12.sp, color = LiorisDarkGrey)
                    Text("₹${viewModel.getCartSubtotal().toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Delivery Shipping Fee", fontSize = 12.sp, color = LiorisDarkGrey)
                    Text(if (viewModel.getDeliveryCharge() == 0.0) "FREE" else "₹${viewModel.getDeliveryCharge().toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                val couponDisc = viewModel.getCouponDiscount()
                if (couponDisc > 0.0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Coupon Discount applied", fontSize = 12.sp, color = LiorisGreen)
                        Text("-₹${couponDisc.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisGreen)
                    }
                }

                val walletUsed = viewModel.getWalletAmountUsed()
                if (walletUsed > 0.0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Wallet Money applied", fontSize = 12.sp, color = LiorisGoldDark)
                        Text("-₹${walletUsed.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                    }
                }

                // If eligible free gift, list it here!
                if (viewModel.isGiftUnlocked()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("🎁 Free Gift included", fontSize = 12.sp, color = LiorisGreen, fontWeight = FontWeight.Bold)
                        Text(viewModel.getGiftItemName(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisGreen)
                    }
                }

                if (paymentMethod == "COD" && settings.codAdvanceEnabled) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("COD Advance paid now", fontSize = 12.sp, color = LiorisGoldDark)
                        Text("-₹${settings.codAdvanceAmount.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                    }
                }

                Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Final Payable Amount", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("₹${viewModel.getFinalPayableAmount().toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                }
            }
        }

        // Place Order Submit Button
        Button(
            onClick = {
                isPlacingOrder = true
                viewModel.checkoutPlaceOrder(
                    onSuccess = { completedId ->
                        isPlacingOrder = false
                        viewModel.navigateTo(Screen.OrderSuccess(completedId), clearStack = true)
                    },
                    onFailure = { errorMsg ->
                        isPlacingOrder = false
                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                    }
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("place_order_btn"),
            shape = RoundedCornerShape(2.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
            enabled = !isPlacingOrder && (user?.phoneVerified == true) && paymentMethod != "Online"
        ) {
            if (isPlacingOrder) {
                CircularProgressIndicator(color = LiorisWhite, modifier = Modifier.size(20.dp))
            } else if (user?.phoneVerified != true) {
                Text("VERIFY PHONE NUMBER TO ORDER", fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp)
            } else {
                Text("PLACE ORDER NOW", fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp)
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 6. ORDER SUCCESS CONFETTI PAGE
// ==========================================
@Composable
fun OrderSuccessScreen(orderId: String, viewModel: LiorisViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiorisWhite)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Confetti effect overlay
        ConfettiOverlay(modifier = Modifier.fillMaxWidth().height(250.dp))

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .size(72.dp)
                .background(LiorisGoldLight, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = "Success",
                tint = LiorisGoldDark,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "ORDER PLACED SUCCESSFULLY!",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center
        )

        Text(
            text = "Thank you for shopping with LIORIS.",
            color = LiorisGoldDark,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Text(
            text = "Order ID: $orderId\nOur team is working on preparing your elegant parcel. You can track status inside Orders tab.",
            color = LiorisDarkGrey,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { viewModel.navigateTo(Screen.Home, clearStack = true) },
            shape = RoundedCornerShape(2.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
            modifier = Modifier.fillMaxWidth().height(46.dp)
        ) {
            Text("CONTINUE SHOPPING", fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = { viewModel.navigateTo(Screen.Orders, clearStack = true) },
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.fillMaxWidth().height(46.dp),
            border = BorderStroke(1.dp, LiorisBlack),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = LiorisBlack)
        ) {
            Text("VIEW ORDER HISTORIES", fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
        }
    }
}

// ==========================================
// 7. USER ORDERS LIST & STATUS TIMELINE TRACKING
// ==========================================
@Composable
fun OrdersScreen(viewModel: LiorisViewModel) {
    val orders by viewModel.userOrders.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedOrderForReturn by remember { mutableStateOf<Order?>(null) }
    var returnReasonText by remember { mutableStateOf("") }

    if (selectedOrderForReturn != null) {
        AlertDialog(
            onDismissRequest = {
                selectedOrderForReturn = null
                returnReasonText = ""
            },
            title = {
                Text(
                    text = "REQUEST SECURE RETURN",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "You are requesting a return for Order ${selectedOrderForReturn?.orderId}. Please specify the reason for return below:",
                        fontSize = 11.sp,
                        color = LiorisDarkGrey,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    OutlinedTextField(
                        value = returnReasonText,
                        onValueChange = { returnReasonText = it },
                        placeholder = { Text("e.g. Size didn't fit / Wrong color delivered", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LiorisGoldDark,
                            unfocusedBorderColor = Color.LightGray
                        ),
                        shape = RoundedCornerShape(2.dp),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ordId = selectedOrderForReturn?.orderId ?: ""
                        if (returnReasonText.trim().isEmpty()) {
                            Toast.makeText(context, "Please enter a valid reason.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.submitReturnRequest(
                            orderId = ordId,
                            reason = returnReasonText.trim(),
                            onSuccess = {
                                Toast.makeText(context, "Return request submitted successfully!", Toast.LENGTH_LONG).show()
                                selectedOrderForReturn = null
                                returnReasonText = ""
                            },
                            onFailure = { err ->
                                Toast.makeText(context, "Error: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("SUBMIT REQUEST", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisGold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        selectedOrderForReturn = null
                        returnReasonText = ""
                    }
                ) {
                    Text("CANCEL", color = Color.Gray, fontSize = 11.sp)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    if (orders.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.ListAlt,
                contentDescription = "No orders",
                tint = Color.LightGray,
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text("NO ORDER HISTORY FOUND", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "Once you place orders with Lioris, they will appear here with fully automated tracking details.",
                color = LiorisDarkGrey,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "YOUR ORDER HISTORIES",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        orders.forEach { order ->
            val parsedItems = LiorisRepository.jsonToCartItems(order.itemsJson)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { viewModel.navigateTo(Screen.TrackOrder(order.orderId)) },
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Order ID: ${order.orderId}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisBlack
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    color = when (order.status) {
                                        "Delivered" -> LiorisGoldLight
                                        "Cancelled" -> LiorisGoldLight
                                        else -> LiorisGoldLight
                                    },
                                    shape = RoundedCornerShape(2.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = order.status.uppercase(),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (order.status) {
                                    "Delivered" -> LiorisGreen
                                    "Cancelled" -> LiorisError
                                    else -> LiorisGoldDark
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    parsedItems.forEach { item ->
                        Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = item.imageUrl,
                                contentDescription = item.productName,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${item.productName} (x${item.quantity})",
                                fontSize = 11.sp,
                                color = LiorisDarkGrey,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    if (order.giftUnlocked) {
                        Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Filled.CardGiftcard, contentDescription = "Gift", tint = LiorisGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Free Gift: ${order.giftItem}",
                                fontSize = 11.sp,
                                color = LiorisGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Amount Paid: ₹${order.finalPayable.toInt()}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisBlack
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            if (order.status == "Delivered") {
                                Text(
                                    text = "REQUEST RETURN",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = LiorisError,
                                    textDecoration = TextDecoration.Underline,
                                    modifier = Modifier.clickable {
                                        selectedOrderForReturn = order
                                    }
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "TRACK SHIPMENT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = LiorisGoldDark,
                                    textDecoration = TextDecoration.Underline
                                )
                                Icon(imageVector = Icons.Filled.ChevronRight, contentDescription = "Track", tint = LiorisGoldDark, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun TrackOrderScreen(orderId: String, viewModel: LiorisViewModel) {
    val orderFlow = remember(orderId) { viewModel.observeOrderFlow(orderId) }
    val order by orderFlow.collectAsState(initial = null)

    val context = LocalContext.current

    if (order == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Loading tracking details...")
        }
        return
    }

    val currentOrder = order!!
    val parsedItems = LiorisRepository.jsonToCartItems(currentOrder.itemsJson)

    // Build timeline progress mapping
    val statuses = listOf("Pending", "Accepted", "Packed", "Shipped", "Out for Delivery", "Delivered")
    val currentIndex = statuses.indexOf(currentOrder.status)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "TRACK SHIPMENT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Order ID: $orderId | Date: ${SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(currentOrder.createdAt))}",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Timeline Rendering
                statuses.forEachIndexed { index, status ->
                    val isCompleted = index <= currentIndex
                    val isCurrent = index == currentIndex

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Dot
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(
                                    color = if (isCompleted) LiorisGoldDark else Color.LightGray,
                                    shape = CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = status.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                color = if (isCompleted) LiorisBlack else Color.Gray,
                                letterSpacing = 0.5.sp
                            )
                            if (isCurrent) {
                                Text(
                                    text = "Active - Parcel is processed at this phase",
                                    fontSize = 9.sp,
                                    color = LiorisGoldDark
                                )
                            }
                        }
                    }

                    // Connecting vertical line
                    if (index < statuses.lastIndex) {
                        Box(
                            modifier = Modifier
                                .padding(start = 6.dp)
                                .width(2.dp)
                                .height(20.dp)
                                .background(if (index < currentIndex) LiorisGoldDark else Color.LightGray)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Status Badge Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ORDER STATUS DETAILS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Order Status:", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = currentOrder.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (currentOrder.status) {
                            "COD Advance Paid Pending Verification" -> LiorisGoldDark
                            "Payment Verification Pending" -> LiorisGoldDark
                            "Cancelled" -> Color.Red
                            "Delivered" -> LiorisGreen
                            else -> LiorisBlack
                        }
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Payment Status:", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = currentOrder.paymentStatus,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (currentOrder.paymentStatus) {
                            "COD Advance Paid Pending Verification" -> LiorisGoldDark
                            "Payment Verification Pending" -> LiorisGoldDark
                            "Failed" -> Color.Red
                            "Verified" -> LiorisGreen
                            else -> LiorisBlack
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Items and invoice card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ORDER DETAIL INVOICE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                Spacer(modifier = Modifier.height(12.dp))

                parsedItems.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${item.productName} (x${item.quantity})", fontSize = 11.sp, color = LiorisDarkGrey)
                        Text("₹${(item.price * item.quantity).toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (currentOrder.giftUnlocked) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("🎁 Free Gift: ${currentOrder.giftItem}", fontSize = 11.sp, color = LiorisGreen, fontWeight = FontWeight.Bold)
                        Text("FREE", fontSize = 11.sp, color = LiorisGreen, fontWeight = FontWeight.Bold)
                    }
                }

                Divider(color = LiorisLightGrey, modifier = Modifier.padding(vertical = 12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Payment Mode", fontSize = 11.sp, color = Color.Gray)
                    Text(currentOrder.paymentMethod, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                if (currentOrder.paymentMethod == "UPI" && currentOrder.utr.isNotEmpty()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("UPI UTR Code", fontSize = 11.sp, color = Color.Gray)
                        Text(currentOrder.utr, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                    }
                }

                if (currentOrder.advancePaid > 0.0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("COD Advance Paid", fontSize = 11.sp, color = Color.Gray)
                        Text("₹${currentOrder.advancePaid.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisGreen)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("COD Advance UTR", fontSize = 11.sp, color = Color.Gray)
                        Text(currentOrder.advanceUtr, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisGoldDark)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Price Paid", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("₹${currentOrder.finalPayable.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = LiorisBlack)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // WhatsApp Support Help Button
                Button(
                    onClick = {
                        openSupportWhatsApp(
                            context = context,
                            number = "7252083788",
                            query = "Hello support, I want help regarding my LIORIS order ID: ${currentOrder.orderId}."
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisGreen),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("WHATSAPP CUSTOMER HELPDESK", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// Extension function inside LiorisViewModel to easily observe a single order
fun LiorisViewModel.observeOrderFlow(orderId: String): Flow<Order?> {
    return db.dao().observeOrderById(orderId)
}

// ==========================================
// 8. WALLET DASHBOARD SYSTEM
// ==========================================
@Composable
fun WalletScreen(viewModel: LiorisViewModel) {
    val user by viewModel.loggedInUser.collectAsStateWithLifecycle()
    val transactions by viewModel.userTransactions.collectAsStateWithLifecycle()

    val shownTransactions = remember(transactions, user) {
        if (transactions.isEmpty() && (user?.walletBalance ?: 0.0) == 50.0) {
            listOf(
                com.example.data.WalletTransaction(
                    transactionId = "WT_WELCOME_INIT",
                    userId = user?.phone ?: "",
                    phone = user?.phone ?: "",
                    type = "CREDIT",
                    amount = 50.0,
                    reason = "Welcome Bonus",
                    createdAt = user?.createdAt ?: System.currentTimeMillis()
                )
            )
        } else {
            transactions
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "LIORIS WALLET LEDGER",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Balance Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisBlack),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "AVAILABLE BALANCE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisGold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "₹${(user?.walletBalance ?: 0.0).toInt()}",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisWhite,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Text(
                    text = "Use this balance to purchase luxury items. Max 50% discount per order.",
                    fontSize = 10.sp,
                    color = LiorisMediumGrey,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Wallet rules list
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("LIORIS WALLET PRIVILEGES & RULES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))

                val rules = listOf(
                    "🎉 New Member gets a ₹50 Welcome Bonus automatically.",
                    "🤝 Refer friends and get ₹50 when they make their first purchase.",
                    "🛍️ Wallet cash can be applied up to 50% of the shopping subtotal.",
                    "❌ Wallet cash cannot be withdrawn to any external bank accounts."
                )

                rules.forEach { rule ->
                    Text(
                        text = rule,
                        fontSize = 11.sp,
                        color = LiorisDarkGrey,
                        modifier = Modifier.padding(vertical = 4.dp),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Transaction History List
        Text(
            text = "TRANSACTION HISTORIES",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisBlack,
            letterSpacing = 0.5.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        if (shownTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LiorisWhite)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No transactions logged yet.", fontSize = 12.sp, color = Color.Gray)
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    shownTransactions.forEach { txn ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = txn.reason,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = LiorisBlack
                                )
                                Text(
                                    text = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(txn.createdAt)),
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                            Text(
                                text = if (txn.type == "CREDIT") "+₹${txn.amount.toInt()}" else "-₹${txn.amount.toInt()}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (txn.type == "CREDIT") LiorisGreen else LiorisError
                            )
                        }
                        Divider(color = LiorisLightGrey)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

// ==========================================
// 9. PROFILE & ADMIN PORTAL REDIRECT
// ==========================================
@Composable
fun ProfileScreen(viewModel: LiorisViewModel) {
    val user by viewModel.loggedInUser.collectAsStateWithLifecycle()
    val settings by viewModel.storeSettings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var showAddressEditDialog by remember { mutableStateOf(false) }
    var showProfileVerifyDialog by remember { mutableStateOf(false) }
    var showBenefitsDialog by remember { mutableStateOf(false) }

    val checkoutPhone by viewModel.checkoutPhone.collectAsStateWithLifecycle()
    val checkoutOtp by viewModel.checkoutOtp.collectAsStateWithLifecycle()
    val isOtpSent by viewModel.isCheckoutOtpSent.collectAsStateWithLifecycle()
    val isSending by viewModel.isSendingCheckoutOtp.collectAsStateWithLifecycle()
    val isVerifying by viewModel.isVerifyingCheckoutOtp.collectAsStateWithLifecycle()
    val otpError by viewModel.checkoutOtpError.collectAsStateWithLifecycle()
    val otpSuccess by viewModel.checkoutOtpSuccess.collectAsStateWithLifecycle()

    val currentUser = user

    if (currentUser == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Button(onClick = { viewModel.navigateTo(Screen.Login) }) {
                Text("Login to view profile")
            }
        }
        return
    }

    var addressInput by remember(currentUser.savedAddress) { mutableStateOf(currentUser.savedAddress) }

    if (showAddressEditDialog) {
        AlertDialog(
            onDismissRequest = { showAddressEditDialog = false },
            title = {
                Text(
                    text = "EDIT SAVED ADDRESS",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter your primary shipping address below. This will be pre-filled during checkout.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        placeholder = { Text("Flat/House No, Building, Street, City, State - Pincode") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4,
                        shape = RoundedCornerShape(2.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LiorisGoldDark,
                            unfocusedBorderColor = LiorisMediumGrey
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.updateSavedAddress(addressInput.trim())
                        showAddressEditDialog = false
                    }
                ) {
                    Text("SAVE ADDRESS", color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddressEditDialog = false }) {
                    Text("CANCEL", color = Color.Gray, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    if (showProfileVerifyDialog) {
        AlertDialog(
            onDismissRequest = { 
                showProfileVerifyDialog = false
                viewModel.checkoutOtpError.value = ""
                viewModel.checkoutOtpSuccess.value = ""
            },
            title = {
                Text(
                    text = "LINK & VERIFY PHONE",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "To access all premium features and secure your account, please verify your mobile number.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    if (!isOtpSent) {
                        OutlinedTextField(
                            value = checkoutPhone,
                            onValueChange = { if (it.length <= 10) viewModel.checkoutPhone.value = it },
                            label = { Text("Phone Number", fontSize = 12.sp) },
                            placeholder = { Text("9999999999") },
                            prefix = { Text("+91 ", fontWeight = FontWeight.Bold) },
                            singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LiorisGoldDark,
                                unfocusedBorderColor = LiorisMediumGrey
                            ),
                            enabled = !isSending
                        )
                    } else {
                        Text(
                            text = "OTP sent to +91 $checkoutPhone",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LiorisGreen,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedTextField(
                            value = checkoutOtp,
                            onValueChange = { if (it.length <= 6) viewModel.checkoutOtp.value = it },
                            label = { Text("6-Digit OTP", fontSize = 12.sp) },
                            placeholder = { Text("123456") },
                            singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LiorisGoldDark,
                                unfocusedBorderColor = LiorisMediumGrey
                            ),
                            enabled = !isVerifying
                        )
                    }

                    if (otpError.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = otpError, color = LiorisError, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                    if (otpSuccess.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = otpSuccess, color = LiorisGreen, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (!isOtpSent) {
                            viewModel.sendCheckoutOtp()
                        } else {
                            viewModel.verifyCheckoutOtp(onVerified = {
                                showProfileVerifyDialog = false
                            })
                        }
                    },
                    enabled = !isSending && !isVerifying
                ) {
                    val btnText = if (!isOtpSent) {
                        if (isSending) "SENDING..." else "SEND OTP"
                    } else {
                        if (isVerifying) "VERIFYING..." else "VERIFY & LINK"
                    }
                    Text(btnText, color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { 
                        showProfileVerifyDialog = false
                        viewModel.checkoutOtpError.value = ""
                        viewModel.checkoutOtpSuccess.value = ""
                    }
                ) {
                    Text("CANCEL", color = Color.Gray, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    if (showBenefitsDialog) {
        AlertDialog(
            onDismissRequest = { showBenefitsDialog = false },
            title = {
                Text(
                    text = "MEMBERSHIP BENEFITS",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Unlock higher loyalty levels by placing more orders. Each tier offers unique premium perks!",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisLightGrey)
                            .padding(12.dp)
                    ) {
                        Text("🏆 NEW MEMBER TIER", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = LiorisBlack)
                        Text("• Active immediately on signup\n• ₹50 Welcome Wallet Bonus (Usable up to 50% on order)\n• Standard Support desk access", fontSize = 11.sp, color = LiorisDarkGrey)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisGoldLight)
                            .padding(12.dp)
                    ) {
                        Text("🥈 SILVER MEMBER TIER", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = LiorisGoldDark)
                        Text("• Unlock after 3 completed orders\n• 2% Cash Wallet Back on all future purchases\n• Silver exclusive coupon codes", fontSize = 11.sp, color = LiorisDarkGrey)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiorisBlack)
                            .padding(12.dp)
                    ) {
                        Text("✨ GOLD MEMBER TIER (PREMIUM)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = LiorisGold)
                        Text("• Unlock after 8 completed orders\n• 5% Cash Wallet Back on all future purchases\n• Free express shipping on all orders\n• Direct executive WhatsApp Support", fontSize = 11.sp, color = Color.LightGray)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBenefitsDialog = false }) {
                    Text("CLOSE", color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LiorisWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // User Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(LiorisGoldLight, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Filled.Person, contentDescription = "Profile", tint = LiorisGoldDark, modifier = Modifier.size(36.dp))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(currentUser.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = LiorisBlack)
                
                val isGoogleUnverified = currentUser.phone.startsWith("GOOGLE_UNVERIFIED_")
                if (isGoogleUnverified) {
                    Text("Phone not verified yet", fontSize = 12.sp, color = LiorisError, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = { showProfileVerifyDialog = true },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Text("VERIFY PHONE", fontSize = 11.sp, color = LiorisGoldDark, fontWeight = FontWeight.Bold, textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline)
                    }
                } else {
                    Text("+91 ${currentUser.phone}", fontSize = 12.sp, color = Color.Gray)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Loyalty Level Badge (Clickable to Membership Benefits Dialog)
                Box(
                    modifier = Modifier
                        .background(LiorisGoldLight, RoundedCornerShape(4.dp))
                        .clickable { showBenefitsDialog = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "🏆 ${currentUser.loyaltyLevel.uppercase()} LEVEL",
                        color = LiorisGoldDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Wallet Balance Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisBlack),
            shape = RoundedCornerShape(4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("LIORIS WALLET BALANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisGoldLight, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("₹${currentUser.walletBalance.toInt()}", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = LiorisWhite)
                }
                Icon(
                    imageVector = Icons.Filled.AccountBalanceWallet,
                    contentDescription = "Wallet",
                    tint = LiorisGold,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Referral Sharing Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("SHARE & EARN REWARDS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiorisBlack, letterSpacing = 1.sp)
                Text("Invite friends. When they place their first order, you instantly receive ₹50 wallet credit!", fontSize = 11.sp, color = LiorisDarkGrey, modifier = Modifier.padding(vertical = 4.dp))

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(LiorisLightGrey)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CODE: ${currentUser.referralCode}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack
                    )
                    TextButton(onClick = {
                        clipboardManager.setText(AnnotatedString(currentUser.referralCode))
                        Toast.makeText(context, "Referral Code Copied!", Toast.LENGTH_SHORT).show()
                    }) {
                        Text("COPY", color = LiorisGoldDark, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        val shareMsg = "Hey! Use my LIORIS referral code '${currentUser.referralCode}' during signup to discover premium collection and receive ₹50 welcome wallet bonus instantly!"
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(shareMsg))
                        }
                        context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LiorisBlack)
                ) {
                    Icon(imageVector = Icons.Filled.Share, contentDescription = "Share Referral")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SHARE VIA WHATSAPP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Profile Menu Items List
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LiorisWhite),
            shape = RoundedCornerShape(4.dp),
            border = BorderStroke(1.dp, LiorisLightGrey)
        ) {
            Column {
                ProfileMenuRow(
                    icon = Icons.Outlined.ListAlt,
                    title = "My Orders",
                    subtitle = "Track and view previous purchases",
                    onClick = { viewModel.navigateTo(Screen.Orders) }
                )
                Divider(color = LiorisLightGrey)
                ProfileMenuRow(
                    icon = Icons.Outlined.ShoppingBag,
                    title = "My Cart",
                    subtitle = "Checkout your selected products",
                    onClick = { viewModel.navigateTo(Screen.Cart) }
                )
                Divider(color = LiorisLightGrey)
                ProfileMenuRow(
                    icon = Icons.Outlined.AccountBalanceWallet,
                    title = "My Wallet",
                    subtitle = "Current Balance: ₹${currentUser.walletBalance.toInt()}",
                    onClick = { viewModel.navigateTo(Screen.Wallet) }
                )
                Divider(color = LiorisLightGrey)
                ProfileMenuRow(
                    icon = Icons.Outlined.Home,
                    title = "Saved Address",
                    subtitle = currentUser.savedAddress.ifEmpty { "No address saved. Click to add." },
                    onClick = { showAddressEditDialog = true }
                )
                Divider(color = LiorisLightGrey)
                ProfileMenuRow(
                    icon = Icons.Outlined.SupportAgent,
                    title = "Support Desk",
                    subtitle = "Chat with us via WhatsApp support",
                    onClick = {
                        openSupportWhatsApp(
                            context = context,
                            number = "7252083788",
                            query = "Hello LIORIS support, I need help with my account."
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Admin Entry gate button (ONLY for admin phone)
        if (currentUser.phone == "7252083788") {
            Button(
                onClick = { viewModel.navigateTo(Screen.AdminDashboard) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("admin_panel_btn"),
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiorisGoldDark)
            ) {
                Icon(imageVector = Icons.Filled.AdminPanelSettings, contentDescription = "Admin")
                Spacer(modifier = Modifier.width(8.dp))
                Text("OPEN ADMIN CONTROL PANEL", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Logout
        OutlinedButton(
            onClick = { viewModel.logout() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = LiorisError),
            border = BorderStroke(1.dp, LiorisError),
            shape = RoundedCornerShape(2.dp)
        ) {
            Text("LOG OUT SECURELY", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun ProfileMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = LiorisGoldDark,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisBlack
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.Gray,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = "Go",
            tint = Color.LightGray,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun NotificationsScreen(viewModel: LiorisViewModel) {
    val notifications by viewModel.userNotifications.collectAsStateWithLifecycle()

    // Mark all notifications as read when entering this screen
    LaunchedEffect(Unit) {
        viewModel.markAllNotificationsAsRead()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiorisLightGrey)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = LiorisBlack
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "INBOX NOTIFICATIONS",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = LiorisBlack,
                letterSpacing = 1.sp
            )
        }

        if (notifications.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 100.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.NotificationsActive,
                    contentDescription = "No Notifications",
                    tint = Color.LightGray,
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "YOUR INBOX IS VACANT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Any exclusive offers, wallet updates, or order status notifications will appear here.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp),
                    lineHeight = 16.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                lazyItems(notifications) { notif ->
                    val icon = remember(notif.title) {
                        val t = notif.title.lowercase()
                        val m = notif.message.lowercase()
                        when {
                            t.contains("wallet") || m.contains("wallet") || t.contains("bonus") || m.contains("bonus") || t.contains("credit") || m.contains("credit") -> Icons.Outlined.Wallet
                            t.contains("order") || m.contains("order") || t.contains("delivery") || m.contains("delivery") || t.contains("shipped") || m.contains("shipped") -> Icons.Outlined.ShoppingBag
                            t.contains("offer") || m.contains("offer") || t.contains("discount") || m.contains("discount") || t.contains("promo") || m.contains("promo") -> Icons.Outlined.LocalActivity
                            else -> Icons.Outlined.Info
                        }
                    }

                    val dateStr = remember(notif.createdAt) {
                        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(notif.createdAt))
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = LiorisWhite),
                        shape = RoundedCornerShape(2.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(LiorisGoldLight, RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = "Notification Icon",
                                    tint = LiorisGoldDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = notif.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = LiorisBlack
                                    )
                                    if (!notif.read) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(LiorisGoldDark, RoundedCornerShape(3.dp))
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = notif.message,
                                    fontSize = 11.sp,
                                    color = LiorisDarkGrey,
                                    lineHeight = 16.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = dateStr,
                                    fontSize = 9.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
