package com.example

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    var startUrl = "http://10.0.2.2:5173"
    val dataUri = intent?.data
    if (dataUri != null) {
      val path = dataUri.path
      if (!path.isNullOrEmpty()) {
        startUrl = "http://10.0.2.2:5173$path"
      }
    }

    setContent {
      AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
          WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            
            webViewClient = object : WebViewClient() {
              @Deprecated("Deprecated in Java")
              override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
              ) {
                if (failingUrl?.contains("10.0.2.2") == true) {
                  val fallbackPath = failingUrl.substringAfter("10.0.2.2:5173").replace("/", "")
                  view?.loadUrl("https://ais-dev-2tefi7bdpmyxjj56lm5jk5-674064215943.asia-southeast1.run.app/$fallbackPath")
                }
              }

              @Deprecated("Deprecated in Java")
              override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null) {
                  view?.loadUrl(url)
                }
                return true
              }
            }
            
            loadUrl(startUrl)
            
            // Safety fallback if localhost loading takes too long/hangs
            postDelayed({
              if (progress < 15) {
                val currentUrl = url ?: ""
                val fallbackPath = if (currentUrl.contains("10.0.2.2:5173")) {
                  currentUrl.substringAfter("10.0.2.2:5173").replace("/", "")
                } else {
                  ""
                }
                loadUrl("https://ais-dev-2tefi7bdpmyxjj56lm5jk5-674064215943.asia-southeast1.run.app/$fallbackPath")
              }
            }, 2500)
          }
        }
      )
    }
  }

  override fun onNewIntent(intent: android.content.Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
  }
}

