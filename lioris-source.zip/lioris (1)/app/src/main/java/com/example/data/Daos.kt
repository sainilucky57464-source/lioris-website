package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LiorisDao {

    // --- Users ---
    @Query("SELECT * FROM users WHERE phone = :phone LIMIT 1")
    suspend fun getUserByPhone(phone: String): User?

    @Query("SELECT * FROM users WHERE phone = :phone LIMIT 1")
    fun observeUserByPhone(phone: String): Flow<User?>

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    // --- Products ---
    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: String): Product?

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    fun observeProductById(id: String): Flow<Product?>

    @Query("SELECT * FROM products WHERE active = 1 ORDER BY createdAt DESC")
    fun getActiveProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products ORDER BY createdAt DESC")
    fun getAllProducts(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteProductById(id: String)

    // --- Orders ---
    @Query("SELECT * FROM orders WHERE orderId = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: String): Order?

    @Query("SELECT * FROM orders WHERE orderId = :orderId LIMIT 1")
    fun observeOrderById(orderId: String): Flow<Order?>

    @Query("SELECT * FROM orders WHERE userId = :userId ORDER BY createdAt DESC")
    fun getOrdersByUserId(userId: String): Flow<List<Order>>

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Update
    suspend fun updateOrder(order: Order)

    // --- Wallet Transactions ---
    @Query("SELECT * FROM wallet_transactions WHERE userId = :userId ORDER BY createdAt DESC")
    fun getWalletTransactionsByUserId(userId: String): Flow<List<WalletTransaction>>

    @Query("SELECT * FROM wallet_transactions ORDER BY createdAt DESC")
    fun getAllWalletTransactions(): Flow<List<WalletTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalletTransaction(transaction: WalletTransaction)

    // --- Coupons ---
    @Query("SELECT * FROM coupons WHERE code = :code LIMIT 1")
    suspend fun getCouponByCode(code: String): Coupon?

    @Query("SELECT * FROM coupons ORDER BY createdAt DESC")
    fun getAllCoupons(): Flow<List<Coupon>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCoupon(coupon: Coupon)

    @Query("DELETE FROM coupons WHERE code = :code")
    suspend fun deleteCouponByCode(code: String)

    // --- Banners ---
    @Query("SELECT * FROM banners WHERE active = 1 ORDER BY sortOrder ASC")
    fun getActiveBanners(): Flow<List<Banner>>

    @Query("SELECT * FROM banners ORDER BY sortOrder ASC")
    fun getAllBanners(): Flow<List<Banner>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanner(banner: Banner)

    @Query("DELETE FROM banners WHERE bannerId = :bannerId")
    suspend fun deleteBannerById(bannerId: String)

    // --- Gift Offers ---
    @Query("SELECT * FROM gift_offers WHERE active = 1")
    fun getActiveGiftOffers(): Flow<List<GiftOffer>>

    @Query("SELECT * FROM gift_offers ORDER BY createdAt DESC")
    fun getAllGiftOffers(): Flow<List<GiftOffer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGiftOffer(offer: GiftOffer)

    @Query("DELETE FROM gift_offers WHERE offerId = :offerId")
    suspend fun deleteGiftOfferById(offerId: String)

    // --- Notifications ---
    @Query("SELECT * FROM notifications WHERE target = 'all' OR phone = :phone ORDER BY createdAt DESC")
    fun getNotificationsForUser(phone: String): Flow<List<Notification>>

    @Query("UPDATE notifications SET `read` = 1 WHERE target = 'all' OR phone = :phone")
    suspend fun markAllNotificationsAsReadForUser(phone: String)

    @Query("SELECT * FROM notifications ORDER BY createdAt DESC")
    fun getAllNotifications(): Flow<List<Notification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: Notification)

    // --- Referrals ---
    @Query("SELECT * FROM referrals WHERE referredPhone = :referredPhone LIMIT 1")
    suspend fun getReferralByReferredPhone(referredPhone: String): Referral?

    @Query("SELECT * FROM referrals ORDER BY createdAt DESC")
    fun getAllReferrals(): Flow<List<Referral>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReferral(referral: Referral)

    @Update
    suspend fun updateReferral(referral: Referral)

    // --- Store Settings ---
    @Query("SELECT * FROM settings WHERE id = 'store' LIMIT 1")
    suspend fun getStoreSettings(): StoreSettings?

    @Query("SELECT * FROM settings WHERE id = 'store' LIMIT 1")
    fun observeStoreSettings(): Flow<StoreSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStoreSettings(settings: StoreSettings)

    // --- Admin Notifications ---
    @Query("SELECT * FROM admin_notifications ORDER BY createdAt DESC")
    fun getAllAdminNotifications(): Flow<List<AdminNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdminNotification(notification: AdminNotification)

    // --- OTP Logs ---
    @Query("SELECT * FROM otp_logs ORDER BY createdAt DESC")
    fun getAllOtpLogs(): Flow<List<OtpLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOtpLog(log: OtpLog)
}
