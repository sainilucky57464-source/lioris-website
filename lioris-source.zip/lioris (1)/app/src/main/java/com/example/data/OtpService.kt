package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object OtpService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Key-value store for active OTP sessions
    // phone -> OtpSession
    private val sessions = mutableMapOf<String, OtpSession>()

    // Track request counts to enforce max 3 OTPs per phone per hour
    private val hourlyRequests = mutableMapOf<String, MutableList<Long>>()

    // Track verification attempts to enforce max 5 attempts per session
    private val verifyAttempts = mutableMapOf<String, Int>()

    data class OtpSession(
        val otp: String,
        val timestamp: Long,
        val phone: String
    )

    fun getSmsMode(): String {
        return try {
            val mode = BuildConfig.SMS_MODE.toString()
            if (mode.isEmpty()) "fast2sms_otp" else mode
        } catch (e: Exception) {
            "fast2sms_otp"
        }
    }

    var testModeOverride: Boolean? = null

    fun isTestMode(): Boolean {
        if (testModeOverride != null) return testModeOverride!!
        return try {
            val mode = BuildConfig.SMS_MODE.toString()
            mode.equals("test", ignoreCase = true)
        } catch (e: Exception) {
            false
        }
    }

    suspend fun sendOtp(phone: String, forceQuickSms: Boolean = false): OtpResult = withContext(Dispatchers.IO) {
        val cleanedPhone = LiorisRepository.cleanPhoneNumber(phone)
        if (cleanedPhone.length != 10) {
            return@withContext OtpResult.Error("Invalid phone number. Must be 10 digits.")
        }

        val currentTime = System.currentTimeMillis()

        // 1. Cooldown check: 60 seconds resend constraint
        val existingSession = sessions[cleanedPhone]
        if (existingSession != null && !isTestMode()) {
            val secondsElapsed = (currentTime - existingSession.timestamp) / 1000
            if (secondsElapsed < 60) {
                val waitSeconds = 60 - secondsElapsed
                return@withContext OtpResult.Error("Please wait $waitSeconds seconds before requesting another OTP.")
            }
        }

        // 3. Generate 6-digit OTP
        val otp = if (isTestMode()) {
            "123456"
        } else {
            Random.nextInt(100000, 999999).toString()
        }

        // 4. Save Session
        sessions[cleanedPhone] = OtpSession(otp = otp, timestamp = currentTime, phone = cleanedPhone)
        verifyAttempts[cleanedPhone] = 0

        // 5. Send SMS if not in test mode
        if (isTestMode()) {
            Log.d("OtpService", "Test mode active: OTP for $cleanedPhone is $otp")
            return@withContext OtpResult.Success(cleanedPhone, isTest = true, response = "Test Mode Success")
        }

        val apiKey = try {
            BuildConfig.FAST2SMS_API_KEY.toString()
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "NA" || apiKey == "dummy" || apiKey == "placeholder") {
            return@withContext OtpResult.Error("Fast2SMS setup missing. Switch to Test Mode.")
        }

        try {
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val isQuick = forceQuickSms || getSmsMode().equals("fast2sms_quick", ignoreCase = true)
            val jsonBody = if (isQuick) {
                """
                    {
                      "route": "q",
                      "message": "Your LIORIS login OTP is $otp. This OTP is valid for 5 minutes. Do not share it with anyone.",
                      "language": "english",
                      "flash": 0,
                      "numbers": "$cleanedPhone"
                    }
                """.trimIndent()
            } else {
                """
                    {
                      "route": "otp",
                      "variables_values": "$otp",
                      "numbers": "$cleanedPhone"
                    }
                """.trimIndent()
            }

            val body = jsonBody.toRequestBody(mediaType)
            val request = Request.Builder()
                .url("https://www.fast2sms.com/dev/bulkV2")
                .addHeader("authorization", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("accept", "application/json")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseText = response.body?.string() ?: ""
                Log.d("OtpService", "Fast2SMS raw response: $responseText")

                if (responseText.contains("996")) {
                    return@withContext OtpResult.Error(
                        message = "Fast2SMS OTP KYC pending. Complete KYC or use test mode.",
                        response = responseText
                    )
                }
                if (responseText.contains("999")) {
                    return@withContext OtpResult.Error(
                        message = "Fast2SMS requires minimum ₹100 transaction before OTP API.",
                        response = responseText
                    )
                }
                if (responseText.contains("997")) {
                    return@withContext OtpResult.Error(
                        message = "OTP must be numeric only.",
                        response = responseText
                    )
                }

                if (response.isSuccessful && (responseText.contains("true", ignoreCase = true) || responseText.contains("Success", ignoreCase = true))) {
                    OtpResult.Success(cleanedPhone, isTest = false, response = responseText)
                } else {
                    OtpResult.Error("Failed to send SMS through Fast2SMS. Response: $responseText", response = responseText)
                }
            }
        } catch (e: Exception) {
            Log.e("OtpService", "SMS Exception: ", e)
            OtpResult.Error("SMS Delivery failed. Connection error: ${e.localizedMessage}")
        }
    }

    fun verifyOtp(phone: String, enteredOtp: String): Boolean {
        val cleanedPhone = LiorisRepository.cleanPhoneNumber(phone)
        val session = sessions[cleanedPhone] ?: return false

        // Check 5-minute expiry
        val currentTime = System.currentTimeMillis()
        if (currentTime - session.timestamp > 5 * 60 * 1000L) {
            sessions.remove(cleanedPhone) // Expired
            verifyAttempts.remove(cleanedPhone)
            return false
        }

        // Limit verify attempts to max 5
        val attempts = verifyAttempts.getOrDefault(cleanedPhone, 0)
        if (attempts >= 5) {
            sessions.remove(cleanedPhone) // Invalidate session due to too many failed attempts
            verifyAttempts.remove(cleanedPhone)
            return false
        }
        verifyAttempts[cleanedPhone] = attempts + 1

        val isValid = session.otp == enteredOtp.trim()
        if (isValid) {
            sessions.remove(cleanedPhone) // Consume session upon success
            verifyAttempts.remove(cleanedPhone)
        }
        return isValid
    }

    private fun UriEncode(value: String): String {
        return java.net.URLEncoder.encode(value, "UTF-8")
    }
}

sealed class OtpResult {
    data class Success(val phone: String, val isTest: Boolean, val response: String = "") : OtpResult()
    data class Error(val message: String, val response: String = "") : OtpResult()
}
