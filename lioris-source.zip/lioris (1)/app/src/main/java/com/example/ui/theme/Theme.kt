package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LiorisWhite,
    onPrimary = LiorisBlack,
    secondary = LiorisGold,
    onSecondary = LiorisBlack,
    background = LiorisBlack,
    onBackground = LiorisWhite,
    surface = LiorisDarkGrey,
    onSurface = LiorisWhite,
    error = LiorisError,
    onError = LiorisWhite,
    surfaceVariant = LiorisDarkGrey,
    onSurfaceVariant = LiorisLightGrey
)

private val LightColorScheme = lightColorScheme(
    primary = LiorisBlack,
    onPrimary = LiorisWhite,
    secondary = LiorisGold,
    onSecondary = LiorisBlack,
    background = LiorisLightGrey,
    onBackground = LiorisBlack,
    surface = LiorisWhite,
    onSurface = LiorisBlack,
    error = LiorisError,
    onError = LiorisWhite,
    surfaceVariant = LiorisLightGrey,
    onSurfaceVariant = LiorisDarkGrey
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
