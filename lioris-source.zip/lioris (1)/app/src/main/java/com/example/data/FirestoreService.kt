package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object FirestoreService {
    private const val TAG = "FirestoreService"

    // Helper to clean phone number to 10 digits
    fun cleanPhone(phone: String?): String {
        val clean = (phone ?: "").replace(Regex("\\D"), "")
        return if (clean.length >= 10) clean.takeLast(10) else clean
    }

    // Check if Firebase is configured/connected
    fun isFirebaseConfigured(context: Context): Boolean {
        return try {
            if (com.google.firebase.FirebaseApp.getApps(context).isEmpty()) {
                val options = com.google.firebase.FirebaseOptions.Builder()
                    .setApiKey("AIzaSyCWRHdFe2eWERga6QG6sehG8B-WJXEM7-s")
                    .setApplicationId("1:357730641920:web:6b43af5bd9953e537e50e5")
                    .setProjectId("luxora-store-58762")
                    .setStorageBucket("luxora-store-58762.firebasestorage.app")
                    .setGcmSenderId("357730641920")
                    .build()
                com.google.firebase.FirebaseApp.initializeApp(context, options)
                Log.d(TAG, "Firebase initialized manually with custom credentials")
                println("Firebase initialized manually with custom credentials")
            }
            val app = com.google.firebase.FirebaseApp.getInstance()
            val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
            app != null && db != null
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring Firebase manually: ${e.message}", e)
            println("Error configuring Firebase manually: ${e.message}")
            false
        }
    }

    // Parse product maps into Product entities safely supporting missing and legacy fields
    fun parseProduct(docId: String, data: Map<String, Any>): Product {
        val id = data["id"] as? String ?: docId
        val name = data["name"] as? String ?: "Unnamed Product"
        val category = data["category"] as? String ?: "Uncategorized"
        val subcategory = data["subcategory"] as? String ?: ""
        
        // Convert price safely
        val price = when (val p = data["price"]) {
            is Number -> p.toDouble()
            is String -> p.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
        
        // Convert mrp safely
        val mrp = when (val m = data["mrp"]) {
            is Number -> m.toDouble()
            is String -> m.toDoubleOrNull() ?: price
            else -> price
        }
        
        val discount = when (val d = data["discount"]) {
            is Number -> d.toDouble()
            is String -> d.toDoubleOrNull() ?: 0.0
            else -> {
                if (mrp > price && mrp > 0) {
                    ((mrp - price) / mrp) * 100.0
                } else {
                    0.0
                }
            }
        }
        
        // Handle stock vs qty
        val stock = when (val s = data["stock"] ?: data["qty"]) {
            is Number -> s.toInt()
            is String -> s.toIntOrNull() ?: 10
            else -> 10
        }
        
        // Handle image vs images (can be String or List)
        val imagesList = when (val imgs = data["images"] ?: data["image"]) {
            is List<*> -> imgs.filterIsInstance<String>()
            is String -> {
                if (imgs.contains(",")) {
                    imgs.split(",").map { it.trim() }
                } else {
                    listOf(imgs)
                }
            }
            else -> emptyList()
        }
        val imagesStr = imagesList.filter { it.isNotEmpty() }.joinToString(",")
            .ifEmpty { "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop" }
            
        val description = data["description"] as? String ?: ""
        val highlights = data["highlights"] as? String ?: ""
        val sizes = data["sizes"] as? String ?: ""
        val colors = data["colors"] as? String ?: ""
        val tags = data["tags"] as? String ?: ""
        val rating = when (val r = data["rating"]) {
            is Number -> r.toDouble()
            else -> 4.5
        }
        val reviewCount = when (val rc = data["reviewCount"]) {
            is Number -> rc.toInt()
            else -> 12
        }
        val active = data["active"] as? Boolean ?: true
        val trending = data["trending"] as? Boolean ?: false
        val bestSeller = data["bestSeller"] as? Boolean ?: false
        val newArrival = data["newArrival"] as? Boolean ?: false
        val giftEligible = data["giftEligible"] as? Boolean ?: false
        val dealExpiry = when (val de = data["dealExpiry"]) {
            is Number -> de.toLong()
            else -> 0L
        }
        val createdAt = when (val ca = data["createdAt"]) {
            is com.google.firebase.Timestamp -> ca.toDate().time
            is Number -> ca.toLong()
            else -> System.currentTimeMillis()
        }
        val updatedAt = when (val ua = data["updatedAt"]) {
            is com.google.firebase.Timestamp -> ua.toDate().time
            is Number -> ua.toLong()
            else -> System.currentTimeMillis()
        }
        
        return Product(
            id = id,
            name = name,
            category = category,
            subcategory = subcategory,
            price = price,
            mrp = mrp,
            discount = discount,
            stock = stock,
            images = imagesStr,
            description = description,
            highlights = highlights,
            sizes = sizes,
            colors = colors,
            tags = tags,
            rating = rating,
            reviewCount = reviewCount,
            active = active,
            trending = trending,
            bestSeller = bestSeller,
            newArrival = newArrival,
            giftEligible = giftEligible,
            dealExpiry = dealExpiry,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    // Parse order maps into Order entities safely supporting missing and legacy fields
    fun parseOrder(docId: String, data: Map<String, Any>): Order {
        val orderId = data["orderId"] as? String ?: docId
        val phone = cleanPhone(data["phone"] as? String ?: "")
        val userId = data["userId"] as? String ?: phone
        val customerName = data["customerName"] as? String ?: data["name"] as? String ?: "Guest Customer"
        val address = data["address"] as? String ?: "No Address"
        val pincode = data["pincode"] as? String ?: ""
        val city = data["city"] as? String ?: ""
        val state = data["state"] as? String ?: ""
        val landmark = data["landmark"] as? String ?: ""
        
        // Convert items representation safely
        val itemsJsonRaw = data["itemsJson"] as? String
        val itemsJson = if (itemsJsonRaw != null && itemsJsonRaw.isNotEmpty()) {
            itemsJsonRaw
        } else {
            val itemsList = data["items"] as? List<*>
            if (itemsList != null) {
                try {
                    val sb = java.lang.StringBuilder("[")
                    itemsList.forEachIndexed { idx, item ->
                        if (idx > 0) sb.append(",")
                        if (item is Map<*, *>) {
                            val name = item["productName"] ?: item["name"] ?: "Item"
                            val qty = item["quantity"] ?: item["qty"] ?: 1
                            val price = item["price"] ?: 0.0
                            sb.append("{\"productId\":\"\",\"productName\":\"$name\",\"price\":$price,\"quantity\":$qty,\"imageUrl\":\"\"}")
                        } else {
                            sb.append("\"${item.toString().replace("\"", "\\\"")}\"")
                        }
                    }
                    sb.append("]")
                    sb.toString()
                } catch (e: Exception) {
                    "[]"
                }
            } else {
                "[]"
            }
        }
        
        val subtotal = when (val s = data["subtotal"]) {
            is Number -> s.toDouble()
            else -> 0.0
        }
        val deliveryCharge = when (val d = data["deliveryCharge"]) {
            is Number -> d.toDouble()
            else -> 0.0
        }
        val couponCode = data["couponCode"] as? String ?: ""
        val couponDiscount = when (val cd = data["couponDiscount"]) {
            is Number -> cd.toDouble()
            else -> 0.0
        }
        val walletUsed = when (val w = data["walletUsed"]) {
            is Number -> w.toDouble()
            else -> 0.0
        }
        val finalPayable = when (val fp = data["finalPayable"] ?: data["total"] ?: data["amount"]) {
            is Number -> fp.toDouble()
            else -> 0.0
        }
        val totalBeforeWallet = when (val tb = data["totalBeforeWallet"]) {
            is Number -> tb.toDouble()
            else -> finalPayable + walletUsed
        }
        val paymentMethod = data["paymentMethod"] as? String ?: "COD"
        val utr = data["utr"] as? String ?: ""
        val paymentStatus = data["paymentStatus"] as? String ?: "Pending"
        val status = data["status"] as? String ?: "Pending"
        val giftUnlocked = data["giftUnlocked"] as? Boolean ?: false
        val giftItem = data["giftItem"] as? String ?: ""
        val walletRefunded = data["walletRefunded"] as? Boolean ?: false
        val telegramNotificationStatus = data["telegramNotificationStatus"] as? String ?: "skipped"
        val returnReason = data["returnReason"] as? String ?: ""
        val returnRequestedAt = when (val rra = data["returnRequestedAt"]) {
            is com.google.firebase.Timestamp -> rra.toDate().time
            is Number -> rra.toLong()
            else -> 0L
        }
        
        val createdAt = when (val ca = data["createdAt"]) {
            is com.google.firebase.Timestamp -> ca.toDate().time
            is Number -> ca.toLong()
            else -> System.currentTimeMillis()
        }
        val updatedAt = when (val ua = data["updatedAt"]) {
            is com.google.firebase.Timestamp -> ua.toDate().time
            is Number -> ua.toLong()
            else -> System.currentTimeMillis()
        }
        
        return Order(
            orderId = orderId,
            userId = userId,
            phone = phone,
            customerName = customerName,
            address = address,
            pincode = pincode,
            city = city,
            state = state,
            landmark = landmark,
            itemsJson = itemsJson,
            subtotal = subtotal,
            deliveryCharge = deliveryCharge,
            couponCode = couponCode,
            couponDiscount = couponDiscount,
            walletUsed = walletUsed,
            totalBeforeWallet = totalBeforeWallet,
            finalPayable = finalPayable,
            paymentMethod = paymentMethod,
            utr = utr,
            paymentStatus = paymentStatus,
            giftUnlocked = giftUnlocked,
            giftItem = giftItem,
            status = status,
            walletRefunded = walletRefunded,
            telegramNotificationStatus = telegramNotificationStatus,
            returnReason = returnReason,
            returnRequestedAt = returnRequestedAt,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    // Save or update customer profile in BOTH Firestore users and customers collections
    suspend fun saveOrUpdateUserOnLogin(
        context: Context, 
        rawPhone: String, 
        existingName: String? = null,
        referredByCode: String? = null
    ): Map<String, Any> {
        val cleaned = cleanPhone(rawPhone)
        println("Saving customer to Firestore (users & customers collections)")
        Log.d(TAG, "Saving customer to Firestore (users & customers collections)")

        if (!isFirebaseConfigured(context)) {
            throw IllegalStateException("Firebase not configured or initialized.")
        }

        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val userRef = db.collection("users").document(cleaned)
                val customerRef = db.collection("customers").document(cleaned)

                // First, resolve the referredByCode if provided
                var resolvedReferredByPhone = ""
                val resolveRunnable = {
                    // Read from both collections to perform safe merge
                    userRef.get().addOnCompleteListener { userGetTask ->
                        customerRef.get().addOnCompleteListener { custGetTask ->
                            val uDoc = if (userGetTask.isSuccessful) userGetTask.result else null
                            val cDoc = if (custGetTask.isSuccessful) custGetTask.result else null

                            val uExists = uDoc != null && uDoc.exists()
                            val cExists = cDoc != null && cDoc.exists()

                            val data = mutableMapOf<String, Any>()

                            if (uExists || cExists) {
                                // Fetch and merge existing data properties safely
                                val uName = uDoc?.getString("name") ?: ""
                                val cName = cDoc?.getString("name") ?: ""
                                val name = uName.ifEmpty { cName }.ifEmpty { existingName ?: "" }

                                // Wallet Balance: If missing, initialize to 0.0. Do not overwrite if exists.
                                val uWallet = uDoc?.getDouble("walletBalance")
                                val cWallet = cDoc?.getDouble("walletBalance")
                                val walletBalance = uWallet ?: cWallet ?: 0.0

                                // Wallet Bonus Given flag
                                val uBonus = uDoc?.getBoolean("walletBonusGiven")
                                val cBonus = cDoc?.getBoolean("walletBonusGiven")
                                val walletBonusGiven = uBonus ?: cBonus ?: false

                                // Saved Address
                                val uAddr = uDoc?.get("savedAddress")
                                val cAddr = cDoc?.get("savedAddress")
                                val savedAddress = uAddr ?: cAddr ?: emptyMap<String, Any>()

                                // Total orders and total spent
                                val uOrders = uDoc?.getLong("totalOrders") ?: 0L
                                val cOrders = cDoc?.getLong("totalOrders") ?: 0L
                                val totalOrders = maxOf(uOrders, cOrders)

                                val uSpent = uDoc?.getDouble("totalSpent") ?: 0.0
                                val cSpent = cDoc?.getDouble("totalSpent") ?: 0.0
                                val totalSpent = maxOf(uSpent, cSpent)

                                val uRefCode = uDoc?.getString("referralCode") ?: ""
                                val cRefCode = cDoc?.getString("referralCode") ?: ""
                                val referralCode = uRefCode.ifEmpty { cRefCode }.ifEmpty { LiorisRepository.generateReferralCode(cleaned) }

                                val uCreatedAt = uDoc?.get("createdAt")
                                val cCreatedAt = cDoc?.get("createdAt")
                                val createdAt = uCreatedAt ?: cCreatedAt ?: FieldValue.serverTimestamp()

                                val email = uDoc?.getString("email") ?: cDoc?.getString("email") ?: ""
                                val googleUid = uDoc?.getString("googleUid") ?: cDoc?.getString("googleUid") ?: ""
                                val loginProvider = uDoc?.getString("loginProvider") ?: cDoc?.getString("loginProvider") ?: "phone"
                                val phoneVerified = uDoc?.getBoolean("phoneVerified") ?: cDoc?.getBoolean("phoneVerified") ?: true
                                val referredBy = uDoc?.getString("referredBy") ?: cDoc?.getString("referredBy") ?: ""
                                val finalReferredBy = referredBy.ifEmpty { resolvedReferredByPhone }
                                val lastOrderAt = uDoc?.get("lastOrderAt") ?: cDoc?.get("lastOrderAt") ?: 0L
                                val defaultAddress = uDoc?.get("defaultAddress") ?: cDoc?.get("defaultAddress") ?: emptyMap<String, Any>()
                                val addresses = uDoc?.get("addresses") ?: cDoc?.get("addresses") ?: emptyList<Map<String, Any>>()
                                val fcmTokens = uDoc?.get("fcmTokens") ?: cDoc?.get("fcmTokens") ?: emptyList<String>()

                                data["phone"] = cleaned
                                data["name"] = name
                                data["email"] = email
                                data["googleUid"] = googleUid
                                data["loginProvider"] = loginProvider
                                data["phoneVerified"] = phoneVerified
                                data["role"] = if (cleaned == "7252083788") "admin" else (uDoc?.getString("role") ?: cDoc?.getString("role") ?: "user")
                                data["walletBalance"] = walletBalance
                                data["walletBonusGiven"] = walletBonusGiven
                                data["referralCode"] = referralCode
                                data["referredBy"] = finalReferredBy
                                data["savedAddress"] = savedAddress
                                data["totalOrders"] = totalOrders
                                data["totalSpent"] = totalSpent
                                data["lastOrderAt"] = lastOrderAt
                                data["defaultAddress"] = defaultAddress
                                data["addresses"] = addresses
                                data["fcmTokens"] = fcmTokens
                                data["createdAt"] = createdAt
                                data["updatedAt"] = FieldValue.serverTimestamp()
                            } else {
                                // Brand New User: Give ₹50 welcome bonus once
                                data["phone"] = cleaned
                                data["name"] = existingName ?: ""
                                data["email"] = ""
                                data["googleUid"] = ""
                                data["loginProvider"] = "phone"
                                data["phoneVerified"] = true
                                data["role"] = if (cleaned == "7252083788") "admin" else "user"
                                data["walletBalance"] = 50.0
                                data["walletBonusGiven"] = true
                                data["referralCode"] = LiorisRepository.generateReferralCode(cleaned)
                                data["referredBy"] = resolvedReferredByPhone
                                data["savedAddress"] = emptyMap<String, Any>()
                                data["totalOrders"] = 0L
                                data["totalSpent"] = 0.0
                                data["lastOrderAt"] = 0L
                                data["defaultAddress"] = emptyMap<String, Any>()
                                data["addresses"] = emptyList<Map<String, Any>>()
                                data["fcmTokens"] = emptyList<String>()
                                data["createdAt"] = FieldValue.serverTimestamp()
                                data["updatedAt"] = FieldValue.serverTimestamp()

                                // If registered with a resolved referrer, record in the referrals collection
                                if (resolvedReferredByPhone.isNotEmpty()) {
                                    val referralData = mapOf(
                                        "referrerPhone" to resolvedReferredByPhone,
                                        "referredPhone" to cleaned,
                                        "referredName" to (existingName ?: ""),
                                        "rewardGiven" to false,
                                        "createdAt" to FieldValue.serverTimestamp()
                                    )
                                    db.collection("referrals").document(cleaned).set(referralData, SetOptions.merge())
                                }
                            }

                            // Write to users
                            userRef.set(data, SetOptions.merge()).addOnCompleteListener { uSetTask ->
                                // Write to customers
                                customerRef.set(data, SetOptions.merge()).addOnCompleteListener { cSetTask ->
                                    if (uSetTask.isSuccessful && cSetTask.isSuccessful) {
                                        continuation.resume(data)
                                    } else {
                                        val err = uSetTask.exception ?: cSetTask.exception ?: Exception("Failed to write to users or customers collections")
                                        continuation.resumeWithException(err)
                                    }
                                }
                            }
                        }
                    }
                }

                if (!referredByCode.isNullOrEmpty()) {
                    db.collection("users")
                        .whereEqualTo("referralCode", referredByCode)
                        .limit(1)
                        .get()
                        .addOnCompleteListener { refQueryTask ->
                            if (refQueryTask.isSuccessful && !refQueryTask.result.isEmpty) {
                                val doc = refQueryTask.result.documents.firstOrNull()
                                if (doc != null && doc.id != cleaned) { // Cannot refer self
                                    resolvedReferredByPhone = doc.id
                                    Log.d(TAG, "Successfully resolved referral code $referredByCode to $resolvedReferredByPhone")
                                }
                            }
                            resolveRunnable()
                        }
                } else {
                    resolveRunnable()
                }

            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // After first valid order, give the referrer ₹50 bonus
    suspend fun checkAndApplyReferralReward(context: Context, referredPhone: String): Boolean {
        if (!isFirebaseConfigured(context)) return false
        val cleaned = cleanPhone(referredPhone)
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val refDocRef = db.collection("referrals").document(cleaned)
                refDocRef.get().addOnCompleteListener { task ->
                    if (task.isSuccessful && task.result?.exists() == true) {
                        val refData = task.result?.data ?: emptyMap<String, Any>()
                        val rewardGiven = refData["rewardGiven"] as? Boolean ?: false
                        val referrerPhone = refData["referrerPhone"] as? String ?: ""

                        if (!rewardGiven && referrerPhone.isNotEmpty()) {
                            refDocRef.update("rewardGiven", true).addOnCompleteListener { updateTask ->
                                if (updateTask.isSuccessful) {
                                    val referrerUserRef = db.collection("users").document(referrerPhone)
                                    val referrerCustRef = db.collection("customers").document(referrerPhone)

                                    db.runTransaction { transaction ->
                                        val uSnap = transaction.get(referrerUserRef)
                                        if (uSnap.exists()) {
                                            val currentBalance = uSnap.getDouble("walletBalance") ?: 0.0
                                            val newBalance = currentBalance + 50.0
                                            transaction.update(referrerUserRef, "walletBalance", newBalance)
                                            transaction.update(referrerCustRef, "walletBalance", newBalance)

                                            // Insert wallet transaction history for referrer
                                            val txnId = "TXN_" + java.util.UUID.randomUUID().toString().take(6)
                                            val txnRef = db.collection("wallet_transactions").document(txnId)
                                            val txnData = mapOf(
                                                "transactionId" to txnId,
                                                "userId" to referrerPhone,
                                                "amount" to 50.0,
                                                "type" to "Credit",
                                                "description" to "Referral Reward (referred: $cleaned)",
                                                "createdAt" to FieldValue.serverTimestamp()
                                            )
                                            transaction.set(txnRef, txnData)
                                        }
                                    }.addOnCompleteListener { txnTask ->
                                        if (txnTask.isSuccessful) {
                                            Log.d(TAG, "Referral reward of ₹50 successfully credited to $referrerPhone")
                                            continuation.resume(true)
                                        } else {
                                            Log.e(TAG, "Failed to credit referral reward to $referrerPhone", txnTask.exception)
                                            continuation.resume(false)
                                        }
                                    }
                                } else {
                                    continuation.resume(false)
                                }
                            }
                        } else {
                            continuation.resume(false)
                        }
                    } else {
                        continuation.resume(false)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in checkAndApplyReferralReward", e)
                continuation.resume(false)
            }
        }
    }

    // Save google user on Google login in googleUsers/{googleUid}
    suspend fun saveGoogleUserOnLogin(
        context: Context,
        uid: String,
        email: String,
        displayName: String
    ): Map<String, Any> {
        if (!isFirebaseConfigured(context)) {
            throw IllegalStateException("Firebase not configured or initialized.")
        }
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val googleUserRef = db.collection("googleUsers").document(uid)

                googleUserRef.get().addOnCompleteListener { getTask ->
                    val doc = if (getTask.isSuccessful) getTask.result else null
                    val exists = doc != null && doc.exists()

                    val data = mutableMapOf<String, Any>()
                    data["uid"] = uid
                    data["email"] = email
                    data["displayName"] = displayName
                    data["loginProvider"] = "google"

                    if (exists) {
                        data["phoneVerified"] = doc?.getBoolean("phoneVerified") ?: false
                        data["verifiedPhone"] = doc?.getString("verifiedPhone") ?: ""
                        data["createdAt"] = doc?.get("createdAt") ?: FieldValue.serverTimestamp()
                        data["updatedAt"] = FieldValue.serverTimestamp()
                    } else {
                        data["phoneVerified"] = false
                        data["verifiedPhone"] = ""
                        data["createdAt"] = FieldValue.serverTimestamp()
                        data["updatedAt"] = FieldValue.serverTimestamp()
                    }

                    googleUserRef.set(data, SetOptions.merge()).addOnCompleteListener { setTask ->
                        if (setTask.isSuccessful) {
                            continuation.resume(data)
                        } else {
                            continuation.resumeWithException(setTask.exception ?: Exception("Failed to write to googleUsers collection"))
                        }
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Link Google account with Phone at Checkout
    suspend fun linkGoogleUserWithPhone(
        context: Context,
        rawPhone: String,
        email: String,
        displayName: String,
        googleUid: String
    ): Map<String, Any> {
        val cleaned = cleanPhone(rawPhone)
        if (!isFirebaseConfigured(context)) {
            throw IllegalStateException("Firebase not configured or initialized.")
        }
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val userRef = db.collection("users").document(cleaned)
                val customerRef = db.collection("customers").document(cleaned)
                val googleUserRef = db.collection("googleUsers").document(googleUid)

                userRef.get().addOnCompleteListener { userGetTask ->
                    customerRef.get().addOnCompleteListener { custGetTask ->
                        val uDoc = if (userGetTask.isSuccessful) userGetTask.result else null
                        val cDoc = if (custGetTask.isSuccessful) custGetTask.result else null

                        val uExists = uDoc != null && uDoc.exists()
                        val cExists = cDoc != null && cDoc.exists()

                        val data = mutableMapOf<String, Any>()

                        if (uExists || cExists) {
                            // Fetch and merge existing data properties safely
                            val uName = uDoc?.getString("name") ?: ""
                            val cName = cDoc?.getString("name") ?: ""
                            val name = uName.ifEmpty { cName }.ifEmpty { displayName }

                            val uWallet = uDoc?.getDouble("walletBalance")
                            val cWallet = cDoc?.getDouble("walletBalance")
                            val walletBalance = uWallet ?: cWallet ?: 0.0

                            val uBonus = uDoc?.getBoolean("walletBonusGiven")
                            val cBonus = cDoc?.getBoolean("walletBonusGiven")
                            val walletBonusGiven = uBonus ?: cBonus ?: false

                            val uAddr = uDoc?.get("savedAddress")
                            val cAddr = cDoc?.get("savedAddress")
                            val savedAddress = uAddr ?: cAddr ?: emptyMap<String, Any>()

                            val uOrders = uDoc?.getLong("totalOrders") ?: 0L
                            val cOrders = cDoc?.getLong("totalOrders") ?: 0L
                            val totalOrders = maxOf(uOrders, cOrders)

                            val uSpent = uDoc?.getDouble("totalSpent") ?: 0.0
                            val cSpent = cDoc?.getDouble("totalSpent") ?: 0.0
                            val totalSpent = maxOf(uSpent, cSpent)

                            val uRefCode = uDoc?.getString("referralCode") ?: ""
                            val cRefCode = cDoc?.getString("referralCode") ?: ""
                            val referralCode = uRefCode.ifEmpty { cRefCode }.ifEmpty { LiorisRepository.generateReferralCode(cleaned) }

                            val uCreatedAt = uDoc?.get("createdAt")
                            val cCreatedAt = cDoc?.get("createdAt")
                            val createdAt = uCreatedAt ?: cCreatedAt ?: FieldValue.serverTimestamp()

                            val referredBy = uDoc?.getString("referredBy") ?: cDoc?.getString("referredBy") ?: ""
                            val lastOrderAt = uDoc?.get("lastOrderAt") ?: cDoc?.get("lastOrderAt") ?: 0L
                            val defaultAddress = uDoc?.get("defaultAddress") ?: cDoc?.get("defaultAddress") ?: emptyMap<String, Any>()
                            val addresses = uDoc?.get("addresses") ?: cDoc?.get("addresses") ?: emptyList<Map<String, Any>>()
                            val fcmTokens = uDoc?.get("fcmTokens") ?: cDoc?.get("fcmTokens") ?: emptyList<String>()

                            data["phone"] = cleaned
                            data["name"] = name
                            data["email"] = email
                            data["googleUid"] = googleUid
                            data["loginProvider"] = "google"
                            data["phoneVerified"] = true
                            data["role"] = if (cleaned == "7252083788") "admin" else (uDoc?.getString("role") ?: cDoc?.getString("role") ?: "user")
                            data["walletBalance"] = walletBalance
                            data["walletBonusGiven"] = walletBonusGiven
                            data["referralCode"] = referralCode
                            data["referredBy"] = referredBy
                            data["savedAddress"] = savedAddress
                            data["totalOrders"] = totalOrders
                            data["totalSpent"] = totalSpent
                            data["lastOrderAt"] = lastOrderAt
                            data["defaultAddress"] = defaultAddress
                            data["addresses"] = addresses
                            data["fcmTokens"] = fcmTokens
                            data["createdAt"] = createdAt
                            data["updatedAt"] = FieldValue.serverTimestamp()
                        } else {
                            // Brand New User: Give ₹50 welcome bonus once
                            data["phone"] = cleaned
                            data["name"] = displayName
                            data["email"] = email
                            data["googleUid"] = googleUid
                            data["loginProvider"] = "google"
                            data["phoneVerified"] = true
                            data["role"] = if (cleaned == "7252083788") "admin" else "user"
                            data["walletBalance"] = 50.0
                            data["walletBonusGiven"] = true
                            data["referralCode"] = LiorisRepository.generateReferralCode(cleaned)
                            data["referredBy"] = ""
                            data["savedAddress"] = emptyMap<String, Any>()
                            data["totalOrders"] = 0L
                            data["totalSpent"] = 0.0
                            data["lastOrderAt"] = 0L
                            data["defaultAddress"] = emptyMap<String, Any>()
                            data["addresses"] = emptyList<Map<String, Any>>()
                            data["fcmTokens"] = emptyList<String>()
                            data["createdAt"] = FieldValue.serverTimestamp()
                            data["updatedAt"] = FieldValue.serverTimestamp()
                        }

                        // Update googleUsers collection as well
                        val googleUserData = mapOf(
                            "phoneVerified" to true,
                            "verifiedPhone" to cleaned,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )

                        userRef.set(data, SetOptions.merge()).addOnCompleteListener { uSetTask ->
                            customerRef.set(data, SetOptions.merge()).addOnCompleteListener { cSetTask ->
                                googleUserRef.set(googleUserData, SetOptions.merge()).addOnCompleteListener { gSetTask ->
                                    if (uSetTask.isSuccessful && cSetTask.isSuccessful && gSetTask.isSuccessful) {
                                        continuation.resume(data)
                                    } else {
                                        val err = uSetTask.exception ?: cSetTask.exception ?: gSetTask.exception ?: Exception("Failed to sync merge for Google user")
                                        continuation.resumeWithException(err)
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Save order on checkout and update BOTH users/{phone} and customers/{phone}
    suspend fun saveOrderOnCheckout(
        context: Context,
        orderId: String,
        customerName: String,
        phone: String,
        address: String,
        pincode: String,
        city: String,
        state: String,
        landmark: String,
        finalPayable: Double,
        otherOrderData: Map<String, Any> = emptyMap(),
        newWalletBalance: Double? = null
    ) {
        val cleaned = cleanPhone(phone)
        if (!isFirebaseConfigured(context)) {
            throw IllegalStateException("Firebase not configured or initialized.")
        }

        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()

                // 1. Create and Save order document
                val orderRef = db.collection("orders").document(orderId)
                val orderMap = mutableMapOf<String, Any>()
                orderMap["orderId"] = orderId
                orderMap["userId"] = cleaned
                orderMap["phone"] = cleaned
                orderMap["customerName"] = customerName
                orderMap["address"] = address
                orderMap["pincode"] = pincode
                orderMap["city"] = city
                orderMap["state"] = state
                orderMap["landmark"] = landmark
                orderMap["finalPayable"] = finalPayable
                orderMap["walletRefunded"] = false
                orderMap["createdAt"] = FieldValue.serverTimestamp()
                orderMap["updatedAt"] = FieldValue.serverTimestamp()
                orderMap.putAll(otherOrderData)

                orderRef.set(orderMap).addOnCompleteListener { orderTask ->
                    if (orderTask.isSuccessful) {
                        // 2. Fetch current user document to increment stats
                        val userRef = db.collection("users").document(cleaned)
                        val customerRef = db.collection("customers").document(cleaned)

                        userRef.get().addOnCompleteListener { userGetTask ->
                            val currentTotalOrders = if (userGetTask.isSuccessful && userGetTask.result?.exists() == true) {
                                userGetTask.result?.getLong("totalOrders") ?: 0L
                            } else {
                                0L
                            }
                            val currentTotalSpent = if (userGetTask.isSuccessful && userGetTask.result?.exists() == true) {
                                userGetTask.result?.getDouble("totalSpent") ?: 0.0
                            } else {
                                0.0
                            }
                            val currentWalletBalance = if (newWalletBalance != null) {
                                newWalletBalance
                            } else {
                                if (userGetTask.isSuccessful && userGetTask.result?.exists() == true) {
                                    userGetTask.result?.getDouble("walletBalance") ?: 50.0
                                } else {
                                    50.0
                                }
                            }
                            val currentWalletBonusGiven = if (userGetTask.isSuccessful && userGetTask.result?.exists() == true) {
                                userGetTask.result?.getBoolean("walletBonusGiven") ?: true
                            } else {
                                true
                            }
                            val currentCreatedAt = if (userGetTask.isSuccessful && userGetTask.result?.exists() == true) {
                                userGetTask.result?.get("createdAt") ?: FieldValue.serverTimestamp()
                            } else {
                                FieldValue.serverTimestamp()
                            }
                            val currentReferralCode = if (userGetTask.isSuccessful && userGetTask.result?.exists() == true) {
                                userGetTask.result?.getString("referralCode") ?: LiorisRepository.generateReferralCode(cleaned)
                            } else {
                                LiorisRepository.generateReferralCode(cleaned)
                            }

                            val addressMap = mapOf(
                                "customerName" to customerName,
                                "address" to address,
                                "pincode" to pincode,
                                "city" to city,
                                "state" to state,
                                "landmark" to landmark
                            )

                            val userUpdate = mapOf(
                                "phone" to cleaned,
                                "name" to customerName,
                                "role" to if (cleaned == "7252083788") "admin" else "user",
                                "walletBalance" to currentWalletBalance,
                                "walletBonusGiven" to currentWalletBonusGiven,
                                "referralCode" to currentReferralCode,
                                "savedAddress" to addressMap,
                                "totalOrders" to (currentTotalOrders + 1L),
                                "totalSpent" to (currentTotalSpent + finalPayable),
                                "createdAt" to currentCreatedAt,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )

                            val customerUpdate = mapOf(
                                "customerName" to customerName,
                                "phone" to cleaned,
                                "savedAddress" to addressMap,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )

                            userRef.set(userUpdate, SetOptions.merge()).addOnCompleteListener { uUpdateTask ->
                                customerRef.set(customerUpdate, SetOptions.merge()).addOnCompleteListener { cUpdateTask ->
                                    if (uUpdateTask.isSuccessful && cUpdateTask.isSuccessful) {
                                        val walletUsed = (otherOrderData["walletUsed"] as? Number)?.toDouble() ?: 0.0
                                        if (walletUsed > 0.0) {
                                            try {
                                                val txId = "WT_DEBIT_" + java.util.UUID.randomUUID().toString().take(8)
                                                val txRef = db.collection("walletTransactions").document(txId)
                                                val txMap = mapOf(
                                                    "userId" to cleaned,
                                                    "phone" to cleaned,
                                                    "type" to "debit",
                                                    "amount" to walletUsed,
                                                    "reason" to "Used in order",
                                                    "orderId" to orderId,
                                                    "createdAt" to FieldValue.serverTimestamp()
                                                )
                                                txRef.set(txMap).addOnCompleteListener { txTask ->
                                                    continuation.resume(Unit)
                                                }
                                            } catch (e: Exception) {
                                                continuation.resume(Unit)
                                            }
                                        } else {
                                            continuation.resume(Unit)
                                        }
                                    } else {
                                        continuation.resumeWithException(
                                            uUpdateTask.exception ?: cUpdateTask.exception ?: Exception("Failed to sync customer after checkout")
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        continuation.resumeWithException(orderTask.exception ?: Exception("Failed to save order document"))
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Get all customers merging users & customers collection safely with phone ID alignment
    suspend fun getAllCustomers(context: Context): List<Map<String, Any>> {
        if (!isFirebaseConfigured(context)) {
            throw IllegalStateException("Firebase not configured or initialized.")
        }
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("users").get().addOnCompleteListener { usersTask ->
                    if (usersTask.isSuccessful) {
                        val usersList = usersTask.result.documents
                        db.collection("customers").get().addOnCompleteListener { custsTask ->
                            if (custsTask.isSuccessful) {
                                val custsList = custsTask.result.documents
                                val mergedMap = mutableMapOf<String, MutableMap<String, Any>>()

                                // 1. Process users collection
                                for (doc in usersList) {
                                    val cleaned = cleanPhone(doc.id)
                                    if (cleaned.isNotEmpty()) {
                                        val map = doc.data?.toMutableMap() ?: mutableMapOf()
                                        map["phone"] = cleaned
                                        mergedMap[cleaned] = map
                                    }
                                }

                                // 2. Process customers collection (merge with users)
                                for (doc in custsList) {
                                    val cleaned = cleanPhone(doc.id)
                                    if (cleaned.isNotEmpty()) {
                                        val custMap = doc.data?.toMutableMap() ?: mutableMapOf()
                                        custMap["phone"] = cleaned
                                        
                                        val existing = mergedMap[cleaned]
                                        if (existing != null) {
                                            val name = existing["name"] as? String ?: ""
                                            val custName = custMap["name"] as? String ?: ""
                                            if (name.isEmpty() && custName.isNotEmpty()) {
                                                existing["name"] = custName
                                            }
                                            
                                            val uBal = (existing["walletBalance"] as? Number)?.toDouble()
                                            val cBal = (custMap["walletBalance"] as? Number)?.toDouble()
                                            if (uBal == null && cBal != null) {
                                                existing["walletBalance"] = cBal
                                            } else if (uBal == null) {
                                                existing["walletBalance"] = 0.0
                                            }
                                            
                                            val uAddr = existing["savedAddress"]
                                            val cAddr = custMap["savedAddress"]
                                            if (uAddr == null && cAddr != null) {
                                                existing["savedAddress"] = cAddr
                                            }
                                            
                                            val uSpent = (existing["totalSpent"] as? Number)?.toDouble() ?: 0.0
                                            val cSpent = (custMap["totalSpent"] as? Number)?.toDouble() ?: 0.0
                                            existing["totalSpent"] = maxOf(uSpent, cSpent)

                                            val uOrd = (existing["totalOrders"] as? Number)?.toLong() ?: 0L
                                            val cOrd = (custMap["totalOrders"] as? Number)?.toLong() ?: 0L
                                            existing["totalOrders"] = maxOf(uOrd, cOrd)
                                        } else {
                                            if (custMap["walletBalance"] == null) {
                                                custMap["walletBalance"] = 0.0
                                            }
                                            mergedMap[cleaned] = custMap
                                        }
                                    }
                                }
                                continuation.resume(mergedMap.values.toList())
                            } else {
                                val list = mutableListOf<Map<String, Any>>()
                                for (doc in usersList) {
                                    val map = doc.data?.toMutableMap() ?: mutableMapOf()
                                    map["phone"] = doc.id
                                    list.add(map)
                                }
                                continuation.resume(list)
                            }
                        }
                    } else {
                        val err = usersTask.exception ?: Exception("Failed to get customers/users from Firestore")
                        continuation.resumeWithException(err)
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Get orders by specific customer
    suspend fun getOrdersByCustomer(context: Context, customerPhone: String): List<Map<String, Any>> {
        val cleaned = cleanPhone(customerPhone)
        if (!isFirebaseConfigured(context)) {
            throw IllegalStateException("Firebase not configured or initialized.")
        }
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("orders")
                    .whereEqualTo("phone", cleaned)
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val list = mutableListOf<Map<String, Any>>()
                            for (doc in task.result) {
                                val map = doc.data.toMutableMap()
                                map["orderId"] = doc.id
                                list.add(map)
                            }
                            continuation.resume(list)
                        } else {
                            continuation.resume(emptyList())
                        }
                    }
            } catch (e: Exception) {
                continuation.resume(emptyList())
            }
        }
    }

    // Get all products from Firestore products collection
    suspend fun getAllProducts(context: Context): List<Map<String, Any>> {
        if (!isFirebaseConfigured(context)) return emptyList()
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("products").get().addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val list = mutableListOf<Map<String, Any>>()
                        for (doc in task.result) {
                            val map = doc.data.toMutableMap()
                            map["id"] = doc.id
                            list.add(map)
                        }
                        continuation.resume(list)
                    } else {
                        continuation.resume(emptyList())
                    }
                }
            } catch (e: Exception) {
                continuation.resume(emptyList())
            }
        }
    }

    // Write/update product inside Firestore products collection
    suspend fun saveOrUpdateProduct(context: Context, product: Product) {
        if (!isFirebaseConfigured(context)) return
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val productMap = mapOf(
                    "id" to product.id,
                    "name" to product.name,
                    "category" to product.category,
                    "subcategory" to product.subcategory,
                    "price" to product.price,
                    "mrp" to product.mrp,
                    "discount" to product.discount,
                    "stock" to product.stock,
                    "qty" to product.stock, // compatibility qty
                    "images" to product.images,
                    "image" to product.images.split(",").firstOrNull().orEmpty(), // compatibility image
                    "description" to product.description,
                    "highlights" to product.highlights,
                    "sizes" to product.sizes,
                    "colors" to product.colors,
                    "tags" to product.tags,
                    "rating" to product.rating,
                    "reviewCount" to product.reviewCount,
                    "active" to product.active,
                    "trending" to product.trending,
                    "bestSeller" to product.bestSeller,
                    "newArrival" to product.newArrival,
                    "giftEligible" to product.giftEligible,
                    "dealExpiry" to product.dealExpiry,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("products").document(product.id).set(productMap, SetOptions.merge())
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            continuation.resume(Unit)
                        } else {
                            continuation.resumeWithException(task.exception ?: Exception("Failed to write product"))
                        }
                    }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Delete product from Firestore products collection
    suspend fun deleteProduct(context: Context, id: String) {
        if (!isFirebaseConfigured(context)) return
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("products").document(id).delete()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            continuation.resume(Unit)
                        } else {
                            continuation.resumeWithException(task.exception ?: Exception("Failed to delete product"))
                        }
                    }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Get all orders from Firestore orders collection
    suspend fun getAllOrders(context: Context): List<Map<String, Any>> {
        if (!isFirebaseConfigured(context)) return emptyList()
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("orders").get().addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val list = mutableListOf<Map<String, Any>>()
                        for (doc in task.result) {
                            val map = doc.data.toMutableMap()
                            map["orderId"] = doc.id
                            list.add(map)
                        }
                        continuation.resume(list)
                    } else {
                        continuation.resume(emptyList())
                    }
                }
            } catch (e: Exception) {
                continuation.resume(emptyList())
            }
        }
    }

    // Update order status in Firestore orders collection
    suspend fun updateOrderStatus(context: Context, orderId: String, newStatus: String, paymentStatus: String? = null) {
        if (!isFirebaseConfigured(context)) return
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val updates = mutableMapOf<String, Any>("status" to newStatus, "updatedAt" to FieldValue.serverTimestamp())
                if (paymentStatus != null) {
                    updates["paymentStatus"] = paymentStatus
                }
                db.collection("orders").document(orderId).update(updates).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        continuation.resume(Unit)
                    } else {
                        continuation.resumeWithException(task.exception ?: Exception("Failed to update status in Firestore"))
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    suspend fun submitReturnRequest(context: Context, orderId: String, reason: String) {
        if (!isFirebaseConfigured(context)) return
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val updates = mapOf(
                    "status" to "Return Requested",
                    "returnReason" to reason,
                    "returnRequestedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("orders").document(orderId).update(updates).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        continuation.resume(Unit)
                    } else {
                        continuation.resumeWithException(task.exception ?: Exception("Failed to submit return request"))
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // General sync method to update BOTH users/{phone} and customers/{phone} on local user modification
    suspend fun syncUserToFirestore(context: Context, user: User) {
        if (!isFirebaseConfigured(context)) return
        val cleaned = cleanPhone(user.phone)
        val db = FirebaseFirestore.getInstance()
        
        val addressMap = if (user.savedAddress.isNotEmpty()) {
            val parts = user.savedAddress.split(",")
            val addr = parts.getOrNull(0)?.trim() ?: ""
            val city = parts.getOrNull(1)?.trim() ?: ""
            val statePin = parts.getOrNull(2)?.trim() ?: ""
            val state = statePin.split("-").getOrNull(0)?.trim() ?: ""
            val pincode = statePin.split("-").getOrNull(1)?.trim() ?: ""
            mapOf(
                "customerName" to user.name,
                "address" to addr,
                "pincode" to pincode,
                "city" to city,
                "state" to state
            )
        } else {
            emptyMap<String, Any>()
        }

        val userMap = mapOf(
            "phone" to cleaned,
            "name" to user.name,
            "role" to user.role,
            "walletBalance" to user.walletBalance,
            "walletBonusGiven" to user.walletBonusGiven,
            "referralCode" to user.referralCode,
            "savedAddress" to addressMap,
            "totalSpent" to user.totalSpent,
            "updatedAt" to FieldValue.serverTimestamp()
        )

        return suspendCancellableCoroutine { continuation ->
            db.collection("users").document(cleaned).set(userMap, SetOptions.merge()).addOnCompleteListener { uTask ->
                db.collection("customers").document(cleaned).set(userMap, SetOptions.merge()).addOnCompleteListener { cTask ->
                    continuation.resume(Unit)
                }
            }
        }
    }

    // Save a wallet transaction history entry to Firestore
    suspend fun saveWalletTransaction(
        context: Context,
        phone: String,
        type: String,
        amount: Double,
        reason: String,
        orderId: String? = null
    ) {
        val cleaned = cleanPhone(phone)
        if (!isFirebaseConfigured(context)) return

        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val txId = "WT_" + type.uppercase() + "_" + java.util.UUID.randomUUID().toString().take(8)
                val txRef = db.collection("walletTransactions").document(txId)
                
                val txMap = mutableMapOf<String, Any>(
                    "userId" to cleaned,
                    "phone" to cleaned,
                    "type" to type.lowercase(),
                    "amount" to amount,
                    "reason" to reason,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                if (orderId != null) {
                    txMap["orderId"] = orderId
                }

                txRef.set(txMap).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        continuation.resume(Unit)
                    } else {
                        continuation.resumeWithException(task.exception ?: Exception("Failed to save wallet transaction"))
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Get store settings from settings collection
    suspend fun getStoreSettings(context: Context): Map<String, Any>? {
        if (!isFirebaseConfigured(context)) return null
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("settings").document("store").get().addOnCompleteListener { task ->
                    if (task.isSuccessful && task.result?.exists() == true) {
                        continuation.resume(task.result?.data)
                    } else {
                        db.collection("settings").limit(1).get().addOnCompleteListener { colTask ->
                            if (colTask.isSuccessful && !colTask.result.isEmpty) {
                                continuation.resume(colTask.result.documents.first().data)
                            } else {
                                continuation.resume(null)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                continuation.resume(null)
            }
        }
    }

    // Save store settings in settings collection
    suspend fun saveStoreSettings(context: Context, settings: Map<String, Any>) {
        if (!isFirebaseConfigured(context)) return
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("settings").document("store").set(settings, SetOptions.merge())
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            continuation.resume(Unit)
                        } else {
                            continuation.resumeWithException(task.exception ?: Exception("Failed to save settings"))
                        }
                    }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Sync cart to Firestore under cart/{phone}
    suspend fun saveCartToFirestore(context: Context, phone: String, cartItems: List<CartItem>) {
        if (!isFirebaseConfigured(context)) return
        val cleaned = cleanPhone(phone)
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val cartRef = db.collection("cart").document(cleaned)
                
                val itemsList = cartItems.map { item ->
                    mapOf(
                        "productId" to item.productId,
                        "productName" to item.productName,
                        "name" to item.productName,
                        "price" to item.price,
                        "quantity" to item.quantity,
                        "qty" to item.quantity,
                        "imageUrl" to item.imageUrl,
                        "image" to item.imageUrl,
                        "selectedSize" to item.selectedSize,
                        "selectedColor" to item.selectedColor
                    )
                }
                
                val cartMap = mapOf(
                    "phone" to cleaned,
                    "items" to itemsList,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                
                cartRef.set(cartMap, SetOptions.merge()).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        continuation.resume(Unit)
                    } else {
                        continuation.resumeWithException(task.exception ?: Exception("Failed to save cart"))
                    }
                }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }
    }

    // Load cart from Firestore under cart/{phone}
    suspend fun getCartFromFirestore(context: Context, phone: String): List<CartItem> {
        if (!isFirebaseConfigured(context)) return emptyList()
        val cleaned = cleanPhone(phone)
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("cart").document(cleaned).get().addOnCompleteListener { task ->
                    if (task.isSuccessful && task.result?.exists() == true) {
                        val itemsList = task.result?.get("items") as? List<*>
                        val cartItems = mutableListOf<CartItem>()
                        if (itemsList != null) {
                            for (item in itemsList) {
                                if (item is Map<*, *>) {
                                    val productId = item["productId"] as? String ?: ""
                                    val productName = item["productName"] as? String ?: item["name"] as? String ?: ""
                                    val price = (item["price"] as? Number)?.toDouble() ?: 0.0
                                    val quantity = (item["quantity"] as? Number)?.toInt() ?: (item["qty"] as? Number)?.toInt() ?: 1
                                    val imageUrl = item["imageUrl"] as? String ?: item["image"] as? String ?: ""
                                    val selectedSize = item["selectedSize"] as? String ?: ""
                                    val selectedColor = item["selectedColor"] as? String ?: ""
                                    
                                    if (productId.isNotEmpty()) {
                                        cartItems.add(
                                            CartItem(
                                                productId = productId,
                                                productName = productName,
                                                price = price,
                                                quantity = quantity,
                                                imageUrl = imageUrl,
                                                selectedSize = selectedSize,
                                                selectedColor = selectedColor
                                            )
                                        )
                                    }
                                }
                            }
                        }
                        continuation.resume(cartItems)
                    } else {
                        continuation.resume(emptyList())
                    }
                }
            } catch (e: Exception) {
                continuation.resume(emptyList())
            }
        }
    }

    // Sync coupon to Firestore
    suspend fun saveCouponToFirestore(context: Context, coupon: Coupon) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        val couponMap = mapOf(
            "code" to coupon.code,
            "type" to coupon.type,
            "value" to coupon.value,
            "minOrder" to coupon.minOrder,
            "maxDiscount" to coupon.maxDiscount,
            "usageLimit" to coupon.usageLimit,
            "usedCount" to coupon.usedCount,
            "active" to coupon.active,
            "expiryDate" to coupon.expiryDate,
            "createdAt" to coupon.createdAt,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return suspendCancellableCoroutine { continuation ->
            db.collection("coupons").document(coupon.code).set(couponMap, SetOptions.merge()).addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    suspend fun deleteCouponFromFirestore(context: Context, code: String) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        return suspendCancellableCoroutine { continuation ->
            db.collection("coupons").document(code).delete().addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    // Sync banner to Firestore
    suspend fun saveBannerToFirestore(context: Context, banner: Banner) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        val bannerMap = mapOf(
            "bannerId" to banner.bannerId,
            "title" to banner.title,
            "subtitle" to banner.subtitle,
            "image" to banner.image,
            "link" to banner.link,
            "active" to banner.active,
            "sortOrder" to banner.sortOrder,
            "createdAt" to banner.createdAt,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return suspendCancellableCoroutine { continuation ->
            db.collection("banners").document(banner.bannerId).set(bannerMap, SetOptions.merge()).addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    suspend fun deleteBannerFromFirestore(context: Context, bannerId: String) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        return suspendCancellableCoroutine { continuation ->
            db.collection("banners").document(bannerId).delete().addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    // Sync giftOffer to Firestore
    suspend fun saveGiftOfferToFirestore(context: Context, offer: GiftOffer) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        val offerMap = mapOf(
            "offerId" to offer.offerId,
            "title" to offer.title,
            "minOrderValue" to offer.minOrderValue,
            "giftName" to offer.giftName,
            "giftImage" to offer.giftImage,
            "active" to offer.active,
            "createdAt" to offer.createdAt,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return suspendCancellableCoroutine { continuation ->
            db.collection("giftOffers").document(offer.offerId).set(offerMap, SetOptions.merge()).addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    suspend fun deleteGiftOfferFromFirestore(context: Context, offerId: String) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        return suspendCancellableCoroutine { continuation ->
            db.collection("giftOffers").document(offerId).delete().addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    // Sync notification to Firestore
    suspend fun saveNotificationToFirestore(context: Context, notification: Notification) {
        if (!isFirebaseConfigured(context)) return
        val db = FirebaseFirestore.getInstance()
        val notificationMap = mapOf(
            "notificationId" to notification.notificationId,
            "title" to notification.title,
            "message" to notification.message,
            "target" to notification.target,
            "phone" to cleanPhone(notification.phone),
            "read" to notification.read,
            "createdAt" to notification.createdAt,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return suspendCancellableCoroutine { continuation ->
            db.collection("notifications").document(notification.notificationId).set(notificationMap, SetOptions.merge()).addOnCompleteListener { task ->
                continuation.resume(Unit)
            }
        }
    }

    suspend fun saveOtpMode(context: Context, otpMode: String) {
        if (!isFirebaseConfigured(context)) return
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                val data = mapOf(
                    "otpMode" to otpMode,
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                db.collection("settings").document("appConfig").set(data, com.google.firebase.firestore.SetOptions.merge())
                    .addOnCompleteListener { task ->
                        continuation.resume(Unit)
                    }
            } catch (e: Exception) {
                continuation.resume(Unit)
            }
        }
    }

    suspend fun getOtpMode(context: Context): String? {
        if (!isFirebaseConfigured(context)) return null
        return suspendCancellableCoroutine { continuation ->
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("settings").document("appConfig").get().addOnCompleteListener { task ->
                    if (task.isSuccessful && task.result?.exists() == true) {
                        val otpMode = task.result?.getString("otpMode")
                        continuation.resume(otpMode)
                    } else {
                        continuation.resume(null)
                    }
                }
            } catch (e: Exception) {
                continuation.resume(null)
            }
        }
    }
}
