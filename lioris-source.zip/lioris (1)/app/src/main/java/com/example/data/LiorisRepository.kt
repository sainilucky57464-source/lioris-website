package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID

class LiorisRepository(private val dao: LiorisDao) {

    // --- Users ---
    suspend fun getUserByPhone(phone: String): User? = dao.getUserByPhone(phone)
    fun observeUserByPhone(phone: String): Flow<User?> = dao.observeUserByPhone(phone)
    fun getAllUsers(): Flow<List<User>> = dao.getAllUsers()
    suspend fun insertUser(user: User) = dao.insertUser(user)
    suspend fun updateUser(user: User) = dao.updateUser(user)

    // --- Products ---
    suspend fun getProductById(id: String): Product? = dao.getProductById(id)
    fun observeProductById(id: String): Flow<Product?> = dao.observeProductById(id)
    fun getActiveProducts(): Flow<List<Product>> = dao.getActiveProducts()
    fun getAllProducts(): Flow<List<Product>> = dao.getAllProducts()
    suspend fun insertProduct(product: Product) = dao.insertProduct(product)
    suspend fun updateProduct(product: Product) = dao.updateProduct(product)
    suspend fun deleteProductById(id: String) = dao.deleteProductById(id)

    // --- Orders ---
    suspend fun getOrderById(orderId: String): Order? = dao.getOrderById(orderId)
    fun observeOrderById(orderId: String): Flow<Order?> = dao.observeOrderById(orderId)
    fun getOrdersByUserId(userId: String): Flow<List<Order>> = dao.getOrdersByUserId(userId)
    fun getAllOrders(): Flow<List<Order>> = dao.getAllOrders()
    suspend fun insertOrder(order: Order) = dao.insertOrder(order)
    suspend fun updateOrder(order: Order) = dao.updateOrder(order)

    // --- Wallet Transactions ---
    fun getWalletTransactionsByUserId(userId: String): Flow<List<WalletTransaction>> =
        dao.getWalletTransactionsByUserId(userId)
    fun getAllWalletTransactions(): Flow<List<WalletTransaction>> = dao.getAllWalletTransactions()
    suspend fun insertWalletTransaction(transaction: WalletTransaction) =
        dao.insertWalletTransaction(transaction)

    // --- Coupons ---
    suspend fun getCouponByCode(code: String): Coupon? = dao.getCouponByCode(code.uppercase().trim())
    fun getAllCoupons(): Flow<List<Coupon>> = dao.getAllCoupons()
    suspend fun insertCoupon(coupon: Coupon) = dao.insertCoupon(coupon.copy(code = coupon.code.uppercase().trim()))
    suspend fun deleteCouponByCode(code: String) = dao.deleteCouponByCode(code.uppercase().trim())

    // --- Banners ---
    fun getActiveBanners(): Flow<List<Banner>> = dao.getActiveBanners()
    fun getAllBanners(): Flow<List<Banner>> = dao.getAllBanners()
    suspend fun insertBanner(banner: Banner) = dao.insertBanner(banner)
    suspend fun deleteBannerById(bannerId: String) = dao.deleteBannerById(bannerId)

    // --- Gift Offers ---
    fun getActiveGiftOffers(): Flow<List<GiftOffer>> = dao.getActiveGiftOffers()
    fun getAllGiftOffers(): Flow<List<GiftOffer>> = dao.getAllGiftOffers()
    suspend fun insertGiftOffer(offer: GiftOffer) = dao.insertGiftOffer(offer)
    suspend fun deleteGiftOfferById(offerId: String) = dao.deleteGiftOfferById(offerId)

    // --- Notifications ---
    fun getNotificationsForUser(phone: String): Flow<List<Notification>> =
        dao.getNotificationsForUser(phone)
    fun getAllNotifications(): Flow<List<Notification>> = dao.getAllNotifications()
    suspend fun insertNotification(notification: Notification) = dao.insertNotification(notification)
    suspend fun markAllNotificationsAsReadForUser(phone: String) = dao.markAllNotificationsAsReadForUser(phone)

    // --- Referrals ---
    fun getAllReferrals(): Flow<List<Referral>> = dao.getAllReferrals()

    // --- Admin Notifications ---
    fun getAllAdminNotifications(): Flow<List<AdminNotification>> = dao.getAllAdminNotifications()
    suspend fun insertAdminNotification(notification: AdminNotification) = dao.insertAdminNotification(notification)

    // --- OTP Logs ---
    fun getAllOtpLogs(): Flow<List<OtpLog>> = dao.getAllOtpLogs()
    suspend fun insertOtpLog(log: OtpLog) = dao.insertOtpLog(log)

    // --- Store Settings ---
    suspend fun getStoreSettings(): StoreSettings {
        var settings = dao.getStoreSettings()
        if (settings == null) {
            settings = StoreSettings()
            dao.insertStoreSettings(settings)
        }
        return settings
    }
    fun observeStoreSettings(): Flow<StoreSettings?> = dao.observeStoreSettings()
    suspend fun insertStoreSettings(settings: StoreSettings) = dao.insertStoreSettings(settings)

    // --- Database Population ---
    suspend fun checkAndPopulateDefaults() {
        val storeSettings = dao.getStoreSettings()
        if (storeSettings == null) {
            dao.insertStoreSettings(StoreSettings())
        }

        val allProducts = dao.getAllProducts().firstOrNull() ?: emptyList()
        if (allProducts.isEmpty()) {
            val demoProducts = listOf(
                Product(
                    id = "p1",
                    name = "Premium Women Top",
                    price = 399.0,
                    mrp = 499.0,
                    discount = 20.0,
                    stock = 15,
                    images = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop",
                    description = "An ultra premium, clean, luxury top for modern chic styling.",
                    highlights = "Premium stretch blend material,Breathable fabric,Minimalist stitching",
                    sizes = "S,M,L",
                    colors = "Beige,White,Black",
                    category = "Clothing",
                    trending = true,
                    newArrival = true
                ),
                Product(
                    id = "p2",
                    name = "Designer Kurti",
                    price = 699.0,
                    mrp = 999.0,
                    discount = 30.0,
                    stock = 8,
                    images = "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&auto=format&fit=crop",
                    description = "Beautifully embroidered premium designer kurti suitable for all luxury and festive settings.",
                    highlights = "100% fine organic cotton,Intricate hand embroidery,Gold thread accents",
                    sizes = "M,L,XL",
                    colors = "Champagne Gold,Classic Black",
                    category = "Clothing",
                    bestSeller = true,
                    newArrival = true
                ),
                Product(
                    id = "p3",
                    name = "Brass Toothpick Stand",
                    price = 120.0,
                    mrp = 199.0,
                    discount = 40.0,
                    stock = 20,
                    images = "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=600&auto=format&fit=crop",
                    description = "Solid brass luxury toothpick stand, showcasing timeless minimal elegance for your dining table.",
                    highlights = "100% solid brushed brass,Heavy weighted stable base,Artisanal premium finish",
                    sizes = "Standard",
                    colors = "Brushed Gold",
                    category = "Metal Items"
                ),
                Product(
                    id = "p4",
                    name = "Luxury Steel Jug",
                    price = 499.0,
                    mrp = 799.0,
                    discount = 37.0,
                    stock = 5,
                    images = "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop",
                    description = "Stunning highly-polished stainless steel jug featuring premium ergonomics and modern curves.",
                    highlights = "Premium food-grade stainless steel,Double insulated wall,Spill-proof ergonomic pour spout",
                    sizes = "1.5L",
                    colors = "Polished Chrome",
                    category = "Metal Items",
                    trending = true
                ),
                Product(
                    id = "p5",
                    name = "Copper Water Bottle",
                    price = 799.0,
                    mrp = 1199.0,
                    discount = 33.0,
                    stock = 3, // Low stock demo!
                    images = "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&auto=format&fit=crop",
                    description = "Pure ayurvedic copper water bottle with leak-proof sleek modern cap. Supports immunity and wellness.",
                    highlights = "99.9% pure therapeutic copper,Seamless leak-proof silicon seal cap,Ergonomic high-style grip",
                    sizes = "1L",
                    colors = "Pure Copper",
                    category = "Home",
                    bestSeller = true,
                    giftEligible = true
                )
            )
            for (p in demoProducts) {
                dao.insertProduct(p)
            }
        }

        val allBanners = dao.getAllBanners().firstOrNull() ?: emptyList()
        if (allBanners.isEmpty()) {
            val demoBanners = listOf(
                Banner(
                    bannerId = "b1",
                    title = "THE LUXURY COLLECTION",
                    subtitle = "Discover premium styles and artisanal metal items.",
                    image = "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1000&auto=format&fit=crop",
                    sortOrder = 1
                ),
                Banner(
                    bannerId = "b2",
                    title = "ARTISANAL HOME PIECE",
                    subtitle = "Up to 40% Off on pure brass & copper masterpieces.",
                    image = "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=1000&auto=format&fit=crop",
                    sortOrder = 2
                )
            )
            for (b in demoBanners) {
                dao.insertBanner(b)
            }
        }

        val allOffers = dao.getAllGiftOffers().firstOrNull() ?: emptyList()
        if (allOffers.isEmpty()) {
            dao.insertGiftOffer(
                GiftOffer(
                    offerId = "g1",
                    title = "Free Brass Keepsake",
                    minOrderValue = 500.0,
                    giftName = "Handcrafted Brass Spoon Set",
                    giftImage = "https://images.unsplash.com/photo-1544816155-12df9643f363?w=600&auto=format&fit=crop",
                    active = true
                )
            )
        }

        val allCoupons = dao.getAllCoupons().firstOrNull() ?: emptyList()
        if (allCoupons.isEmpty()) {
            dao.insertCoupon(
                Coupon(
                    code = "WELCOME50",
                    type = "FLAT",
                    value = 50.0,
                    minOrder = 299.0,
                    maxDiscount = 50.0,
                    usageLimit = 1000,
                    usedCount = 0,
                    active = true,
                    expiryDate = System.currentTimeMillis() + 30 * 24 * 60 * 60 * 1000L
                )
            )
            dao.insertCoupon(
                Coupon(
                    code = "LIORISGOLD",
                    type = "PERCENT",
                    value = 10.0,
                    minOrder = 499.0,
                    maxDiscount = 150.0,
                    usageLimit = 500,
                    usedCount = 0,
                    active = true,
                    expiryDate = System.currentTimeMillis() + 30 * 24 * 60 * 60 * 1000L
                )
            )
        }
    }

    // --- Business Workflows ---

    // 1. Phone OTP Verification & User Creation Flow
    suspend fun verifyOtpAndCreateUser(phone: String, referralCodeApplied: String = ""): User {
        val cleanedPhone = cleanPhoneNumber(phone)
        val existingUser = dao.getUserByPhone(cleanedPhone)

        if (existingUser != null) {
            return existingUser
        }

        // New User Flow
        val settings = getStoreSettings()
        val welcomeBonus = settings.welcomeBonus

        // Generate Referral Code
        val refCode = generateReferralCode(cleanedPhone)

        // Determine if referred by someone else
        var parentReferredBy = ""
        if (referralCodeApplied.isNotEmpty()) {
            val parentUser = dao.getAllUsers().firstOrNull()?.find {
                it.referralCode.equals(referralCodeApplied, ignoreCase = true)
            }
            if (parentUser != null && parentUser.phone != cleanedPhone) {
                parentReferredBy = parentUser.phone
                // Record referral linking
                dao.insertReferral(
                    Referral(
                        referralId = UUID.randomUUID().toString(),
                        referrerPhone = parentUser.phone,
                        referredPhone = cleanedPhone,
                        bonusGiven = false
                    )
                )
            }
        }

        val newUser = User(
            phone = cleanedPhone,
            name = "Guest $cleanedPhone",
            role = if (cleanedPhone == "7252083788") "admin" else "user",
            walletBalance = welcomeBonus,
            walletBonusGiven = true,
            referralCode = refCode,
            referredBy = parentReferredBy,
            firstOrderPlaced = false,
            totalSpent = 0.0,
            loyaltyLevel = "New Member",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        dao.insertUser(newUser)

        // Insert Welcome Wallet Transaction
        if (welcomeBonus > 0.0) {
            dao.insertWalletTransaction(
                WalletTransaction(
                    transactionId = "WT_WELCOME_" + UUID.randomUUID().toString().take(6),
                    userId = cleanedPhone,
                    phone = cleanedPhone,
                    type = "CREDIT",
                    amount = welcomeBonus,
                    reason = "Welcome Bonus",
                    createdAt = System.currentTimeMillis()
                )
            )

            // Insert custom system notification
            dao.insertNotification(
                Notification(
                    notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                    title = "Welcome to LIORIS! ✨",
                    message = "Congratulations! A ₹${welcomeBonus.toInt()} welcome bonus has been credited to your Lioris Wallet.",
                    target = "phone",
                    phone = cleanedPhone,
                    read = false
                )
            )
        }

        return newUser
    }

    // 2. Placing Order Transaction Flow
    suspend fun placeOrder(
        userId: String,
        customerName: String,
        address: String,
        pincode: String,
        city: String,
        state: String,
        landmark: String,
        cartItems: List<CartItem>,
        subtotal: Double,
        deliveryCharge: Double,
        couponCode: String,
        couponDiscount: Double,
        walletUsed: Double,
        totalBeforeWallet: Double,
        finalPayable: Double,
        paymentMethod: String,
        utr: String = "",
        giftUnlocked: Boolean,
        giftItem: String = "",
        loginProvider: String = "",
        googleUid: String = ""
    ): Order {
        val cleanedPhone = cleanPhoneNumber(userId)
        var workingUser = dao.getUserByPhone(cleanedPhone) ?: throw IllegalStateException("User not found")

        // Get latest walletBalance from DB
        val walletBalance = workingUser.walletBalance

        // Calculate allowedWalletUse again on backend/transaction
        val allowedWalletUse = if (walletUsed > 0.0) {
            val totalBeforeWalletCalc = subtotal + deliveryCharge - couponDiscount
            val maxWalletAllowed = totalBeforeWalletCalc * 0.5
            minOf(walletUsed, walletBalance, maxWalletAllowed).coerceAtLeast(0.0)
        } else {
            0.0
        }

        // Validate wallet balance
        if (allowedWalletUse > 0.0 && walletBalance < allowedWalletUse) {
            throw IllegalStateException("Insufficient wallet balance")
        }

        // Deduct Product Stock
        for (item in cartItems) {
            val product = dao.getProductById(item.productId)
            if (product != null) {
                val newStock = (product.stock - item.quantity).coerceAtLeast(0)
                dao.insertProduct(product.copy(stock = newStock))
            }
        }

        // Create Order
        val orderId = "LOR_" + System.currentTimeMillis().toString().takeLast(6) + "_" + UUID.randomUUID().toString().take(4).uppercase()
        val itemsJsonString = cartItemsToJson(cartItems)

        val settings = getStoreSettings()
        val isCodAdvance = paymentMethod == "COD" && settings.codAdvanceEnabled
        val finalAdvancePaid = if (isCodAdvance) settings.codAdvanceAmount else 0.0
        val finalAdvanceUtr = if (isCodAdvance) utr else ""

        val newOrder = Order(
            orderId = orderId,
            userId = cleanedPhone,
            phone = workingUser.phone,
            customerName = customerName,
            address = address,
            pincode = pincode,
            city = city,
            state = state,
            landmark = landmark,
            itemsJson = itemsJsonString,
            subtotal = subtotal,
            deliveryCharge = deliveryCharge,
            couponCode = couponCode,
            couponDiscount = couponDiscount,
            walletUsed = allowedWalletUse,
            totalBeforeWallet = totalBeforeWallet,
            finalPayable = finalPayable,
            paymentMethod = paymentMethod,
            utr = if (paymentMethod == "UPI") utr else "",
            paymentStatus = when {
                paymentMethod == "COD" && settings.codAdvanceEnabled -> "COD Advance Paid Pending Verification"
                paymentMethod == "COD" -> "Pending"
                else -> "Payment Verification Pending"
            },
            giftUnlocked = giftUnlocked,
            giftItem = giftItem,
            status = when {
                paymentMethod == "COD" && settings.codAdvanceEnabled -> "COD Advance Paid Pending Verification"
                paymentMethod == "COD" -> "Accepted"
                else -> "Payment Verification Pending"
            },
            telegramNotificationStatus = "skipped",
            telegramNotificationError = "",
            telegramNotificationAt = 0L,
            loginProvider = loginProvider,
            googleUid = googleUid,
            advancePaid = finalAdvancePaid,
            advanceUtr = finalAdvanceUtr,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        dao.insertOrder(newOrder)

        // Deduct Wallet Balance & Create Transaction
        if (allowedWalletUse > 0.0) {
            val newWalletBalance = workingUser.walletBalance - allowedWalletUse
            workingUser = workingUser.copy(walletBalance = newWalletBalance)
            dao.insertWalletTransaction(
                WalletTransaction(
                    transactionId = "WT_DEBIT_" + UUID.randomUUID().toString().take(6),
                    userId = cleanedPhone,
                    phone = workingUser.phone,
                    type = "DEBIT",
                    amount = allowedWalletUse,
                    reason = "Used in order",
                    orderId = orderId,
                    createdAt = System.currentTimeMillis()
                )
            )
        }

        // Mark Coupon Used
        if (couponCode.isNotEmpty()) {
            val coupon = dao.getCouponByCode(couponCode)
            if (coupon != null) {
                dao.insertCoupon(coupon.copy(usedCount = coupon.usedCount + 1))
            }
        }

        // Post-Order Notification
        dao.insertNotification(
            Notification(
                notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                title = "Order Placed Successfully! 🛒",
                message = "Your order $orderId of ₹${finalPayable.toInt()} is successfully placed and is being processed.",
                target = "phone",
                phone = cleanedPhone,
                read = false
            )
        )

        // Handle Referral Rewards on first valid order placed
        if (!workingUser.firstOrderPlaced) {
            workingUser = workingUser.copy(firstOrderPlaced = true)

            // Check if user was referred
            val referral = dao.getAllReferrals().firstOrNull()?.find {
                it.referredPhone == cleanedPhone && !it.bonusGiven
            }
            if (referral != null) {
                val referrer = dao.getUserByPhone(referral.referrerPhone)
                if (referrer != null) {
                    val settings = getStoreSettings()
                    val bonusAmount = settings.referralBonus

                    // Reward Referrer
                    dao.insertUser(referrer.copy(walletBalance = referrer.walletBalance + bonusAmount))

                    // Record referral transaction
                    dao.insertWalletTransaction(
                        WalletTransaction(
                            transactionId = "WT_REF_REWARD_" + UUID.randomUUID().toString().take(6),
                            userId = referrer.phone,
                            phone = referrer.phone,
                            type = "CREDIT",
                            amount = bonusAmount,
                            reason = "Referral Bonus for $cleanedPhone",
                            createdAt = System.currentTimeMillis()
                        )
                    )

                    // Mark referral record as bonus given
                    dao.updateReferral(referral.copy(bonusGiven = true))

                    // Send notifications to referrer
                    dao.insertNotification(
                        Notification(
                            notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                            title = "Referral Reward Received! 🎉",
                            message = "You have received a ₹${bonusAmount.toInt()} bonus because your referred friend $customerName placed their first order!",
                            target = "phone",
                            phone = referrer.phone,
                            read = false
                        )
                    )
                }
            }
        }

        // Update Total spent & loyalty level
        val finalUserSpent = workingUser.totalSpent + finalPayable
        val newLoyaltyLevel = when {
            finalUserSpent >= 5000.0 -> "Premium"
            finalUserSpent >= 2500.0 -> "Gold"
            finalUserSpent >= 1000.0 -> "Silver"
            else -> "New Member"
        }
        workingUser = workingUser.copy(
            totalSpent = finalUserSpent,
            loyaltyLevel = newLoyaltyLevel,
            savedAddress = "$address, $city, $state - $pincode"
        )

        // Single final safe update of workingUser record to SQLite DB
        dao.insertUser(workingUser)

        return newOrder
    }

    // 3. Admin Order Status Update / Cancellation with Refund
    suspend fun repairWalletDeductions(): Int {
        var repairedCount = 0
        val allOrders = dao.getAllOrders().firstOrNull() ?: emptyList()
        val allTx = dao.getAllWalletTransactions().firstOrNull() ?: emptyList()

        for (order in allOrders) {
            if (order.walletUsed > 0.0) {
                val txExists = allTx.any {
                    it.orderId == order.orderId && it.type.equals("DEBIT", ignoreCase = true)
                }
                if (!txExists) {
                    val user = dao.getUserByPhone(order.userId)
                    if (user != null) {
                        val newBalance = (user.walletBalance - order.walletUsed).coerceAtLeast(0.0)
                        dao.insertUser(user.copy(walletBalance = newBalance))

                        dao.insertWalletTransaction(
                            WalletTransaction(
                                transactionId = "WT_DEBIT_REPAIR_" + UUID.randomUUID().toString().take(6),
                                userId = order.userId,
                                phone = user.phone,
                                type = "DEBIT",
                                amount = order.walletUsed,
                                reason = "Used in order (Repaired)",
                                orderId = order.orderId,
                                createdAt = System.currentTimeMillis()
                            )
                        )
                        repairedCount++
                    }
                }
            }
        }
        return repairedCount
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String): Order? {
        val order = dao.getOrderById(orderId) ?: return null

        if (newStatus == "Cancelled" && order.status != "Cancelled" && !order.walletRefunded) {
            // Cancel order & Refund wallet balance
            val user = dao.getUserByPhone(order.userId)
            if (user != null && order.walletUsed > 0.0) {
                val updatedBalance = user.walletBalance + order.walletUsed
                dao.insertUser(user.copy(walletBalance = updatedBalance))

                // Wallet Credit Transaction
                dao.insertWalletTransaction(
                    WalletTransaction(
                        transactionId = "WT_CREDIT_REFUND_" + UUID.randomUUID().toString().take(6),
                        userId = order.userId,
                        phone = user.phone,
                        type = "CREDIT",
                        amount = order.walletUsed,
                        reason = "Refund for Cancelled Order $orderId",
                        orderId = orderId,
                        createdAt = System.currentTimeMillis()
                    )
                )
            }

            // Also restore product stock
            val itemsList = jsonToCartItems(order.itemsJson)
            for (item in itemsList) {
                val product = dao.getProductById(item.productId)
                if (product != null) {
                    dao.insertProduct(product.copy(stock = product.stock + item.quantity))
                }
            }

            val updatedOrder = order.copy(
                status = "Cancelled",
                walletRefunded = true,
                updatedAt = System.currentTimeMillis()
            )
            dao.insertOrder(updatedOrder)

            // Send notification
            dao.insertNotification(
                Notification(
                    notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                    title = "Order Cancelled 🚫",
                    message = "Your order $orderId has been cancelled. Any wallet amount used has been refunded.",
                    target = "phone",
                    phone = order.userId,
                    read = false
                )
            )

            return updatedOrder
        }

        if (newStatus == "Returned" && order.status != "Returned" && !order.walletRefunded) {
            // Refund the finalPayable and any walletUsed back to the user's wallet!
            val user = dao.getUserByPhone(order.userId)
            val refundAmount = order.finalPayable + order.walletUsed
            if (user != null && refundAmount > 0.0) {
                val updatedBalance = user.walletBalance + refundAmount
                dao.insertUser(user.copy(walletBalance = updatedBalance))

                dao.insertWalletTransaction(
                    WalletTransaction(
                        transactionId = "WT_CREDIT_RETURN_" + UUID.randomUUID().toString().take(6),
                        userId = order.userId,
                        phone = user.phone,
                        type = "CREDIT",
                        amount = refundAmount,
                        reason = "Refund for Returned Order $orderId",
                        orderId = orderId,
                        createdAt = System.currentTimeMillis()
                    )
                )
            }

            // Restore product stock on returned items
            val itemsList = jsonToCartItems(order.itemsJson)
            for (item in itemsList) {
                val product = dao.getProductById(item.productId)
                if (product != null) {
                    dao.insertProduct(product.copy(stock = product.stock + item.quantity))
                }
            }

            val updatedOrder = order.copy(
                status = "Returned",
                walletRefunded = true,
                updatedAt = System.currentTimeMillis()
            )
            dao.insertOrder(updatedOrder)

            dao.insertNotification(
                Notification(
                    notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                    title = "Return Approved & Refunded 💵",
                    message = "Your return request for order $orderId has been approved. Refund of ₹${refundAmount.toInt()} has been credited to your wallet.",
                    target = "phone",
                    phone = order.userId,
                    read = false
                )
            )

            return updatedOrder
        }

        // Normal Status Update
        val updatedOrder = order.copy(
            status = newStatus,
            paymentStatus = if (newStatus == "Delivered") "Verified" else order.paymentStatus,
            updatedAt = System.currentTimeMillis()
        )
        dao.insertOrder(updatedOrder)

        // Send Status Update Notification
        val title = when (newStatus) {
            "Accepted" -> "Order Accepted ✅"
            "Packed" -> "Order Packed 📦"
            "Shipped" -> "Order Shipped 🚚"
            "Out for Delivery" -> "Out for Delivery 🛵"
            "Delivered" -> "Order Delivered 🎉"
            else -> "Order Status Update 🔔"
        }
        val message = when (newStatus) {
            "Accepted" -> "Your order $orderId has been accepted and is being prepared."
            "Packed" -> "Great news! Your order $orderId is securely packed and ready to ship."
            "Shipped" -> "Your package $orderId has been handed over to the courier partner."
            "Out for Delivery" -> "Our delivery executive is on their way with your order $orderId!"
            "Delivered" -> "Thank you for shopping with LIORIS! Your order $orderId has been delivered successfully."
            else -> "Your order $orderId status is now: $newStatus"
        }

        dao.insertNotification(
            Notification(
                notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                title = title,
                message = message,
                target = "phone",
                phone = order.userId,
                read = false
            )
        )

        return updatedOrder
    }

    // 4. Admin Wallet Manual Controls
    suspend fun adjustUserWallet(phone: String, amount: Double, reason: String, type: String): User? {
        val user = dao.getUserByPhone(phone) ?: return null
        val finalBalance = if (type == "CREDIT") {
            user.walletBalance + amount
        } else {
            (user.walletBalance - amount).coerceAtLeast(0.0)
        }

        val updatedUser = user.copy(walletBalance = finalBalance, updatedAt = System.currentTimeMillis())
        dao.insertUser(updatedUser)

        dao.insertWalletTransaction(
            WalletTransaction(
                transactionId = "WT_ADMIN_ADJ_" + UUID.randomUUID().toString().take(6),
                userId = phone,
                phone = phone,
                type = type,
                amount = amount,
                reason = reason,
                createdAt = System.currentTimeMillis()
            )
        )

        // In-App Notification
        dao.insertNotification(
            Notification(
                notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                title = if (type == "CREDIT") "Wallet Credited 💳" else "Wallet Debited 💳",
                message = if (type == "CREDIT") "Your wallet has been credited with ₹${amount.toInt()} ($reason)."
                          else "Your wallet has been debited with ₹${amount.toInt()} ($reason).",
                target = "phone",
                phone = phone,
                read = false
            )
        )

        return updatedUser
    }

    // Helpers
    companion object {
        fun cleanPhoneNumber(phone: String): String {
            // Remove +91, spaces, dashes, brackets, etc. and keep last 10 digits
            val cleanStr = phone.replace(Regex("[^0-9]"), "")
            return if (cleanStr.length >= 10) cleanStr.takeLast(10) else cleanStr
        }

        fun generateReferralCode(phone: String): String {
            val phonePart = if (phone.length >= 4) phone.takeLast(4) else "0000"
            val randomPart = UUID.randomUUID().toString().take(3).uppercase()
            return "LIORIS$phonePart$randomPart"
        }

        // Simple Serialization since we don't have heavy libraries setup or to keep it fast
        fun cartItemsToJson(items: List<CartItem>): String {
            return items.joinToString(";") { item ->
                "${item.productId}|${item.productName}|${item.price}|${item.quantity}|${item.imageUrl}|${item.selectedSize}|${item.selectedColor}"
            }
        }

        fun jsonToCartItems(json: String): List<CartItem> {
            if (json.isEmpty()) return emptyList()
            return try {
                json.split(";").mapNotNull { block ->
                    val parts = block.split("|")
                    if (parts.size >= 5) {
                        CartItem(
                            productId = parts[0],
                            productName = parts[1],
                            price = parts[2].toDouble(),
                            quantity = parts[3].toInt(),
                            imageUrl = parts[4],
                            selectedSize = parts.getOrNull(5) ?: "",
                            selectedColor = parts.getOrNull(6) ?: ""
                        )
                    } else null
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}

data class CartItem(
    val productId: String,
    val productName: String,
    val price: Double,
    val quantity: Int,
    val imageUrl: String,
    val selectedSize: String = "",
    val selectedColor: String = ""
)
