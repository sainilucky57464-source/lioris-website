package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object TelegramService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    sealed class TelegramResult {
        object Success : TelegramResult()
        object Skipped : TelegramResult()
        data class Failure(val error: String) : TelegramResult()
    }

    suspend fun sendOrderNotification(order: Order, items: List<CartItem>): TelegramResult = withContext(Dispatchers.IO) {
        val botToken = try {
            BuildConfig.TELEGRAM_BOT_TOKEN.toString()
        } catch (e: Exception) {
            ""
        }
        val chatId = try {
            BuildConfig.TELEGRAM_CHAT_ID.toString()
        } catch (e: Exception) {
            ""
        }

        if (botToken.isEmpty() || chatId.isEmpty() || 
            botToken == "NA" || chatId == "NA" || 
            botToken == "dummy" || chatId == "dummy" || 
            botToken.contains("placeholder") || chatId.contains("placeholder") ||
            botToken.contains("dummy") || chatId.contains("dummy")
        ) {
            Log.d("TelegramService", "Telegram credentials missing or dummy. Skipping notification.")
            return@withContext TelegramResult.Skipped
        }

        val itemsString = items.mapIndexed { index, item ->
            "${index + 1}. ${item.productName} x ${item.quantity} = ₹${(item.price * item.quantity).toInt()}"
        }.joinToString("\n")

        val giftText = if (order.giftUnlocked && order.giftItem.isNotEmpty()) order.giftItem else "None"
        val couponText = if (order.couponCode.isNotEmpty()) order.couponCode else "None"

        val message = """
🛍️ <b>New LIORIS Order</b>

<b>Order ID:</b> ${order.orderId}
<b>Customer:</b> ${order.customerName}
<b>Phone:</b> ${order.phone}
<b>Amount:</b> ₹${order.finalPayable.toInt()}
<b>Subtotal:</b> ₹${order.subtotal.toInt()}
<b>Wallet Used:</b> ₹${order.walletUsed.toInt()}
<b>Coupon:</b> $couponText
<b>Payment:</b> ${order.paymentMethod}
<b>Status:</b> ${order.status}

<b>Address:</b>
${order.address}, ${order.city}, ${order.state} - ${order.pincode}${if (order.landmark.isNotEmpty()) "\nLandmark: " + order.landmark else ""}

<b>Items:</b>
$itemsString

<b>Gift:</b>
$giftText
        """.trimIndent()

        try {
            val formBody = FormBody.Builder()
                .add("chat_id", chatId)
                .add("text", message)
                .add("parse_mode", "HTML")
                .build()

            val request = Request.Builder()
                .url("https://api.telegram.org/bot$botToken/sendMessage")
                .post(formBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                Log.d("TelegramService", "Telegram response: $responseBody")
                if (response.isSuccessful) {
                    TelegramResult.Success
                } else {
                    TelegramResult.Failure("HTTP ${response.code}: $responseBody")
                }
            }
        } catch (e: Exception) {
            Log.e("TelegramService", "Error sending telegram notification: ", e)
            TelegramResult.Failure(e.localizedMessage ?: "Connection error")
        }
    }

    suspend fun sendTestMessage(): TelegramResult = withContext(Dispatchers.IO) {
        val botToken = try {
            BuildConfig.TELEGRAM_BOT_TOKEN.toString()
        } catch (e: Exception) {
            ""
        }
        val chatId = try {
            BuildConfig.TELEGRAM_CHAT_ID.toString()
        } catch (e: Exception) {
            ""
        }

        if (botToken.isEmpty() || chatId.isEmpty() || 
            botToken == "NA" || chatId == "NA" || 
            botToken == "dummy" || chatId == "dummy" || 
            botToken.contains("placeholder") || chatId.contains("placeholder") ||
            botToken.contains("dummy") || chatId.contains("dummy")
        ) {
            return@withContext TelegramResult.Failure("Telegram credentials missing, empty, or dummy.")
        }

        try {
            val formBody = FormBody.Builder()
                .add("chat_id", chatId)
                .add("text", "LIORIS Telegram notification test successful.")
                .add("parse_mode", "HTML")
                .build()

            val request = Request.Builder()
                .url("https://api.telegram.org/bot$botToken/sendMessage")
                .post(formBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                Log.d("TelegramService", "Telegram test response: $responseBody")
                if (response.isSuccessful) {
                    TelegramResult.Success
                } else {
                    TelegramResult.Failure("HTTP ${response.code}: $responseBody")
                }
            }
        } catch (e: Exception) {
            Log.e("TelegramService", "Telegram test error: ", e)
            TelegramResult.Failure(e.localizedMessage ?: "Unknown connection error")
        }
    }
}
