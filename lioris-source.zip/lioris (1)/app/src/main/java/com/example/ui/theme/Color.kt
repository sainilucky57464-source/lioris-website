package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LIORIS Premium Color Palette
val LiorisBlack = Color(0xFF1A1A1A)
val LiorisWhite = Color(0xFFFFFFFF)
val LiorisLightGrey = Color(0xFFFCFCFC)
val LiorisMediumGrey = Color(0xFFF0F0F0)
val LiorisDarkGrey = Color(0xFF666666)
val LiorisGold = Color(0xFFC5A059) // Signature Luxury Prestige Gold Accent
val LiorisGoldLight = Color(0xFFF5EFE4) // Soft ivory/warm gold light background
val LiorisGoldDark = Color(0xFFC5A059) // Standardized to the gorgeous Gold hue
val LiorisError = Color(0xFFB00020)
val LiorisGreen = Color(0xFF2E7D32)
val LiorisWarning = Color(0xFFC5A059) // Warm warning accent aligned with brand
val LiorisRatingStar = Color(0xFFFFB300)
