package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.Product
import com.example.ui.theme.*
import kotlin.random.Random

// --- Trust Badges ---
data class TrustBadge(val icon: ImageVector, val title: String, val subtitle: String)

@Composable
fun TrustBadgesSection() {
    val badges = listOf(
        TrustBadge(Icons.Outlined.LocalShipping, "COD Available", "Pay at your door"),
        TrustBadge(Icons.Outlined.Lock, "Secure Checkout", "100% SSL protected"),
        TrustBadge(Icons.Outlined.ContactSupport, "Easy Support", "WhatsApp help desk"),
        TrustBadge(Icons.Outlined.WorkspacePremium, "Premium Quality", "Artisanal & authentic")
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(LiorisLightGrey)
            .padding(vertical = 16.dp, horizontal = 12.dp)
    ) {
        Text(
            text = "LIORIS COMMITMENT",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = LiorisGoldDark,
            letterSpacing = 1.5.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            textAlign = TextAlign.Center
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            badges.forEach { badge ->
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(LiorisWhite, shape = CircleShape)
                            .border(1.dp, LiorisMediumGrey, shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = badge.icon,
                            contentDescription = badge.title,
                            tint = LiorisBlack,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = badge.title,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = badge.subtitle,
                        fontSize = 8.sp,
                        color = LiorisDarkGrey,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

// --- Product Card Component ---
@Composable
fun PremiumProductCard(
    product: Product,
    onProductClick: (Product) -> Unit,
    onAddToCartClick: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(170.dp)
            .clickable { onProductClick(product) }
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = LiorisWhite),
        shape = RoundedCornerShape(4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Product Image
            val imageUrl = product.images.split(",").firstOrNull() ?: ""
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(imageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = product.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                contentScale = ContentScale.Crop
            )

            // Wishlist heart overlay
            var isWished by remember { mutableStateOf(false) }
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(32.dp)
                    .background(LiorisWhite.copy(alpha = 0.8f), CircleShape)
                    .clickable { isWished = !isWished },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isWished) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Wishlist",
                    tint = if (isWished) LiorisError else LiorisBlack,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Badges Overlays
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (product.trending) {
                    Box(
                        modifier = Modifier
                            .background(LiorisBlack, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "TRENDING",
                            color = LiorisGold,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }

                if (product.stock <= 3 && product.stock > 0) {
                    Box(
                        modifier = Modifier
                            .background(LiorisError, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "ONLY ${product.stock} LEFT",
                            color = LiorisWhite,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (product.stock == 0) {
                    Box(
                        modifier = Modifier
                            .background(Color.Gray, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "OUT OF STOCK",
                            color = LiorisWhite,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (product.giftEligible) {
                    Box(
                        modifier = Modifier
                            .background(LiorisGreen, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "FREE GIFT",
                            color = LiorisWhite,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Brand Name & Rating Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIORIS",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisGoldDark,
                    letterSpacing = 1.sp
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = "Rating",
                        tint = LiorisRatingStar,
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = product.rating.toString(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiorisBlack
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Product Name
            Text(
                text = product.name,
                fontSize = 13.sp,
                color = LiorisBlack,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Pricing Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "₹${product.price.toInt()}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiorisBlack
                )

                if (product.mrp > product.price) {
                    Text(
                        text = "₹${product.mrp.toInt()}",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textDecoration = TextDecoration.LineThrough
                    )
                    Text(
                        text = "${product.discount.toInt()}% OFF",
                        fontSize = 10.sp,
                        color = LiorisGoldDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Add Button
            Button(
                onClick = { if (product.stock > 0) onAddToCartClick(product) },
                enabled = product.stock > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .testTag("add_to_cart_btn_${product.id}"),
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = LiorisBlack,
                    contentColor = LiorisWhite,
                    disabledContainerColor = Color.LightGray,
                    disabledContentColor = Color.White
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.ShoppingBag,
                    contentDescription = "Add",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (product.stock > 0) "ADD TO BAG" else "OUT OF STOCK",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

// --- Dynamic Announcement Bar ---
@Composable
fun AnnouncementBar(message: String) {
    if (message.isNotEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LiorisBlack)
                .padding(vertical = 6.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = message.uppercase(),
                color = LiorisGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// --- Confetti Particles Effect ---
@Composable
fun ConfettiOverlay(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition()
    val fallPercentage by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    val random = remember { Random(42) }
    val particles = remember {
        List(40) {
            ConfettiParticle(
                x = random.nextFloat(),
                delay = random.nextFloat() * 1000,
                size = random.nextInt(6, 14),
                color = when (random.nextInt(3)) {
                    0 -> LiorisGold
                    1 -> LiorisGoldDark
                    else -> LiorisBlack
                }
            )
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        particles.forEach { particle ->
            val factor = (fallPercentage + particle.delay / 3000f) % 1f
            val yOffset = factor * 800
            val xOffset = particle.x * 400 + Math.sin(factor * 10.0).toFloat() * 20

            Box(
                modifier = Modifier
                    .offset(x = xOffset.dp, y = yOffset.dp)
                    .size(particle.size.dp)
                    .background(particle.color, shape = CircleShape)
            )
        }
    }
}

data class ConfettiParticle(val x: Float, val delay: Float, val size: Int, val color: Color)

// --- WhatsApp Share utility ---
fun shareProductOnWhatsApp(context: Context, productName: String, price: Double, productId: String, referralCode: String) {
    try {
        val productLink = "https://lioris.app/product/$productId?ref=$referralCode"
        val shareText = """
            ✨ Discover LIORIS Luxury ✨
            Check out this premium item:
            $productName at only ₹${price.toInt()}

            Shop here:
            $productLink

            Use referral code $referralCode and get ₹50 wallet bonus.

            Discover more. Get the best.
        """.trimIndent()
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(shareText))
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "WhatsApp is not installed.", Toast.LENGTH_SHORT).show()
    }
}

fun openSupportWhatsApp(context: Context, number: String, query: String = "Hello LIORIS support, I need help.") {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?phone=91$number&text=" + Uri.encode(query))
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "WhatsApp is not installed.", Toast.LENGTH_SHORT).show()
    }
}
