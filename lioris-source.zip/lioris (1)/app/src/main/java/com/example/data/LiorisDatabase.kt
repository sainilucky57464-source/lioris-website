package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        User::class,
        Product::class,
        Order::class,
        WalletTransaction::class,
        Coupon::class,
        Banner::class,
        GiftOffer::class,
        Notification::class,
        Referral::class,
        StoreSettings::class,
        AdminNotification::class,
        OtpLog::class
    ],
    version = 6,
    exportSchema = false
)
abstract class LiorisDatabase : RoomDatabase() {
    abstract fun dao(): LiorisDao

    companion object {
        @Volatile
        private var INSTANCE: LiorisDatabase? = null

        fun getDatabase(context: Context): LiorisDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LiorisDatabase::class.java,
                    "lioris_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
