package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters

@Entity(tableName = "users")
data class User(
    @PrimaryKey val phone: String, // Cleaned 10-digit number
    val name: String,
    val role: String = "user", // "user" or "admin"
    val walletBalance: Double = 0.0,
    val walletBonusGiven: Boolean = false,
    val referralCode: String = "",
    val referredBy: String = "",
    val firstOrderPlaced: Boolean = false,
    val totalSpent: Double = 0.0,
    val loyaltyLevel: String = "New Member", // "New Member", "Silver", "Gold", "Premium"
    val savedAddress: String = "",
    val email: String = "",
    val googleUid: String = "",
    val loginProvider: String = "", // "phone" or "google"
    val phoneVerified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val subcategory: String = "",
    val price: Double,
    val mrp: Double,
    val discount: Double, // Price discount percentage (e.g. 20%)
    val stock: Int,
    val images: String, // Comma-separated list of image URLs
    val description: String,
    val highlights: String = "", // Comma-separated or bullet points
    val sizes: String = "", // Comma-separated (e.g. "S,M,L,XL")
    val colors: String = "", // Comma-separated (e.g. "Black,White,Gold")
    val tags: String = "", // Comma-separated (e.g. "trending,new,bestseller")
    val rating: Double = 4.5,
    val reviewCount: Int = 12,
    val active: Boolean = true,
    val trending: Boolean = false,
    val bestSeller: Boolean = false,
    val newArrival: Boolean = false,
    val giftEligible: Boolean = false,
    val dealExpiry: Long = 0L, // Timestamp if it is a limited time deal
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val orderId: String,
    val userId: String, // phone
    val phone: String,
    val customerName: String,
    val address: String,
    val pincode: String,
    val city: String,
    val state: String,
    val landmark: String = "",
    val itemsJson: String, // JSON representation of items ordered
    val subtotal: Double,
    val deliveryCharge: Double,
    val couponCode: String = "",
    val couponDiscount: Double = 0.0,
    val walletUsed: Double = 0.0,
    val totalBeforeWallet: Double,
    val finalPayable: Double,
    val paymentMethod: String, // "COD", "UPI", "Online"
    val utr: String = "", // UPI Transaction ID
    val paymentStatus: String = "Pending", // "Pending", "Verified", "Failed"
    val giftUnlocked: Boolean = false,
    val giftItem: String = "", // Name of the free gift product
    val status: String = "Pending", // "Pending", "Accepted", "Packed", "Shipped", "Out for Delivery", "Delivered", "Cancelled", "Payment Verification Pending"
    val walletRefunded: Boolean = false,
    val telegramNotificationStatus: String = "skipped", // "sent", "failed", "skipped"
    val telegramNotificationError: String = "",
    val telegramNotificationAt: Long = 0L,
    val loginProvider: String = "",
    val googleUid: String = "",
    val advancePaid: Double = 0.0,
    val advanceUtr: String = "",
    val returnReason: String = "",
    val returnRequestedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallet_transactions")
data class WalletTransaction(
    @PrimaryKey val transactionId: String,
    val userId: String, // phone
    val phone: String,
    val type: String, // "CREDIT" or "DEBIT"
    val amount: Double,
    val reason: String, // "Welcome Bonus", "Referral Bonus", "Order Payment", "Order Refund", "Admin Adjustment"
    val orderId: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "coupons")
data class Coupon(
    @PrimaryKey val code: String,
    val type: String, // "FLAT" or "PERCENT"
    val value: Double,
    val minOrder: Double,
    val maxDiscount: Double,
    val usageLimit: Int = 100,
    val usedCount: Int = 0,
    val active: Boolean = true,
    val expiryDate: Long = 0L, // Timestamp
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "banners")
data class Banner(
    @PrimaryKey val bannerId: String,
    val title: String,
    val subtitle: String = "",
    val image: String,
    val link: String = "",
    val active: Boolean = true,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "gift_offers")
data class GiftOffer(
    @PrimaryKey val offerId: String,
    val title: String,
    val minOrderValue: Double,
    val giftName: String,
    val giftImage: String,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey val notificationId: String,
    val title: String,
    val message: String,
    val target: String = "all", // "all" or specific "phone"
    val phone: String = "",
    val read: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "referrals")
data class Referral(
    @PrimaryKey val referralId: String,
    val referrerPhone: String,
    val referredPhone: String,
    val bonusGiven: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class StoreSettings(
    @PrimaryKey val id: String = "store",
    val storeName: String = "LIORIS",
    val logoUrl: String = "",
    val supportWhatsApp: String = "7252083788",
    val upiId: String = "lioris@upi",
    val qrImage: String = "",
    val deliveryCharge: Double = 40.0,
    val freeDeliveryMinimum: Double = 499.0,
    val codEnabled: Boolean = true,
    val upiEnabled: Boolean = true,
    val onlineEnabled: Boolean = false,
    val referralEnabled: Boolean = true,
    val referralBonus: Double = 50.0,
    val welcomeBonus: Double = 50.0,
    val returnPolicy: String = "Easy 7 days return on all products.",
    val privacyPolicy: String = "Your privacy is our priority. We protect your data.",
    val terms: String = "By buying from LIORIS, you agree to our terms of service.",
    val codAdvanceEnabled: Boolean = true,
    val codAdvanceAmount: Double = 50.0,
    val otpMode: String = "fast2sms_quick" // "test" or "fast2sms_quick"
)

@Entity(tableName = "admin_notifications")
data class AdminNotification(
    @PrimaryKey val id: String,
    val orderId: String,
    val status: String, // "sent", "failed", "skipped"
    val errorMessage: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "otp_logs")
data class OtpLog(
    @PrimaryKey val logId: String,
    val phone: String,
    val smsMode: String,
    val response: String,
    val status: String, // "success", "error"
    val createdAt: Long = System.currentTimeMillis()
)


