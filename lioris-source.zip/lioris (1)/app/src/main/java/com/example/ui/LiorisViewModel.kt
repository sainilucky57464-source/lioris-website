package com.example.ui

import android.app.Application
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class LiorisViewModel(application: Application) : AndroidViewModel(application) {

    val db = LiorisDatabase.getDatabase(application)
    private val repository = LiorisRepository(db.dao())

    // --- Screen Navigation State ---
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Splash)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Navigation Backstack
    private val backstack = mutableListOf<Screen>()

    fun navigateTo(screen: Screen, clearStack: Boolean = false) {
        if (clearStack) {
            backstack.clear()
        } else {
            backstack.add(_currentScreen.value)
        }
        _currentScreen.value = screen
        if (screen == Screen.Profile) {
            refreshUserFromFirestore()
        }
    }

    fun navigateBack(): Boolean {
        if (backstack.isNotEmpty()) {
            _currentScreen.value = backstack.removeAt(backstack.lastIndex)
            return true
        }
        return false
    }

    // --- Session User State ---
    private val _loggedInUser = MutableStateFlow<User?>(null)
    val loggedInUser: StateFlow<User?> = _loggedInUser.asStateFlow()
    val isFirestoreUserLoaded = MutableStateFlow(false)
    val appError = MutableStateFlow<String?>(null)

    fun onSplashFinished() {
        if (_loggedInUser.value != null) {
            _currentScreen.value = Screen.Home
        } else {
            _currentScreen.value = Screen.Login
        }
    }

    fun reloadApp() {
        appError.value = null
        _currentScreen.value = Screen.Splash
        viewModelScope.launch {
            try {
                repository.checkAndPopulateDefaults()
                _storeSettings.value = repository.getStoreSettings()

                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    // Sync products
                    val firebaseProducts = FirestoreService.getAllProducts(getApplication())
                    if (firebaseProducts.isNotEmpty()) {
                        firebaseProducts.forEach { map ->
                            val product = FirestoreService.parseProduct(map["id"] as? String ?: "", map)
                            repository.insertProduct(product)
                        }
                    }

                    // Sync settings
                    val firebaseSettingsMap = FirestoreService.getStoreSettings(getApplication())
                    if (firebaseSettingsMap != null) {
                        val currentSettings = repository.getStoreSettings()
                        val dbOtpMode = FirestoreService.getOtpMode(getApplication())
                        val otpModeFromFirebase = dbOtpMode ?: (firebaseSettingsMap["otpMode"] as? String) ?: currentSettings.otpMode
                        val syncedSettings = currentSettings.copy(
                            storeName = firebaseSettingsMap["storeName"] as? String ?: currentSettings.storeName,
                            logoUrl = firebaseSettingsMap["logoUrl"] as? String ?: currentSettings.logoUrl,
                            supportWhatsApp = firebaseSettingsMap["supportWhatsApp"] as? String ?: currentSettings.supportWhatsApp,
                            upiId = firebaseSettingsMap["upiId"] as? String ?: currentSettings.upiId,
                            qrImage = firebaseSettingsMap["qrImage"] as? String ?: currentSettings.qrImage,
                            deliveryCharge = (firebaseSettingsMap["deliveryCharge"] as? Number)?.toDouble() ?: currentSettings.deliveryCharge,
                            freeDeliveryMinimum = (firebaseSettingsMap["freeDeliveryMinimum"] as? Number)?.toDouble() ?: currentSettings.freeDeliveryMinimum,
                            codEnabled = firebaseSettingsMap["codEnabled"] as? Boolean ?: currentSettings.codEnabled,
                            upiEnabled = firebaseSettingsMap["upiEnabled"] as? Boolean ?: currentSettings.upiEnabled,
                            onlineEnabled = firebaseSettingsMap["onlineEnabled"] as? Boolean ?: currentSettings.onlineEnabled,
                            referralEnabled = firebaseSettingsMap["referralEnabled"] as? Boolean ?: currentSettings.referralEnabled,
                            referralBonus = (firebaseSettingsMap["referralBonus"] as? Number)?.toDouble() ?: currentSettings.referralBonus,
                            welcomeBonus = (firebaseSettingsMap["welcomeBonus"] as? Number)?.toDouble() ?: currentSettings.welcomeBonus,
                            returnPolicy = firebaseSettingsMap["returnPolicy"] as? String ?: currentSettings.returnPolicy,
                            privacyPolicy = firebaseSettingsMap["privacyPolicy"] as? String ?: currentSettings.privacyPolicy,
                            terms = firebaseSettingsMap["terms"] as? String ?: currentSettings.terms,
                            codAdvanceEnabled = firebaseSettingsMap["codAdvanceEnabled"] as? Boolean ?: currentSettings.codAdvanceEnabled,
                            codAdvanceAmount = (firebaseSettingsMap["codAdvanceAmount"] as? Number)?.toDouble() ?: currentSettings.codAdvanceAmount,
                            otpMode = otpModeFromFirebase
                        )
                        repository.insertStoreSettings(syncedSettings)
                        _storeSettings.value = syncedSettings
                    }
                } else {
                    appError.value = "Firebase database initialization failed. Please check network settings."
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Reload sync failed", e)
                appError.value = "An error occurred during reload: ${e.localizedMessage}"
            }
        }
    }

    // --- Active Flows from DB ---
    val products = repository.getAllProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val activeBanners = repository.getActiveBanners().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val activeGiftOffers = repository.getActiveGiftOffers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val coupons = repository.getAllCoupons().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allBanners = repository.getAllBanners().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allGiftOffers = repository.getAllGiftOffers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allOrders = repository.getAllOrders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allUsers = repository.getAllUsers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allTransactions = repository.getAllWalletTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allReferrals = repository.getAllReferrals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allAdminNotifications = repository.getAllAdminNotifications().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val otpLogs = repository.getAllOtpLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _storeSettings = MutableStateFlow(StoreSettings())
    val storeSettings: StateFlow<StoreSettings> = _storeSettings.asStateFlow()

    // Current user notifications
    val userNotifications = _loggedInUser.flatMapLatest { user ->
        if (user != null) repository.getNotificationsForUser(user.phone) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current user orders
    val userOrders = _loggedInUser.flatMapLatest { user ->
        if (user != null) repository.getOrdersByUserId(user.phone) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current user wallet transactions
    val userTransactions = _loggedInUser.flatMapLatest { user ->
        if (user != null) repository.getWalletTransactionsByUserId(user.phone) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Search & Filtering State ---
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")

    // --- Shopping Cart State ---
    val cartItems = mutableStateListOf<CartItem>()

    // Selected Size / Color state for PDP quick-adds
    val pdpSize = MutableStateFlow("")
    val pdpColor = MutableStateFlow("")

    // Applied Promo Coupon
    private val _appliedCoupon = MutableStateFlow<Coupon?>(null)
    val appliedCoupon: StateFlow<Coupon?> = _appliedCoupon.asStateFlow()

    // Flag whether user has checked "Use Wallet Balance"
    val useWallet = MutableStateFlow(false)

    // Coupon Error message
    val couponError = MutableStateFlow("")

    // --- Recently Viewed Products ---
    val recentlyViewed = mutableStateListOf<Product>()

    fun addToRecentlyViewed(product: Product) {
        recentlyViewed.removeAll { it.id == product.id }
        recentlyViewed.add(0, product)
        if (recentlyViewed.size > 5) {
            recentlyViewed.removeAt(recentlyViewed.size - 1)
        }
    }

    // --- OTP Login State Variables ---
    val loginPhone = MutableStateFlow("")
    val loginOtp = MutableStateFlow("")
    val loginName = MutableStateFlow("")
    val referralCodeInput = MutableStateFlow("")
    val isOtpSent = MutableStateFlow(false)
    val loginError = MutableStateFlow("")
    val loginSuccessMsg = MutableStateFlow("")
    val isSendingOtp = MutableStateFlow(false)
    val isVerifyingOtp = MutableStateFlow(false)
    val otpCooldown = MutableStateFlow(0) // Seconds remaining for resend

    // --- Checkout OTP & Phone Linking Variables ---
    val checkoutPhone = MutableStateFlow("")
    val checkoutOtp = MutableStateFlow("")
    val isCheckoutOtpSent = MutableStateFlow(false)
    val isSendingCheckoutOtp = MutableStateFlow(false)
    val isVerifyingCheckoutOtp = MutableStateFlow(false)
    val checkoutOtpError = MutableStateFlow("")
    val checkoutOtpSuccess = MutableStateFlow("")
    val checkoutOtpCooldown = MutableStateFlow(0)

    // --- Checkout Input Fields ---
    val checkoutName = MutableStateFlow("")
    val checkoutAddress = MutableStateFlow("")
    val checkoutPincode = MutableStateFlow("")
    val checkoutCity = MutableStateFlow("")
    val checkoutState = MutableStateFlow("")
    val checkoutLandmark = MutableStateFlow("")
    val checkoutPaymentMethod = MutableStateFlow("COD") // "COD", "UPI", "Online"
    val checkoutUtr = MutableStateFlow("") // UPI transaction ID

    init {
        viewModelScope.launch {
            // Populate defaults on fresh app launch
            repository.checkAndPopulateDefaults()
            
            // Force Fast2SMS Quick Real OTP mode ON
            try {
                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    FirestoreService.saveOtpMode(getApplication(), "fast2sms_quick")
                }
                val currentSettings = repository.getStoreSettings()
                if (currentSettings.otpMode != "fast2sms_quick") {
                    val updated = currentSettings.copy(otpMode = "fast2sms_quick")
                    repository.insertStoreSettings(updated)
                    _storeSettings.value = updated
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Startup fast2sms_quick enforcement failed", e)
            }

            // Load store settings
            _storeSettings.value = repository.getStoreSettings()

            // Pre-populate referral code if pending in SharedPreferences
            val prefs = getApplication<android.app.Application>().getSharedPreferences("lioris_prefs", android.content.Context.MODE_PRIVATE)
            val pendingRef = prefs.getString("pending_referral_code", "") ?: ""
            if (pendingRef.isNotEmpty() && referralCodeInput.value.isEmpty()) {
                referralCodeInput.value = pendingRef
            }

            // Restore user session
            restoreUserSession()

            // Startup sync from Firestore
            launch {
                try {
                    if (FirestoreService.isFirebaseConfigured(getApplication())) {
                        // 1. Sync products
                        val firebaseProducts = FirestoreService.getAllProducts(getApplication())
                        if (firebaseProducts.isNotEmpty()) {
                            firebaseProducts.forEach { map ->
                                val product = FirestoreService.parseProduct(map["id"] as? String ?: "", map)
                                repository.insertProduct(product)
                            }
                        }
                        
                        // 2. Sync settings
                        val firebaseSettingsMap = FirestoreService.getStoreSettings(getApplication())
                        if (firebaseSettingsMap != null) {
                            val currentSettings = repository.getStoreSettings()
                            val dbOtpMode = FirestoreService.getOtpMode(getApplication())
                            val otpModeFromFirebase = dbOtpMode ?: (firebaseSettingsMap["otpMode"] as? String) ?: currentSettings.otpMode
                            val syncedSettings = currentSettings.copy(
                                storeName = firebaseSettingsMap["storeName"] as? String ?: currentSettings.storeName,
                                logoUrl = firebaseSettingsMap["logoUrl"] as? String ?: currentSettings.logoUrl,
                                supportWhatsApp = firebaseSettingsMap["supportWhatsApp"] as? String ?: currentSettings.supportWhatsApp,
                                upiId = firebaseSettingsMap["upiId"] as? String ?: currentSettings.upiId,
                                qrImage = firebaseSettingsMap["qrImage"] as? String ?: currentSettings.qrImage,
                                deliveryCharge = (firebaseSettingsMap["deliveryCharge"] as? Number)?.toDouble() ?: currentSettings.deliveryCharge,
                                freeDeliveryMinimum = (firebaseSettingsMap["freeDeliveryMinimum"] as? Number)?.toDouble() ?: currentSettings.freeDeliveryMinimum,
                                codEnabled = firebaseSettingsMap["codEnabled"] as? Boolean ?: currentSettings.codEnabled,
                                upiEnabled = firebaseSettingsMap["upiEnabled"] as? Boolean ?: currentSettings.upiEnabled,
                                onlineEnabled = firebaseSettingsMap["onlineEnabled"] as? Boolean ?: currentSettings.onlineEnabled,
                                referralEnabled = firebaseSettingsMap["referralEnabled"] as? Boolean ?: currentSettings.referralEnabled,
                                referralBonus = (firebaseSettingsMap["referralBonus"] as? Number)?.toDouble() ?: currentSettings.referralBonus,
                                welcomeBonus = (firebaseSettingsMap["welcomeBonus"] as? Number)?.toDouble() ?: currentSettings.welcomeBonus,
                                returnPolicy = firebaseSettingsMap["returnPolicy"] as? String ?: currentSettings.returnPolicy,
                                privacyPolicy = firebaseSettingsMap["privacyPolicy"] as? String ?: currentSettings.privacyPolicy,
                                terms = firebaseSettingsMap["terms"] as? String ?: currentSettings.terms,
                                codAdvanceEnabled = firebaseSettingsMap["codAdvanceEnabled"] as? Boolean ?: currentSettings.codAdvanceEnabled,
                                codAdvanceAmount = (firebaseSettingsMap["codAdvanceAmount"] as? Number)?.toDouble() ?: currentSettings.codAdvanceAmount,
                                otpMode = otpModeFromFirebase
                            )
                            repository.insertStoreSettings(syncedSettings)
                            _storeSettings.value = syncedSettings
                        } else {
                            val currentSettings = repository.getStoreSettings()
                            val settingsMap = mapOf(
                                "id" to "store",
                                "storeName" to currentSettings.storeName,
                                "logoUrl" to currentSettings.logoUrl,
                                "supportWhatsApp" to currentSettings.supportWhatsApp,
                                "upiId" to currentSettings.upiId,
                                "qrImage" to currentSettings.qrImage,
                                "deliveryCharge" to currentSettings.deliveryCharge,
                                "freeDeliveryMinimum" to currentSettings.freeDeliveryMinimum,
                                "codEnabled" to currentSettings.codEnabled,
                                "upiEnabled" to currentSettings.upiEnabled,
                                "onlineEnabled" to currentSettings.onlineEnabled,
                                "referralEnabled" to currentSettings.referralEnabled,
                                "referralBonus" to currentSettings.referralBonus,
                                "welcomeBonus" to currentSettings.welcomeBonus,
                                "returnPolicy" to currentSettings.returnPolicy,
                                "privacyPolicy" to currentSettings.privacyPolicy,
                                "terms" to currentSettings.terms,
                                "otpMode" to currentSettings.otpMode
                            )
                            FirestoreService.saveStoreSettings(getApplication(), settingsMap)
                        }

                        // 3. Sync orders
                        val firebaseOrders = FirestoreService.getAllOrders(getApplication())
                        firebaseOrders.forEach { map ->
                            val order = FirestoreService.parseOrder(map["orderId"] as? String ?: "", map)
                            repository.insertOrder(order)
                        }
                    }
                } catch (e: Exception) {
                    Log.e("LiorisViewModel", "Startup Firestore sync failed", e)
                }
            }

            // Periodically refresh Store Settings and observe
            repository.observeStoreSettings().collect { settings ->
                if (settings != null) {
                    _storeSettings.value = settings
                }
            }
        }
    }

    // --- Authentication Actions ---

    val showQuickSmsWarning = MutableStateFlow(false)

    fun sendLoginOtp(forceQuick: Boolean = false) {
        val rawPhone = loginPhone.value
        val cleanedPhone = LiorisRepository.cleanPhoneNumber(rawPhone)
        if (cleanedPhone.length != 10) {
            loginError.value = "Please enter a valid 10-digit phone number."
            return
        }

        viewModelScope.launch {
            isSendingOtp.value = true
            loginError.value = ""
            loginSuccessMsg.value = ""

            // Read otpMode from Firestore before sending
            var smsMode = "test"
            try {
                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    val dbOtpMode = FirestoreService.getOtpMode(getApplication())
                    if (dbOtpMode != null) {
                        smsMode = dbOtpMode
                    } else {
                        val firebaseSettingsMap = FirestoreService.getStoreSettings(getApplication())
                        if (firebaseSettingsMap != null) {
                            smsMode = firebaseSettingsMap["otpMode"] as? String ?: "test"
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Error fetching otpMode on login", e)
            }

            // Sync with local repository
            try {
                val currentSettings = repository.getStoreSettings()
                if (currentSettings.otpMode != smsMode) {
                    repository.insertStoreSettings(currentSettings.copy(otpMode = smsMode))
                    _storeSettings.value = repository.getStoreSettings()
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Local settings sync failed", e)
            }

            if (smsMode.equals("fast2sms_quick", ignoreCase = true) && !forceQuick) {
                showQuickSmsWarning.value = true
                isSendingOtp.value = false
                return@launch
            }

            // Dynamically override OTP test mode
            OtpService.testModeOverride = smsMode.equals("test", ignoreCase = true)

            when (val result = OtpService.sendOtp(cleanedPhone, forceQuickSms = forceQuick || smsMode.equals("fast2sms_quick", ignoreCase = true))) {
                is OtpResult.Success -> {
                    isOtpSent.value = true
                    loginSuccessMsg.value = if (result.isTest) {
                        "Test OTP mode active."
                    } else {
                        "OTP Sent successfully to $cleanedPhone."
                    }
                    startOtpCooldown()
                    try {
                        repository.insertOtpLog(
                            OtpLog(
                                logId = "OTP_LOG_" + java.util.UUID.randomUUID().toString().take(6),
                                phone = cleanedPhone,
                                smsMode = if (result.isTest) "test" else if (forceQuick || smsMode.equals("fast2sms_quick", ignoreCase = true)) "fast2sms_quick" else smsMode,
                                response = result.response,
                                status = "success",
                                createdAt = System.currentTimeMillis()
                            )
                        )
                    } catch (e: Exception) {
                        Log.e("LiorisViewModel", "Failed to log OTP success", e)
                    }
                }
                is OtpResult.Error -> {
                    loginError.value = result.message
                    try {
                        repository.insertOtpLog(
                            OtpLog(
                                logId = "OTP_LOG_" + java.util.UUID.randomUUID().toString().take(6),
                                phone = cleanedPhone,
                                smsMode = if (forceQuick || smsMode.equals("fast2sms_quick", ignoreCase = true)) "fast2sms_quick" else smsMode,
                                response = result.response,
                                status = "error",
                                createdAt = System.currentTimeMillis()
                            )
                        )
                    } catch (e: Exception) {
                        Log.e("LiorisViewModel", "Failed to log OTP error", e)
                    }
                }
            }
            isSendingOtp.value = false
        }
    }

    private fun startOtpCooldown() {
        otpCooldown.value = 60
        viewModelScope.launch {
            while (otpCooldown.value > 0) {
                kotlinx.coroutines.delay(1000L)
                otpCooldown.value -= 1
            }
        }
    }

    fun verifyLoginOtp() {
        val phone = LiorisRepository.cleanPhoneNumber(loginPhone.value)
        val otp = loginOtp.value.trim()

        if (otp.length != 6) {
            loginError.value = "OTP must be exactly 6 digits."
            return
        }

        viewModelScope.launch {
            isVerifyingOtp.value = true
            loginError.value = ""

            val isValid = OtpService.verifyOtp(phone, otp)
            if (isValid) {
                try {
                    println("Saving customer to Firestore")
                    Log.d("LiorisViewModel", "Saving customer to Firestore")
                    
                    var firestoreUserMap: Map<String, Any>? = null
                    var syncError: String? = null
                    
                    try {
                        firestoreUserMap = FirestoreService.saveOrUpdateUserOnLogin(
                            context = getApplication(), 
                            rawPhone = phone, 
                            existingName = loginName.value.trim(),
                            referredByCode = referralCodeInput.value.trim()
                        )
                    } catch (fe: Exception) {
                        syncError = "Firestore save failed: ${fe.localizedMessage ?: "Firebase is not configured or connected"}"
                    }
                    
                    if (syncError != null) {
                        println("Customer save failed")
                        Log.e("LiorisViewModel", "Customer save failed: $syncError")
                        loginError.value = syncError
                        isVerifyingOtp.value = false
                        return@launch
                    }
                    
                    if (firestoreUserMap != null) {
                        // Successfully saved/updated in Firestore
                        val walletBalance = (firestoreUserMap["walletBalance"] as? Number)?.toDouble() ?: 50.0
                        val walletBonusGiven = firestoreUserMap["walletBonusGiven"] as? Boolean ?: true
                        val totalSpent = (firestoreUserMap["totalSpent"] as? Number)?.toDouble() ?: 0.0
                        
                        // Handle savedAddress conversion from Map/String
                        val savedAddressMap = firestoreUserMap["savedAddress"] as? Map<String, Any>
                        val savedAddressStr = if (savedAddressMap != null) {
                            val addr = savedAddressMap["address"] as? String ?: ""
                            val city = savedAddressMap["city"] as? String ?: ""
                            val state = savedAddressMap["state"] as? String ?: ""
                            val pincode = savedAddressMap["pincode"] as? String ?: ""
                            if (addr.isNotEmpty()) "$addr, $city, $state - $pincode" else ""
                        } else {
                            firestoreUserMap["savedAddress"] as? String ?: ""
                        }
                        
                        val syncedUser = User(
                            phone = phone,
                            name = firestoreUserMap["name"] as? String ?: "Guest $phone",
                            role = firestoreUserMap["role"] as? String ?: "user",
                            walletBalance = walletBalance,
                            walletBonusGiven = walletBonusGiven,
                            referralCode = firestoreUserMap["referralCode"] as? String ?: LiorisRepository.generateReferralCode(phone),
                            totalSpent = totalSpent,
                            savedAddress = savedAddressStr,
                            loginProvider = "phone",
                            phoneVerified = true,
                            createdAt = System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis()
                        )
                        
                        // Save/Sync to local Room database
                        repository.insertUser(syncedUser)
                        
                        isFirestoreUserLoaded.value = true
                        _loggedInUser.value = syncedUser
                        saveUserSession(syncedUser)

                        // Load and sync cart from Firestore on login
                        try {
                            val firebaseCart = FirestoreService.getCartFromFirestore(getApplication(), phone)
                            if (firebaseCart.isNotEmpty()) {
                                cartItems.clear()
                                cartItems.addAll(firebaseCart)
                            }
                        } catch (ce: Exception) {
                            Log.e("LiorisViewModel", "Failed to load cart on login", ce)
                        }

                        // Pre-fill checkout address details from profile if user has shopped before
                        checkoutName.value = syncedUser.name.replace("Guest ", "")
                        if (syncedUser.savedAddress.isNotEmpty()) {
                            val addressParts = syncedUser.savedAddress.split(",")
                            checkoutAddress.value = addressParts.getOrNull(0)?.trim() ?: ""
                            checkoutCity.value = addressParts.getOrNull(1)?.trim() ?: ""
                            checkoutState.value = addressParts.getOrNull(2)?.split("-")?.getOrNull(0)?.trim() ?: ""
                            checkoutPincode.value = addressParts.getOrNull(2)?.split("-")?.getOrNull(1)?.trim() ?: ""
                        }

                        // On successful login, clear the login fields
                        loginOtp.value = ""
                        loginName.value = ""
                        referralCodeInput.value = ""
                        isOtpSent.value = false
                        
                        // Clear pending referral from SharedPreferences once applied
                        val prefs = getApplication<android.app.Application>().getSharedPreferences("lioris_prefs", android.content.Context.MODE_PRIVATE)
                        prefs.edit().remove("pending_referral_code").apply()

                        navigateTo(Screen.Home)
                    }
                } catch (e: Exception) {
                    println("Customer save failed")
                    Log.e("LiorisViewModel", "Customer save failed", e)
                    loginError.value = "Failed to sync user: ${e.localizedMessage}"
                }
            } else {
                loginError.value = "Invalid or expired OTP. Please try again."
            }
            isVerifyingOtp.value = false
        }
    }

    fun loginWithGoogle(uid: String, email: String, displayName: String, onSuccess: () -> Unit = {}, onFailure: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                // 1. Sync or save to googleUsers in Firestore
                var syncResult: Map<String, Any>? = null
                try {
                    syncResult = FirestoreService.saveGoogleUserOnLogin(getApplication(), uid, email, displayName)
                } catch (fe: Exception) {
                    Log.e("LiorisViewModel", "Failed to sync googleUsers to Firestore", fe)
                }

                // Check if this Google user has a verifiedPhone already linked
                val verifiedPhone = syncResult?.get("verifiedPhone") as? String ?: ""
                val isPhoneVerified = syncResult?.get("phoneVerified") as? Boolean ?: false

                if (isPhoneVerified && verifiedPhone.isNotEmpty()) {
                    // They are already verified and linked! Log them in directly using their verifiedPhone
                    val firestoreUserMap = FirestoreService.saveOrUpdateUserOnLogin(getApplication(), verifiedPhone, displayName)
                    val walletBalance = (firestoreUserMap["walletBalance"] as? Number)?.toDouble() ?: 50.0
                    val walletBonusGiven = firestoreUserMap["walletBonusGiven"] as? Boolean ?: true
                    val totalSpent = (firestoreUserMap["totalSpent"] as? Number)?.toDouble() ?: 0.0

                    // Handle savedAddress conversion from Map/String
                    val savedAddressMap = firestoreUserMap["savedAddress"] as? Map<String, Any>
                    val savedAddressStr = if (savedAddressMap != null) {
                        val addr = savedAddressMap["address"] as? String ?: ""
                        val city = savedAddressMap["city"] as? String ?: ""
                        val state = savedAddressMap["state"] as? String ?: ""
                        val pincode = savedAddressMap["pincode"] as? String ?: ""
                        if (addr.isNotEmpty()) "$addr, $city, $state - $pincode" else ""
                    } else {
                        firestoreUserMap["savedAddress"] as? String ?: ""
                    }

                    val syncedUser = User(
                        phone = verifiedPhone,
                        name = firestoreUserMap["name"] as? String ?: displayName,
                        role = firestoreUserMap["role"] as? String ?: "user",
                        walletBalance = walletBalance,
                        walletBonusGiven = walletBonusGiven,
                        referralCode = firestoreUserMap["referralCode"] as? String ?: LiorisRepository.generateReferralCode(verifiedPhone),
                        totalSpent = totalSpent,
                        savedAddress = savedAddressStr,
                        email = email,
                        googleUid = uid,
                        loginProvider = "google",
                        phoneVerified = true,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )

                    repository.insertUser(syncedUser)
                    _loggedInUser.value = syncedUser
                    saveUserSession(syncedUser)

                    // Load and sync cart from Firestore on login
                    try {
                        val firebaseCart = FirestoreService.getCartFromFirestore(getApplication(), verifiedPhone)
                        if (firebaseCart.isNotEmpty()) {
                            cartItems.clear()
                            cartItems.addAll(firebaseCart)
                        }
                    } catch (ce: Exception) {
                        Log.e("LiorisViewModel", "Failed to load cart on login", ce)
                    }

                    checkoutName.value = syncedUser.name.replace("Guest ", "")
                    if (syncedUser.savedAddress.isNotEmpty()) {
                        val addressParts = syncedUser.savedAddress.split(",")
                        checkoutAddress.value = addressParts.getOrNull(0)?.trim() ?: ""
                        checkoutCity.value = addressParts.getOrNull(1)?.trim() ?: ""
                        checkoutState.value = addressParts.getOrNull(2)?.split("-")?.getOrNull(0)?.trim() ?: ""
                        checkoutPincode.value = addressParts.getOrNull(2)?.split("-")?.getOrNull(1)?.trim() ?: ""
                    }

                    onSuccess()
                    navigateTo(Screen.Home)
                } else {
                    // Google user is logged in but unverified. Let them browse the app with temporary unverified session!
                    val tempPhone = "GOOGLE_UNVERIFIED_" + uid
                    val tempUser = User(
                        phone = tempPhone,
                        name = displayName,
                        role = "user", // Do not mark admin from Google email
                        walletBalance = 0.0,
                        walletBonusGiven = false,
                        referralCode = "",
                        totalSpent = 0.0,
                        savedAddress = "",
                        email = email,
                        googleUid = uid,
                        loginProvider = "google",
                        phoneVerified = false,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )

                    // Insert temp user in Room to avoid database constraints
                    repository.insertUser(tempUser)
                    _loggedInUser.value = tempUser
                    saveUserSession(tempUser)

                    onSuccess()
                    navigateTo(Screen.Home)
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Google login failed", e)
                onFailure(e.localizedMessage ?: "Google sign-in failed")
            }
        }
    }

    fun sendCheckoutOtp() {
        val phone = LiorisRepository.cleanPhoneNumber(checkoutPhone.value)
        if (phone.length != 10) {
            checkoutOtpError.value = "Please enter a valid 10-digit phone number."
            return
        }

        viewModelScope.launch {
            isSendingCheckoutOtp.value = true
            checkoutOtpError.value = ""
            checkoutOtpSuccess.value = ""

            // Read otpMode from Firestore before sending
            var smsMode = "test"
            try {
                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    val dbOtpMode = FirestoreService.getOtpMode(getApplication())
                    if (dbOtpMode != null) {
                        smsMode = dbOtpMode
                    } else {
                        val firebaseSettingsMap = FirestoreService.getStoreSettings(getApplication())
                        if (firebaseSettingsMap != null) {
                            smsMode = firebaseSettingsMap["otpMode"] as? String ?: "test"
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Error fetching otpMode on checkout", e)
            }

            // Sync with local repository
            try {
                val currentSettings = repository.getStoreSettings()
                if (currentSettings.otpMode != smsMode) {
                    repository.insertStoreSettings(currentSettings.copy(otpMode = smsMode))
                    _storeSettings.value = repository.getStoreSettings()
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Local settings sync failed", e)
            }

            // Dynamically override OTP test mode
            val isTest = smsMode.equals("test", ignoreCase = true)
            OtpService.testModeOverride = isTest

            val forceQuick = smsMode.equals("fast2sms_quick", ignoreCase = true)

            when (val result = OtpService.sendOtp(phone, forceQuick)) {
                is OtpResult.Success -> {
                    isCheckoutOtpSent.value = true
                    checkoutOtpSuccess.value = if (result.isTest) {
                        "Test OTP mode active."
                    } else {
                        "OTP sent successfully to +91 $phone"
                    }
                    startCheckoutOtpCooldown()
                }
                is OtpResult.Error -> {
                    checkoutOtpError.value = result.message
                }
            }
            isSendingCheckoutOtp.value = false
        }
    }

    private fun startCheckoutOtpCooldown() {
        checkoutOtpCooldown.value = 60
        viewModelScope.launch {
            while (checkoutOtpCooldown.value > 0) {
                kotlinx.coroutines.delay(1000L)
                checkoutOtpCooldown.value -= 1
            }
        }
    }

    fun verifyCheckoutOtp(onVerified: () -> Unit = {}) {
        val rawPhone = checkoutPhone.value
        val phone = LiorisRepository.cleanPhoneNumber(rawPhone)
        val otp = checkoutOtp.value.trim()
        val currentUser = _loggedInUser.value

        if (otp.length != 6) {
            checkoutOtpError.value = "OTP must be exactly 6 digits."
            return
        }
        if (currentUser == null || currentUser.googleUid.isEmpty()) {
            checkoutOtpError.value = "Session error. Please log in again."
            return
        }

        viewModelScope.launch {
            isVerifyingCheckoutOtp.value = true
            checkoutOtpError.value = ""
            checkoutOtpSuccess.value = ""

            val isValid = OtpService.verifyOtp(phone, otp)
            if (isValid) {
                try {
                    // Link google account with phone
                    val syncData = FirestoreService.linkGoogleUserWithPhone(
                        context = getApplication(),
                        rawPhone = phone,
                        email = currentUser.email,
                        displayName = currentUser.name,
                        googleUid = currentUser.googleUid
                    )

                    val walletBalance = (syncData["walletBalance"] as? Number)?.toDouble() ?: 50.0
                    val walletBonusGiven = syncData["walletBonusGiven"] as? Boolean ?: true
                    val totalSpent = (syncData["totalSpent"] as? Number)?.toDouble() ?: 0.0

                    // Convert address
                    val savedAddressMap = syncData["savedAddress"] as? Map<String, Any>
                    val savedAddressStr = if (savedAddressMap != null) {
                        val addr = savedAddressMap["address"] as? String ?: ""
                        val city = savedAddressMap["city"] as? String ?: ""
                        val state = savedAddressMap["state"] as? String ?: ""
                        val pincode = savedAddressMap["pincode"] as? String ?: ""
                        if (addr.isNotEmpty()) "$addr, $city, $state - $pincode" else ""
                    } else {
                        syncData["savedAddress"] as? String ?: ""
                    }

                    // Create the linked User
                    val linkedUser = User(
                        phone = phone,
                        name = syncData["name"] as? String ?: currentUser.name,
                        role = syncData["role"] as? String ?: "user",
                        walletBalance = walletBalance,
                        walletBonusGiven = walletBonusGiven,
                        referralCode = syncData["referralCode"] as? String ?: LiorisRepository.generateReferralCode(phone),
                        totalSpent = totalSpent,
                        savedAddress = savedAddressStr,
                        email = currentUser.email,
                        googleUid = currentUser.googleUid,
                        loginProvider = "google",
                        phoneVerified = true,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )

                    // Transfer cart items from unverified session to verified session
                    val oldTempPhone = currentUser.phone
                    repository.insertUser(linkedUser)
                    _loggedInUser.value = linkedUser
                    saveUserSession(linkedUser)

                    // Insert Welcome Wallet Transaction locally if they got the welcome bonus
                    if (walletBonusGiven && walletBalance >= 50.0) {
                        try {
                            repository.insertWalletTransaction(
                                com.example.data.WalletTransaction(
                                    transactionId = "WT_WELCOME_" + java.util.UUID.randomUUID().toString().take(6),
                                    userId = phone,
                                    phone = phone,
                                    type = "CREDIT",
                                    amount = 50.0,
                                    reason = "Welcome Bonus",
                                    createdAt = System.currentTimeMillis()
                                )
                            )
                            repository.insertNotification(
                                com.example.data.Notification(
                                    notificationId = "NT_" + java.util.UUID.randomUUID().toString().take(6),
                                    title = "Welcome to LIORIS! ✨",
                                    message = "Congratulations! A ₹50 welcome bonus has been credited to your Lioris Wallet.",
                                    target = "phone",
                                    phone = phone,
                                    read = false
                                )
                            )
                        } catch (e: Exception) {
                            Log.e("LiorisViewModel", "Failed to insert local welcome wallet transaction", e)
                        }
                    }

                    // Save cart to Firestore under the new verified phone number
                    try {
                        FirestoreService.saveCartToFirestore(getApplication(), phone, cartItems.toList())
                    } catch (e: Exception) {
                        Log.e("LiorisViewModel", "Failed to sync cart on linking", e)
                    }

                    // Clean states
                    checkoutPhone.value = ""
                    checkoutOtp.value = ""
                    isCheckoutOtpSent.value = false

                    checkoutOtpSuccess.value = "Phone number verified and linked successfully!"
                    onVerified()
                } catch (e: Exception) {
                    Log.e("LiorisViewModel", "Phone linking failed", e)
                    checkoutOtpError.value = "Failed to link phone: ${e.localizedMessage}"
                }
            } else {
                checkoutOtpError.value = "Invalid or expired OTP. Please try again."
            }
            isVerifyingCheckoutOtp.value = false
        }
    }

    fun logout() {
        _loggedInUser.value = null
        clearUserSession()
        navigateTo(Screen.Login, clearStack = true)
        cartItems.clear()
        _appliedCoupon.value = null
        useWallet.value = false
        isFirestoreUserLoaded.value = false
    }

    fun refreshUserFromFirestore() {
        val currentUser = _loggedInUser.value ?: return
        viewModelScope.launch {
            try {
                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    val cleaned = FirestoreService.cleanPhone(currentUser.phone)
                    val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    db.collection("users").document(cleaned).get().addOnCompleteListener { task ->
                        if (task.isSuccessful && task.result?.exists() == true) {
                            val doc = task.result
                            isFirestoreUserLoaded.value = true
                            viewModelScope.launch {
                                try {
                                    val name = doc.getString("name") ?: currentUser.name
                                    val walletBalance = doc.getDouble("walletBalance") ?: currentUser.walletBalance
                                    val role = doc.getString("role") ?: currentUser.role
                                    val walletBonusGiven = doc.getBoolean("walletBonusGiven") ?: currentUser.walletBonusGiven
                                    val referralCode = doc.getString("referralCode") ?: currentUser.referralCode
                                    
                                    val savedAddressMap = doc.get("savedAddress") as? Map<String, Any>
                                    val savedAddressStr = if (savedAddressMap != null) {
                                        val addr = savedAddressMap["address"] as? String ?: ""
                                        val city = savedAddressMap["city"] as? String ?: ""
                                        val state = savedAddressMap["state"] as? String ?: ""
                                        val pincode = savedAddressMap["pincode"] as? String ?: ""
                                        if (addr.isNotEmpty()) "$addr, $city, $state - $pincode" else ""
                                    } else {
                                        doc.get("savedAddress") as? String ?: ""
                                    }
                                    
                                    val phoneVerified = doc.getBoolean("phoneVerified") ?: currentUser.phoneVerified
                                    val loginProvider = doc.getString("loginProvider") ?: currentUser.loginProvider
                                    val email = doc.getString("email") ?: currentUser.email
                                    val googleUid = doc.getString("googleUid") ?: currentUser.googleUid
                                    
                                    val updatedLocalUser = currentUser.copy(
                                        name = name,
                                        walletBalance = walletBalance,
                                        role = role,
                                        walletBonusGiven = walletBonusGiven,
                                        referralCode = referralCode,
                                        savedAddress = savedAddressStr,
                                        phoneVerified = phoneVerified,
                                        loginProvider = loginProvider,
                                        email = email,
                                        googleUid = googleUid
                                    )
                                    repository.insertUser(updatedLocalUser)
                                    _loggedInUser.value = updatedLocalUser
                                    saveUserSession(updatedLocalUser)
                                } catch (e: Exception) {
                                    Log.e("LiorisViewModel", "Error updating local user from firestore doc", e)
                                }
                            }
                        } else {
                            isFirestoreUserLoaded.value = false
                        }
                    }
                } else {
                    isFirestoreUserLoaded.value = false
                }
            } catch (e: Exception) {
                isFirestoreUserLoaded.value = false
            }
        }
    }

    // --- Shopping Cart Actions ---

    private fun syncCartToFirestore() {
        val user = _loggedInUser.value ?: return
        viewModelScope.launch {
            try {
                FirestoreService.saveCartToFirestore(getApplication(), user.phone, cartItems.toList())
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Failed to sync cart to Firestore", e)
            }
        }
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        val size = pdpSize.value
        val color = pdpColor.value

        val existing = cartItems.find { it.productId == product.id && it.selectedSize == size && it.selectedColor == color }
        if (existing != null) {
            val idx = cartItems.indexOf(existing)
            cartItems[idx] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            cartItems.add(
                CartItem(
                    productId = product.id,
                    productName = product.name,
                    price = product.price,
                    quantity = quantity,
                    imageUrl = product.images.split(",").firstOrNull() ?: "",
                    selectedSize = size,
                    selectedColor = color
                )
            )
        }

        // Reset quick selections
        pdpSize.value = ""
        pdpColor.value = ""
        
        syncCartToFirestore()
    }

    fun removeFromCart(item: CartItem) {
        cartItems.remove(item)
        validateCouponForCart()
        syncCartToFirestore()
    }

    fun updateCartQuantity(item: CartItem, delta: Int) {
        val idx = cartItems.indexOf(item)
        if (idx != -1) {
            val newQty = item.quantity + delta
            if (newQty <= 0) {
                cartItems.removeAt(idx)
            } else {
                cartItems[idx] = item.copy(quantity = newQty)
            }
        }
        validateCouponForCart()
        syncCartToFirestore()
    }

    // Coupon Actions
    fun applyCoupon(code: String) {
        couponError.value = ""
        if (code.isEmpty()) return

        viewModelScope.launch {
            val coupon = repository.getCouponByCode(code)
            if (coupon == null) {
                couponError.value = "Invalid Coupon Code"
                _appliedCoupon.value = null
                return@launch
            }

            if (!coupon.active) {
                couponError.value = "This coupon is currently inactive."
                _appliedCoupon.value = null
                return@launch
            }

            if (coupon.usedCount >= coupon.usageLimit) {
                couponError.value = "Coupon limit exceeded."
                _appliedCoupon.value = null
                return@launch
            }

            if (coupon.expiryDate > 0L && System.currentTimeMillis() > coupon.expiryDate) {
                couponError.value = "Coupon has expired."
                _appliedCoupon.value = null
                return@launch
            }

            val subtotal = getCartSubtotal()
            if (subtotal < coupon.minOrder) {
                couponError.value = "Minimum order value is ₹${coupon.minOrder.toInt()} to apply this coupon."
                _appliedCoupon.value = null
                return@launch
            }

            _appliedCoupon.value = coupon
        }
    }

    fun removeCoupon() {
        _appliedCoupon.value = null
        couponError.value = ""
    }

    private fun validateCouponForCart() {
        val coupon = _appliedCoupon.value ?: return
        val subtotal = getCartSubtotal()
        if (subtotal < coupon.minOrder) {
            _appliedCoupon.value = null
            couponError.value = "Coupon removed as cart value fell below ₹${coupon.minOrder.toInt()}."
        }
    }

    // --- Checkout Calculations ---

    fun getCartSubtotal(): Double {
        return cartItems.sumOf { it.price * it.quantity }
    }

    fun getCouponDiscount(): Double {
        val coupon = _appliedCoupon.value ?: return 0.0
        val subtotal = getCartSubtotal()
        return if (coupon.type == "PERCENT") {
            val discount = subtotal * (coupon.value / 100.0)
            discount.coerceAtMost(coupon.maxDiscount)
        } else {
            coupon.value.coerceAtMost(subtotal)
        }
    }

    fun getDeliveryCharge(): Double {
        val subtotal = getCartSubtotal()
        val settings = _storeSettings.value
        return if (subtotal >= settings.freeDeliveryMinimum) 0.0 else settings.deliveryCharge
    }

    fun getTotalBeforeWallet(): Double {
        val subtotal = getCartSubtotal()
        val delivery = getDeliveryCharge()
        val discount = getCouponDiscount()
        return (subtotal + delivery - discount).coerceAtLeast(0.0)
    }

    fun getWalletAmountUsed(): Double {
        if (!useWallet.value) return 0.0
        val userBalance = _loggedInUser.value?.walletBalance ?: 0.0
        val totalBefore = getTotalBeforeWallet()
        // Wallet can be used up to 50% of the totalBeforeWallet!
        val maxWalletAllowed = totalBefore * 0.5
        return minOf(userBalance, maxWalletAllowed).coerceAtLeast(0.0)
    }

    fun getFinalPayableAmount(): Double {
        val totalBefore = getTotalBeforeWallet()
        val wallet = getWalletAmountUsed()
        val basePayable = (totalBefore - wallet).coerceAtLeast(0.0)
        val settings = storeSettings.value
        if (checkoutPaymentMethod.value == "COD" && settings.codAdvanceEnabled) {
            return (basePayable - settings.codAdvanceAmount).coerceAtLeast(0.0)
        }
        return basePayable
    }

    // Gift check
    fun isGiftUnlocked(): Boolean {
        val subtotal = getCartSubtotal()
        val giftOffer = activeGiftOffers.value.firstOrNull() ?: return false
        return subtotal >= giftOffer.minOrderValue
    }

    fun getGiftOfferProgress(): Float {
        val subtotal = getCartSubtotal()
        val giftOffer = activeGiftOffers.value.firstOrNull() ?: return 0f
        return (subtotal / giftOffer.minOrderValue).toFloat().coerceIn(0f, 1f)
    }

    fun getGiftOfferShortfall(): Double {
        val subtotal = getCartSubtotal()
        val giftOffer = activeGiftOffers.value.firstOrNull() ?: return 0.0
        return (giftOffer.minOrderValue - subtotal).coerceAtLeast(0.0)
    }

    fun getGiftItemName(): String {
        return activeGiftOffers.value.firstOrNull()?.giftName ?: ""
    }

    // Place Order Operation
    fun checkoutPlaceOrder(onSuccess: (String) -> Unit, onFailure: (String) -> Unit) {
        val user = _loggedInUser.value
        if (user == null) {
            onFailure("You must be logged in to place an order.")
            return
        }

        if (cartItems.isEmpty()) {
            onFailure("Your cart is empty.")
            return
        }

        val name = checkoutName.value.trim()
        val addr = checkoutAddress.value.trim()
        val pin = checkoutPincode.value.trim()
        val city = checkoutCity.value.trim()
        val state = checkoutState.value.trim()
        val paymentMethod = checkoutPaymentMethod.value

        if (name.isEmpty() || addr.isEmpty() || pin.isEmpty() || city.isEmpty() || state.isEmpty()) {
            onFailure("Please fill in all required shipping address fields.")
            return
        }

        if (paymentMethod == "UPI" && checkoutUtr.value.trim().isEmpty()) {
            onFailure("Please enter the 12-digit UPI UTR Transaction ID to submit.")
            return
        }

        val settings = storeSettings.value
        if (paymentMethod == "COD" && settings.codAdvanceEnabled && checkoutUtr.value.trim().isEmpty()) {
            onFailure("Please enter the 12-digit COD Advance Payment UPI UTR Transaction ID to submit.")
            return
        }

        viewModelScope.launch {
            try {
                val subtotal = getCartSubtotal()
                val delivery = getDeliveryCharge()
                val discount = getCouponDiscount()
                val wallet = getWalletAmountUsed()
                val totalBefore = getTotalBeforeWallet()
                val finalPayable = getFinalPayableAmount()
                val giftUnlocked = isGiftUnlocked()
                val giftItem = if (giftUnlocked) getGiftItemName() else ""

                val order = repository.placeOrder(
                    userId = user.phone,
                    customerName = name,
                    address = addr,
                    pincode = pin,
                    city = city,
                    state = state,
                    landmark = checkoutLandmark.value.trim(),
                    cartItems = cartItems.toList(),
                    subtotal = subtotal,
                    deliveryCharge = delivery,
                    couponCode = _appliedCoupon.value?.code ?: "",
                    couponDiscount = discount,
                    walletUsed = wallet,
                    totalBeforeWallet = totalBefore,
                    finalPayable = finalPayable,
                    paymentMethod = paymentMethod,
                    utr = checkoutUtr.value.trim(),
                    giftUnlocked = giftUnlocked,
                    giftItem = giftItem,
                    loginProvider = user.loginProvider,
                    googleUid = user.googleUid
                )

                // Trigger Telegram message in background and update status
                val itemsCopy = cartItems.toList()
                viewModelScope.launch {
                    try {
                        val telegramResult = TelegramService.sendOrderNotification(order, itemsCopy)
                        val updatedOrder = when (telegramResult) {
                            is TelegramService.TelegramResult.Success -> {
                                order.copy(
                                    telegramNotificationStatus = "sent",
                                    telegramNotificationError = "",
                                    telegramNotificationAt = System.currentTimeMillis()
                                )
                            }
                            is TelegramService.TelegramResult.Skipped -> {
                                order.copy(
                                    telegramNotificationStatus = "skipped",
                                    telegramNotificationError = "",
                                    telegramNotificationAt = System.currentTimeMillis()
                                )
                            }
                            is TelegramService.TelegramResult.Failure -> {
                                order.copy(
                                    telegramNotificationStatus = "failed",
                                    telegramNotificationError = telegramResult.error,
                                    telegramNotificationAt = System.currentTimeMillis()
                                )
                            }
                        }
                        repository.updateOrder(updatedOrder)

                        // Log to adminNotifications table
                        val adminNotif = AdminNotification(
                            id = "AN_" + java.util.UUID.randomUUID().toString().take(6),
                            orderId = order.orderId,
                            status = when (telegramResult) {
                                is TelegramService.TelegramResult.Success -> "sent"
                                is TelegramService.TelegramResult.Skipped -> "skipped"
                                is TelegramService.TelegramResult.Failure -> "failed"
                            },
                            errorMessage = when (telegramResult) {
                                is TelegramService.TelegramResult.Failure -> telegramResult.error
                                else -> ""
                            },
                            createdAt = System.currentTimeMillis()
                        )
                        repository.insertAdminNotification(adminNotif)
                    } catch (te: Exception) {
                        Log.e("LiorisViewModel", "Telegram background logging failed", te)
                    }
                }

                // Fetch the fresh user balance from repository
                val freshUser = repository.getUserByPhone(user.phone)

                // Firestore checkout and customer update
                try {
                    val settings = storeSettings.value
                    val isCodAdvance = paymentMethod == "COD" && settings.codAdvanceEnabled
                    val finalAdvancePaid = if (isCodAdvance) settings.codAdvanceAmount else 0.0
                    val finalAdvanceUtr = if (isCodAdvance) checkoutUtr.value.trim() else ""
                    val computedStatus = when {
                        paymentMethod == "COD" && settings.codAdvanceEnabled -> "COD Advance Paid Pending Verification"
                        paymentMethod == "COD" -> "Accepted"
                        else -> "Payment Verification Pending"
                    }
                    val computedPaymentStatus = when {
                        paymentMethod == "COD" && settings.codAdvanceEnabled -> "COD Advance Paid Pending Verification"
                        paymentMethod == "COD" -> "Pending"
                        else -> "Payment Verification Pending"
                    }

                    val orderDetailsMap = mapOf(
                        "subtotal" to subtotal,
                        "deliveryCharge" to delivery,
                        "couponCode" to (_appliedCoupon.value?.code ?: ""),
                        "couponDiscount" to discount,
                        "walletUsed" to wallet,
                        "totalBeforeWallet" to totalBefore,
                        "paymentMethod" to paymentMethod,
                        "utr" to if (paymentMethod == "UPI") checkoutUtr.value.trim() else "",
                        "loginProvider" to user.loginProvider,
                        "googleUid" to user.googleUid,
                        "status" to computedStatus,
                        "paymentStatus" to computedPaymentStatus,
                        "advancePaid" to finalAdvancePaid,
                        "advanceUtr" to finalAdvanceUtr
                    )
                    FirestoreService.saveOrderOnCheckout(
                        context = getApplication(),
                        orderId = order.orderId,
                        customerName = name,
                        phone = user.phone,
                        address = addr,
                        pincode = pin,
                        city = city,
                        state = state,
                        landmark = checkoutLandmark.value.trim(),
                        finalPayable = finalPayable,
                        otherOrderData = orderDetailsMap,
                        newWalletBalance = freshUser?.walletBalance
                    )
                } catch (fe: Exception) {
                    Log.e("LiorisViewModel", "Firestore checkout save failed", fe)
                    val exactError = "Firestore save failed: ${fe.localizedMessage ?: "Firebase not configured or connected"}"
                    onFailure(exactError)
                    return@launch
                }

                // On success:
                val completedId = order.orderId
                cartItems.clear()
                _appliedCoupon.value = null
                useWallet.value = false
                checkoutUtr.value = ""

                // Sync cleared cart to Firestore
                syncCartToFirestore()

                // Re-sync user info to show correct wallet balance in frontend instantly
                if (freshUser != null) {
                    _loggedInUser.value = freshUser
                }

                // Apply referral rewards for referrer on first valid order
                viewModelScope.launch {
                    try {
                        FirestoreService.checkAndApplyReferralReward(getApplication(), user.phone)
                    } catch (re: Exception) {
                        Log.e("LiorisViewModel", "Failed to check referral reward post order", re)
                    }
                }

                onSuccess(completedId)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Checkout failure", e)
                onFailure(e.localizedMessage ?: "Failed to place order. Please try again.")
            }
        }
    }

    // --- Admin Dashboard / Management Actions ---

    fun adminAddProduct(product: Product) {
        viewModelScope.launch {
            repository.insertProduct(product)
            try {
                FirestoreService.saveOrUpdateProduct(getApplication(), product)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore add product failed", e)
            }
        }
    }

    fun adminEditProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
            try {
                FirestoreService.saveOrUpdateProduct(getApplication(), product)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore edit product failed", e)
            }
        }
    }

    fun adminDeleteProduct(id: String) {
        viewModelScope.launch {
            repository.deleteProductById(id)
            try {
                FirestoreService.deleteProduct(getApplication(), id)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore delete product failed", e)
            }
        }
    }

    // --- Deep Link Handler ---
    fun handleDeepLink(uri: android.net.Uri?) {
        if (uri == null) return
        Log.d("LiorisViewModel", "handleDeepLink called with: $uri")
        try {
            val pathSegments = uri.pathSegments
            val host = uri.host

            var productId: String? = null
            if (host == "product") {
                productId = pathSegments.getOrNull(0)
            } else if (pathSegments.getOrNull(0) == "product") {
                productId = pathSegments.getOrNull(1)
            }

            val refCode = uri.getQueryParameter("ref")
            if (!refCode.isNullOrEmpty()) {
                val prefs = getApplication<android.app.Application>().getSharedPreferences("lioris_prefs", android.content.Context.MODE_PRIVATE)
                prefs.edit().putString("pending_referral_code", refCode).apply()
                referralCodeInput.value = refCode
                Log.d("LiorisViewModel", "Captured referral code: $refCode")
            }

            if (!productId.isNullOrEmpty()) {
                navigateTo(Screen.ProductDetail(productId))
                Log.d("LiorisViewModel", "Navigated to product detail for ID: $productId")
            }
        } catch (e: Exception) {
            Log.e("LiorisViewModel", "Error handling deep link", e)
        }
    }

    fun adminAddBanner(banner: Banner) {
        viewModelScope.launch {
            repository.insertBanner(banner)
            try {
                FirestoreService.saveBannerToFirestore(getApplication(), banner)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore save banner failed", e)
            }
        }
    }

    fun adminDeleteBanner(id: String) {
        viewModelScope.launch {
            repository.deleteBannerById(id)
            try {
                FirestoreService.deleteBannerFromFirestore(getApplication(), id)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore delete banner failed", e)
            }
        }
    }

    fun adminAddCoupon(coupon: Coupon) {
        viewModelScope.launch {
            repository.insertCoupon(coupon)
            try {
                FirestoreService.saveCouponToFirestore(getApplication(), coupon)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore save coupon failed", e)
            }
        }
    }

    fun adminDeleteCoupon(code: String) {
        viewModelScope.launch {
            repository.deleteCouponByCode(code)
            try {
                FirestoreService.deleteCouponFromFirestore(getApplication(), code)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore delete coupon failed", e)
            }
        }
    }

    fun adminAddGiftOffer(offer: GiftOffer) {
        viewModelScope.launch {
            repository.insertGiftOffer(offer)
            try {
                FirestoreService.saveGiftOfferToFirestore(getApplication(), offer)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore save gift offer failed", e)
            }
        }
    }

    fun adminDeleteGiftOffer(id: String) {
        viewModelScope.launch {
            repository.deleteGiftOfferById(id)
            try {
                FirestoreService.deleteGiftOfferFromFirestore(getApplication(), id)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore delete gift offer failed", e)
            }
        }
    }

    fun submitReturnRequest(orderId: String, reason: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            try {
                // Update locally
                val order = repository.getOrderById(orderId)
                if (order == null) {
                    onFailure("Order not found.")
                    return@launch
                }
                
                val updatedOrder = order.copy(
                    status = "Return Requested",
                    returnReason = reason,
                    returnRequestedAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
                repository.insertOrder(updatedOrder)
                
                // Update in Firestore
                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    FirestoreService.submitReturnRequest(getApplication(), orderId, reason)
                }
                
                // Add an admin notification
                val adminNotif = AdminNotification(
                    id = "AN_" + java.util.UUID.randomUUID().toString().take(6),
                    orderId = orderId,
                    status = "return_requested",
                    errorMessage = "Reason: $reason",
                    createdAt = System.currentTimeMillis()
                )
                repository.insertAdminNotification(adminNotif)

                onSuccess()
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Return request submission failed", e)
                onFailure(e.message ?: "Failed to submit return request.")
            }
        }
    }

    fun adminUpdateOrderStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            val updatedOrder = repository.updateOrderStatus(orderId, newStatus)
            try {
                FirestoreService.updateOrderStatus(getApplication(), orderId, newStatus, updatedOrder?.paymentStatus)
                // If order was cancelled and had wallet refund, sync user's new wallet balance to Firestore
                if (newStatus == "Cancelled" && updatedOrder != null) {
                    val user = repository.getUserByPhone(updatedOrder.userId)
                    if (user != null) {
                        FirestoreService.syncUserToFirestore(getApplication(), user)
                    }
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore update order status failed", e)
            }
        }
    }

    fun adminAdjustWallet(phone: String, amount: Double, reason: String, type: String) {
        viewModelScope.launch {
            val updatedUser = repository.adjustUserWallet(phone, amount, reason, type)
            if (updatedUser != null) {
                try {
                    FirestoreService.syncUserToFirestore(getApplication(), updatedUser)
                    FirestoreService.saveWalletTransaction(
                        context = getApplication(),
                        phone = phone,
                        type = type,
                        amount = amount,
                        reason = reason
                    )
                } catch (e: Exception) {
                    Log.e("LiorisViewModel", "Firestore sync adjusted user wallet failed", e)
                }
                if (updatedUser.phone == _loggedInUser.value?.phone) {
                    _loggedInUser.value = updatedUser
                }
            }
        }
    }

    fun updateSavedAddress(newAddress: String) {
        val currentUser = _loggedInUser.value ?: return
        val updatedUser = currentUser.copy(savedAddress = newAddress, updatedAt = System.currentTimeMillis())
        _loggedInUser.value = updatedUser
        saveUserSession(updatedUser)
        viewModelScope.launch {
            try {
                repository.insertUser(updatedUser)
                if (FirestoreService.isFirebaseConfigured(getApplication())) {
                    FirestoreService.syncUserToFirestore(getApplication(), updatedUser)
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Failed to sync updated address", e)
            }
        }
    }

    fun adminSendNotification(title: String, message: String, targetPhone: String = "") {
        viewModelScope.launch {
            val notification = Notification(
                notificationId = "NT_" + UUID.randomUUID().toString().take(6),
                title = title,
                message = message,
                target = if (targetPhone.isEmpty()) "all" else "phone",
                phone = targetPhone
            )
            repository.insertNotification(notification)
            try {
                FirestoreService.saveNotificationToFirestore(getApplication(), notification)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore send notification failed", e)
            }
        }
    }

    fun adminSaveSettings(settings: StoreSettings) {
        viewModelScope.launch {
            repository.insertStoreSettings(settings)
            _storeSettings.value = settings
            try {
                val settingsMap = mapOf(
                    "id" to "store",
                    "storeName" to settings.storeName,
                    "logoUrl" to settings.logoUrl,
                    "supportWhatsApp" to settings.supportWhatsApp,
                    "upiId" to settings.upiId,
                    "qrImage" to settings.qrImage,
                    "deliveryCharge" to settings.deliveryCharge,
                    "freeDeliveryMinimum" to settings.freeDeliveryMinimum,
                    "codEnabled" to settings.codEnabled,
                    "upiEnabled" to settings.upiEnabled,
                    "onlineEnabled" to settings.onlineEnabled,
                    "referralEnabled" to settings.referralEnabled,
                    "referralBonus" to settings.referralBonus,
                    "welcomeBonus" to settings.welcomeBonus,
                    "returnPolicy" to settings.returnPolicy,
                    "privacyPolicy" to settings.privacyPolicy,
                    "terms" to settings.terms,
                    "codAdvanceEnabled" to settings.codAdvanceEnabled,
                    "codAdvanceAmount" to settings.codAdvanceAmount,
                    "otpMode" to settings.otpMode
                )
                FirestoreService.saveStoreSettings(getApplication(), settingsMap)
                FirestoreService.saveOtpMode(getApplication(), settings.otpMode)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Firestore save settings failed", e)
            }
        }
    }

    fun adminRepairWalletDeductions(onComplete: (Int) -> Unit) {
        viewModelScope.launch {
            val count = repository.repairWalletDeductions()
            onComplete(count)
        }
    }

    fun adminSendTestTelegramMessage(onResult: (String?) -> Unit) {
        viewModelScope.launch {
            when (val result = TelegramService.sendTestMessage()) {
                is TelegramService.TelegramResult.Success -> onResult(null)
                is TelegramService.TelegramResult.Failure -> onResult(result.error)
                is TelegramService.TelegramResult.Skipped -> onResult("Skipped: Credentials missing or placeholder.")
            }
        }
    }

    fun markAllNotificationsAsRead() {
        val currentUser = _loggedInUser.value ?: return
        viewModelScope.launch {
            try {
                repository.markAllNotificationsAsReadForUser(currentUser.phone)
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Failed to mark notifications as read", e)
            }
        }
    }

    fun saveUserSession(user: com.example.data.User) {
        val prefs = getApplication<android.app.Application>().getSharedPreferences("lioris_prefs", android.content.Context.MODE_PRIVATE)
        prefs.edit()
            .putString("session_phone", user.phone)
            .putString("session_name", user.name)
            .putString("session_email", user.email)
            .putString("session_google_uid", user.googleUid)
            .putString("session_login_provider", user.loginProvider)
            .putBoolean("session_phone_verified", user.phoneVerified)
            .apply()
    }

    fun clearUserSession() {
        val prefs = getApplication<android.app.Application>().getSharedPreferences("lioris_prefs", android.content.Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    fun restoreUserSession() {
        val prefs = getApplication<android.app.Application>().getSharedPreferences("lioris_prefs", android.content.Context.MODE_PRIVATE)
        val phone = prefs.getString("session_phone", null) ?: return
        val name = prefs.getString("session_name", "") ?: ""
        val email = prefs.getString("session_email", "") ?: ""
        val googleUid = prefs.getString("session_google_uid", "") ?: ""
        val loginProvider = prefs.getString("session_login_provider", "") ?: ""
        val phoneVerified = prefs.getBoolean("session_phone_verified", false)

        viewModelScope.launch {
            try {
                // Try to get from database first
                val localUser = repository.getUserByPhone(phone)
                if (localUser != null) {
                    _loggedInUser.value = localUser
                } else {
                    // Create temp/fallback User object so they can proceed immediately
                    val fallbackUser = com.example.data.User(
                        phone = phone,
                        name = name,
                        email = email,
                        googleUid = googleUid,
                        loginProvider = loginProvider,
                        phoneVerified = phoneVerified,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                    repository.insertUser(fallbackUser)
                    _loggedInUser.value = fallbackUser
                }

                // If phone is verified and Firebase is configured, sync fresh data in background!
                if (phoneVerified && !phone.startsWith("GOOGLE_UNVERIFIED_")) {
                    if (FirestoreService.isFirebaseConfigured(getApplication())) {
                        val dbMap = FirestoreService.saveOrUpdateUserOnLogin(getApplication(), phone, name)
                        val walletBalance = (dbMap["walletBalance"] as? Number)?.toDouble() ?: 50.0
                        val walletBonusGiven = dbMap["walletBonusGiven"] as? Boolean ?: true
                        val totalSpent = (dbMap["totalSpent"] as? Number)?.toDouble() ?: 0.0

                        val savedAddressMap = dbMap["savedAddress"] as? Map<String, Any>
                        val savedAddressStr = if (savedAddressMap != null) {
                            val addr = savedAddressMap["address"] as? String ?: ""
                            val city = savedAddressMap["city"] as? String ?: ""
                            val state = savedAddressMap["state"] as? String ?: ""
                            val pincode = savedAddressMap["pincode"] as? String ?: ""
                            if (addr.isNotEmpty()) "$addr, $city, $state - $pincode" else ""
                        } else {
                            dbMap["savedAddress"] as? String ?: ""
                        }

                        val freshUser = com.example.data.User(
                            phone = phone,
                            name = dbMap["name"] as? String ?: name,
                            role = dbMap["role"] as? String ?: "user",
                            walletBalance = walletBalance,
                            walletBonusGiven = walletBonusGiven,
                            referralCode = dbMap["referralCode"] as? String ?: LiorisRepository.generateReferralCode(phone),
                            totalSpent = totalSpent,
                            savedAddress = savedAddressStr,
                            email = email,
                            googleUid = googleUid,
                            loginProvider = loginProvider,
                            phoneVerified = true,
                            createdAt = System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis()
                        )
                        repository.insertUser(freshUser)
                        _loggedInUser.value = freshUser
                    }
                }

                // Pre-fill checkout fields if restored
                val current = _loggedInUser.value
                if (current != null) {
                    checkoutName.value = current.name.replace("Guest ", "")
                    if (current.savedAddress.isNotEmpty()) {
                        val addressParts = current.savedAddress.split(",")
                        checkoutAddress.value = addressParts.getOrNull(0)?.trim() ?: ""
                        checkoutCity.value = addressParts.getOrNull(1)?.trim() ?: ""
                        checkoutState.value = addressParts.getOrNull(2)?.split("-")?.getOrNull(0)?.trim() ?: ""
                        checkoutPincode.value = addressParts.getOrNull(2)?.split("-")?.getOrNull(1)?.trim() ?: ""
                    }
                    navigateTo(Screen.Home)
                }
            } catch (e: Exception) {
                Log.e("LiorisViewModel", "Failed to restore user session", e)
            }
        }
    }
}

// Sealed class representing type-safe screens in LIORIS app
sealed class Screen {
    object Splash : Screen()
    object Login : Screen()
    object Home : Screen()
    data class ProductDetail(val productId: String) : Screen()
    object Cart : Screen()
    object Checkout : Screen()
    object Orders : Screen()
    data class OrderSuccess(val orderId: String) : Screen()
    object Wallet : Screen()
    object Profile : Screen()
    object Notifications : Screen()

    // Admin Screens
    object AdminDashboard : Screen()
    object AdminProducts : Screen()
    object AdminOrders : Screen()
    object AdminCustomers : Screen()
    object AdminBanners : Screen()
    object AdminCoupons : Screen()
    object AdminGifts : Screen()
    object AdminWallet : Screen()
    object AdminNotifications : Screen()
    object AdminSettings : Screen()

    // Tracking
    data class TrackOrder(val orderId: String) : Screen()
}
