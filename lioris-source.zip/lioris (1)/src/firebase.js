import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics, isSupported } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyCWRHdFe2eWERga6QG6sehG8B-WJXEM7-s",
  authDomain: "luxora-store-58762.firebaseapp.com",
  projectId: "luxora-store-58762",
  storageBucket: "luxora-store-58762.firebasestorage.app",
  messagingSenderId: "357730641920",
  appId: "1:357730641920:web:6b43af5bd9953e537e50e5",
  measurementId: "G-5C0EXV6FGT"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const storage = getStorage(app);

export const initAnalytics = async () => {
  try {
    if (await isSupported()) {
      return getAnalytics(app);
    }
    return null;
  } catch (error) {
    console.warn("Analytics not supported:", error);
    return null;
  }
};

export default app;
