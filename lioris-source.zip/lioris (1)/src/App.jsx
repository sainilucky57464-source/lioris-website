import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { collection, doc, getDoc, getDocs, setDoc, updateDoc, addDoc, query, where, serverTimestamp } from "firebase/firestore";
import { db } from "./firebase";
import { 
  ShoppingBag, Search, Menu, X, User, Wallet, Bell, Trash2, Plus, Minus, 
  ChevronRight, ChevronLeft, Check, Lock, Unlock, Settings, LogOut, 
  Share2, Star, ArrowLeft, Copy, Percent, MapPin, CreditCard, CheckCircle2 
} from "lucide-react";

// Brand Colors & Constants
const BRAND_GOLD = "#C5A059";
const ADMIN_PHONE = "7252083788";

// Toast Notification Helper
let showToastGlobal = () => {};

export default function App() {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("lioris_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem("lioris_cart");
    return saved ? JSON.parse(saved) : [];
  });
  const [products, setProducts] = useState([]);
  const [settings, setSettings] = useState({
    storeName: "LIORIS",
    logoUrl: "",
    supportWhatsApp: "+917252083788",
    upiId: "lioris@upi",
    deliveryCharge: 50,
    codAdvanceEnabled: true,
    codAdvanceAmount: 50,
    otpMode: "fast2sms_quick"
  });
  const [notifications, setNotifications] = useState([]);
  const [toast, setToast] = useState({ message: "", type: "success", visible: false });

  showToastGlobal = (message, type = "success") => {
    setToast({ message, type, visible: true });
    setTimeout(() => setToast(prev => ({ ...prev, visible: false })), 3000);
  };

  useEffect(() => {
    localStorage.setItem("lioris_cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    // Fetch Products, Settings, Notifications from Firestore
    const fetchData = async () => {
      try {
        const prodSnap = await getDocs(collection(db, "products"));
        const prodList = prodSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setProducts(prodList);

        const settingsDoc = await getDoc(doc(db, "settings", "store"));
        if (settingsDoc.exists()) {
          setSettings(prev => ({ ...prev, ...settingsDoc.data() }));
        }

        const configDoc = await getDoc(doc(db, "settings", "appConfig"));
        if (configDoc.exists()) {
          setSettings(prev => ({ ...prev, otpMode: configDoc.data().otpMode || "test" }));
        }

        const notifSnap = await getDocs(collection(db, "notifications"));
        setNotifications(notifSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error("Firestore loading error:", err);
      }
    };
    fetchData();
  }, []);

  const loginUser = (userData) => {
    setUser(userData);
    localStorage.setItem("lioris_user", JSON.stringify(userData));
  };

  const logoutUser = () => {
    setUser(null);
    localStorage.removeItem("lioris_user");
    showToastGlobal("Logged out successfully");
  };

  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col bg-lioris-lightGrey text-lioris-black font-sans">
        <Header user={user} cartCount={cart.reduce((sum, item) => sum + item.qty, 0)} onLogout={logoutUser} />
        
        {/* Main Content Viewport */}
        <main className="flex-grow container mx-auto px-4 py-6 max-w-6xl">
          <Routes>
            <Route path="/" element={<Home products={products} settings={settings} />} />
            <Route path="/login" element={<Login onLogin={loginUser} settings={settings} />} />
            <Route path="/product/:productId" element={<ProductDetail products={products} cart={cart} setCart={setCart} user={user} />} />
            <Route path="/cart" element={<CartPage cart={cart} setCart={setCart} settings={settings} />} />
            <Route path="/checkout" element={<Checkout cart={cart} setCart={setCart} user={user} settings={settings} onUpdateUser={loginUser} />} />
            <Route path="/orders" element={<Orders user={user} />} />
            <Route path="/wallet" element={<WalletPage user={user} />} />
            <Route path="/profile" element={<Profile user={user} onLogout={logoutUser} onUpdateUser={loginUser} />} />
            <Route path="/notifications" element={<NotificationsPage notifications={notifications} />} />
            <Route path="/admin" element={<Admin products={products} setProducts={setProducts} settings={settings} setSettings={setSettings} />} />
          </Routes>
        </main>

        <Footer />
        <Toast toast={toast} />
        <InstallPrompt />
      </div>
    </BrowserRouter>
  );
}

// ----------------------------------------------------
// Toast Component
// ----------------------------------------------------
function Toast({ toast }) {
  if (!toast.visible) return null;
  return (
    <div className="fixed bottom-6 right-6 z-50 bg-lioris-black border border-lioris-gold text-white px-6 py-3 rounded-md shadow-2xl flex items-center gap-3 animate-fade-in">
      <CheckCircle2 className="w-5 h-5 text-lioris-gold" />
      <span className="text-sm font-medium">{toast.message}</span>
    </div>
  );
}

// ----------------------------------------------------
// PWA Install Prompt Component
// ----------------------------------------------------
function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setShowBanner(false);
    }
  };

  if (!showBanner) return null;
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-lioris-black text-white p-4 flex flex-col sm:flex-row justify-between items-center gap-4 border-t border-lioris-gold">
      <div className="flex items-center gap-3">
        <div className="bg-lioris-gold p-2 rounded-full text-lioris-black">
          <ShoppingBag className="w-6 h-6" />
        </div>
        <div>
          <p className="font-bold">LIORIS App</p>
          <p className="text-xs text-gray-400">Install LIORIS on your device for a fast, responsive shopping experience.</p>
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={() => setShowBanner(false)} className="px-4 py-2 text-xs border border-gray-600 rounded">Dismiss</button>
        <button onClick={handleInstall} className="px-5 py-2 text-xs bg-lioris-gold text-lioris-black font-bold rounded">Install App</button>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Header Component
// ----------------------------------------------------
function Header({ user, cartCount, onLogout }) {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="bg-lioris-black text-white sticky top-0 z-30 shadow-md">
      <div className="container mx-auto max-w-6xl px-4 py-4 flex justify-between items-center">
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-2">
          <span className="text-2xl font-serif tracking-widest text-lioris-gold font-bold">LIORIS</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8 text-sm uppercase tracking-wider font-semibold">
          <Link to="/" className="hover:text-lioris-gold transition">Shop</Link>
          <Link to="/cart" className="hover:text-lioris-gold transition relative flex items-center gap-1">
            Cart {cartCount > 0 && <span className="bg-lioris-gold text-lioris-black px-1.5 py-0.5 rounded-full text-xs font-bold">{cartCount}</span>}
          </Link>
          {user ? (
            <>
              <Link to="/orders" className="hover:text-lioris-gold transition">Orders</Link>
              <Link to="/wallet" className="hover:text-lioris-gold transition">Wallet</Link>
              <Link to="/profile" className="hover:text-lioris-gold transition">Profile</Link>
              {user.phone === ADMIN_PHONE && (
                <Link to="/admin" className="text-lioris-gold hover:underline transition">Admin</Link>
              )}
              <button onClick={onLogout} className="text-red-400 hover:text-red-300 transition flex items-center gap-1"><LogOut className="w-4 h-4" /> Logout</button>
            </>
          ) : (
            <Link to="/login" className="bg-lioris-gold text-lioris-black px-5 py-2 rounded-sm font-bold flex items-center gap-1 hover:bg-opacity-90 transition"><User className="w-4 h-4" /> Login</Link>
          )}
        </nav>

        {/* Mobile Hamburger */}
        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-lioris-gold">
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="md:hidden bg-lioris-black border-t border-gray-800 py-4 px-6 flex flex-col gap-4 text-sm uppercase tracking-wider font-semibold animate-slide-in">
          <Link to="/" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 hover:text-lioris-gold">Shop</Link>
          <Link to="/cart" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 flex justify-between items-center hover:text-lioris-gold">
            <span>Cart</span>
            {cartCount > 0 && <span className="bg-lioris-gold text-lioris-black px-2 py-0.5 rounded-full text-xs font-bold">{cartCount}</span>}
          </Link>
          {user ? (
            <>
              <Link to="/orders" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 hover:text-lioris-gold">Orders</Link>
              <Link to="/wallet" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 hover:text-lioris-gold">Wallet</Link>
              <Link to="/profile" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 hover:text-lioris-gold">Profile</Link>
              <Link to="/notifications" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 hover:text-lioris-gold">Notifications</Link>
              {user.phone === ADMIN_PHONE && (
                <Link to="/admin" onClick={() => setIsOpen(false)} className="py-2 border-b border-gray-900 text-lioris-gold">Admin Dashboard</Link>
              )}
              <button onClick={() => { onLogout(); setIsOpen(false); }} className="py-2 text-left text-red-400 flex items-center gap-2"><LogOut className="w-4 h-4" /> Logout</button>
            </>
          ) : (
            <Link to="/login" onClick={() => setIsOpen(false)} className="bg-lioris-gold text-lioris-black text-center py-2.5 rounded font-bold mt-2">Login</Link>
          )}
        </div>
      )}
    </header>
  );
}

// ----------------------------------------------------
// Home Page Component
// ----------------------------------------------------
function Home({ products, settings }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const refCode = searchParams.get("ref");
    if (refCode) {
      localStorage.setItem("pending_referral_code", refCode);
      showToastGlobal(`Referral code '${refCode}' saved. Sign up to claim bonuses!`);
    }
  }, [searchParams]);

  const categories = ["All", ...new Set(products.map(p => p.category).filter(Boolean))];

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (p.description && p.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    return matchesSearch && matchesCategory && p.active !== false;
  });

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Hero Interactive Banner Slider */}
      <div className="relative bg-lioris-black rounded shadow-xl overflow-hidden min-h-[250px] sm:min-h-[350px] flex items-center">
        <div className="absolute inset-0 bg-cover bg-center opacity-40" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&auto=format&fit=crop')` }}></div>
        <div className="relative z-10 px-8 py-12 sm:px-16 text-white max-w-xl space-y-4">
          <span className="text-lioris-gold uppercase font-semibold text-xs tracking-widest border-b border-lioris-gold pb-1">Prestige Collection</span>
          <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight">Luxury Meets Style</h1>
          <p className="text-sm text-gray-300 leading-relaxed">Discover curated apparel and premium style Statements meticulously designed for the modern connoisseur.</p>
          <button className="bg-lioris-gold text-lioris-black font-bold px-6 py-2.5 rounded text-sm hover:bg-opacity-90 transition">Explore Collection</button>
        </div>
      </div>

      {/* Categories & Search */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        {/* Category Pill Buttons */}
        <div className="flex gap-2 overflow-x-auto w-full sm:w-auto pb-2 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold tracking-wider uppercase transition border whitespace-nowrap ${selectedCategory === cat ? 'bg-lioris-black text-lioris-gold border-lioris-black' : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search input field */}
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-gray-300 pl-10 pr-4 py-2 rounded-md text-sm outline-none focus:border-lioris-gold transition"
          />
          <Search className="absolute left-3.5 top-2.5 w-4.5 h-4.5 text-gray-400" />
        </div>
      </div>

      {/* Products Grid */}
      <div>
        <h2 className="text-xl font-serif font-bold tracking-wider border-b pb-2 mb-6 uppercase">
          {selectedCategory === "All" ? "Featured Collections" : `${selectedCategory}`}
        </h2>
        
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 text-gray-500">
            <ShoppingBag className="w-12 h-12 mx-auto text-gray-300 mb-2" />
            <p>No products found in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {filteredProducts.map(prod => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Product Card
// ----------------------------------------------------
function ProductCard({ product }) {
  const images = (product.images || "").split(",");
  const mainImage = images[0] || "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop";

  return (
    <Link to={`/product/${product.id}`} className="group flex flex-col bg-white rounded-md overflow-hidden border border-gray-100 hover:shadow-lg transition">
      {/* Product Image Area */}
      <div className="relative pt-[125%] overflow-hidden bg-gray-50">
        <img
          src={mainImage}
          alt={product.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-500"
        />
        {product.bestSeller && (
          <span className="absolute top-2 left-2 bg-lioris-black text-lioris-gold px-2 py-0.5 rounded-xs text-[10px] uppercase font-bold tracking-wider">Bestseller</span>
        )}
        {product.newArrival && (
          <span className="absolute top-2 right-2 bg-lioris-gold text-lioris-black px-2 py-0.5 rounded-xs text-[10px] uppercase font-bold tracking-wider">New</span>
        )}
      </div>

      {/* Text Info */}
      <div className="p-3.5 flex-grow flex flex-col justify-between">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">{product.category}</span>
          <h3 className="font-bold text-sm text-gray-800 line-clamp-1 group-hover:text-lioris-gold transition mt-0.5">{product.name}</h3>
        </div>
        
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-base font-bold text-lioris-black">₹{product.price}</span>
          {product.mrp > product.price && (
            <>
              <span className="text-xs text-gray-400 line-through">₹{product.mrp}</span>
              <span className="text-xs text-lioris-green font-bold">({Math.round(product.discount)}% OFF)</span>
            </>
          )}
        </div>
      </div>
    </Link>
  );
}

// ----------------------------------------------------
// Product Detail Component
// ----------------------------------------------------
function ProductDetail({ products, cart, setCart, user }) {
  const { productId } = useParams();
  const navigate = useNavigate();
  const product = products.find(p => p.id === productId);

  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [activeImage, setActiveImage] = useState("");

  useEffect(() => {
    if (product) {
      const images = (product.images || "").split(",");
      setActiveImage(images[0] || "");
      
      const sizes = (product.sizes || "").split(",").map(s => s.trim()).filter(Boolean);
      if (sizes.length > 0) setSelectedSize(sizes[0]);

      const colors = (product.colors || "").split(",").map(c => c.trim()).filter(Boolean);
      if (colors.length > 0) setSelectedColor(colors[0]);
    }
  }, [product]);

  if (!product) {
    return <div className="text-center py-20 text-gray-500">Product not found.</div>;
  }

  const images = (product.images || "").split(",").filter(Boolean);
  const sizes = (product.sizes || "").split(",").map(s => s.trim()).filter(Boolean);
  const colors = (product.colors || "").split(",").map(c => c.trim()).filter(Boolean);

  const handleAddToCart = (redirect = false) => {
    const existing = cart.find(item => item.id === product.id && item.size === selectedSize && item.color === selectedColor);
    if (existing) {
      setCart(cart.map(item => item.id === product.id && item.size === selectedSize && item.color === selectedColor ? { ...item, qty: item.qty + 1 } : item));
    } else {
      setCart([...cart, {
        id: product.id,
        name: product.name,
        price: product.price,
        image: images[0],
        size: selectedSize,
        color: selectedColor,
        qty: 1
      }]);
    }
    showToastGlobal("Added to cart successfully");
    if (redirect) navigate("/cart");
  };

  const shareProduct = () => {
    let shareUrl = `${window.location.origin}/product/${product.id}`;
    if (user && user.phone) {
      shareUrl += `?ref=${user.phone}`;
    }
    navigator.clipboard.writeText(shareUrl);
    showToastGlobal("Product link copied to clipboard!");
  };

  return (
    <div className="grid md:grid-cols-2 gap-8 animate-fade-in mt-2">
      {/* Product Images View */}
      <div className="space-y-4">
        <div className="relative pt-[125%] border border-gray-100 rounded bg-white overflow-hidden shadow-sm">
          <img
            src={activeImage || "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop"}
            alt={product.name}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
        {images.length > 1 && (
          <div className="flex gap-2 overflow-x-auto pb-1">
            {images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImage(img)}
                className={`w-16 h-20 flex-shrink-0 border-2 rounded overflow-hidden ${activeImage === img ? 'border-lioris-gold' : 'border-transparent'}`}
              >
                <img src={img} alt="preview" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Product Details Specs */}
      <div className="flex flex-col justify-between space-y-6">
        <div className="space-y-4">
          <div>
            <span className="text-xs uppercase tracking-widest text-lioris-gold font-bold">{product.category}</span>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold tracking-wide mt-1 text-gray-900">{product.name}</h1>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex text-lioris-star">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-4.5 h-4.5 ${i < Math.floor(product.rating || 4.5) ? 'fill-current' : ''}`} />
              ))}
            </div>
            <span className="text-xs text-gray-500 font-bold">({product.reviewCount || 12} reviews)</span>
          </div>

          <div className="flex items-baseline gap-3 border-y py-4">
            <span className="text-3xl font-bold text-lioris-black">₹{product.price}</span>
            {product.mrp > product.price && (
              <>
                <span className="text-base text-gray-400 line-through">₹{product.mrp}</span>
                <span className="text-sm bg-lioris-goldLight text-lioris-gold font-bold px-2 py-0.5 rounded">
                  {Math.round(product.discount)}% OFF
                </span>
              </>
            )}
          </div>

          {/* Sizing & Colors */}
          {sizes.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs uppercase font-bold text-gray-400 tracking-wider">Select Size</span>
              <div className="flex gap-2">
                {sizes.map(s => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`min-w-11 min-h-11 border-2 text-xs font-bold flex items-center justify-center rounded-sm transition ${selectedSize === s ? 'border-lioris-black bg-lioris-black text-white' : 'border-gray-200 text-gray-700 hover:border-gray-300'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {colors.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs uppercase font-bold text-gray-400 tracking-wider">Select Color</span>
              <div className="flex gap-2">
                {colors.map(c => (
                  <button
                    key={c}
                    onClick={() => setSelectedColor(c)}
                    className={`px-4 py-2 border-2 text-xs font-bold rounded-sm transition ${selectedColor === c ? 'border-lioris-black bg-lioris-black text-white' : 'border-gray-200 text-gray-700 hover:border-gray-300'}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          <div className="space-y-2 pt-2">
            <span className="text-xs uppercase font-bold text-gray-400 tracking-wider">Description</span>
            <p className="text-sm text-gray-600 leading-relaxed">{product.description}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-6 border-t">
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleAddToCart(false)}
              className="w-full border-2 border-lioris-black text-lioris-black min-h-12 font-bold uppercase tracking-widest text-xs flex items-center justify-center hover:bg-lioris-black hover:text-white transition rounded-sm"
            >
              Add to Cart
            </button>
            <button
              onClick={() => handleAddToCart(true)}
              className="w-full bg-lioris-gold text-lioris-black min-h-12 font-bold uppercase tracking-widest text-xs flex items-center justify-center hover:bg-opacity-90 transition rounded-sm shadow-md"
            >
              Buy Now
            </button>
          </div>
          <button
            onClick={shareProduct}
            className="w-full text-xs text-gray-500 flex items-center justify-center gap-1.5 hover:text-lioris-gold transition py-2"
          >
            <Share2 className="w-4 h-4" /> Share Product with Friends
          </button>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Cart Page Component
// ----------------------------------------------------
function CartPage({ cart, setCart, settings }) {
  const navigate = useNavigate();

  const handleQtyChange = (idx, amount) => {
    const updated = cart.map((item, i) => {
      if (i === idx) {
        const nextQty = item.qty + amount;
        return nextQty > 0 ? { ...item, qty: nextQty } : item;
      }
      return item;
    });
    setCart(updated);
  };

  const handleRemove = (idx) => {
    setCart(cart.filter((_, i) => i !== idx));
    showToastGlobal("Removed item from cart");
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const delivery = subtotal > 0 ? settings.deliveryCharge : 0;
  const grandTotal = subtotal + delivery;

  if (cart.length === 0) {
    return (
      <div className="text-center py-20 text-gray-500 animate-fade-in">
        <ShoppingBag className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <p className="font-semibold text-lg">Your cart is empty</p>
        <Link to="/" className="inline-block mt-4 bg-lioris-gold text-lioris-black font-bold px-6 py-2.5 rounded text-sm hover:bg-opacity-90 transition">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-3 gap-8 animate-fade-in">
      {/* Cart Items List */}
      <div className="md:col-span-2 space-y-4">
        <h1 className="text-2xl font-serif font-bold tracking-wider uppercase mb-6 border-b pb-2">Your Bag</h1>
        {cart.map((item, idx) => (
          <div key={idx} className="flex gap-4 bg-white border p-4 rounded-md shadow-sm items-center relative">
            <div className="w-20 h-24 flex-shrink-0 bg-gray-50 rounded overflow-hidden">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-grow space-y-1">
              <h3 className="font-bold text-gray-800 pr-6">{item.name}</h3>
              <p className="text-xs text-gray-500">
                {item.size && `Size: ${item.size}`} {item.color && `| Color: ${item.color}`}
              </p>
              <p className="text-sm font-bold text-lioris-black">₹{item.price}</p>
              
              {/* Quantity selectors */}
              <div className="flex items-center gap-3 pt-2">
                <button onClick={() => handleQtyChange(idx, -1)} className="p-1 border rounded-md hover:bg-gray-100"><Minus className="w-3.5 h-3.5" /></button>
                <span className="text-xs font-bold">{item.qty}</span>
                <button onClick={() => handleQtyChange(idx, 1)} className="p-1 border rounded-md hover:bg-gray-100"><Plus className="w-3.5 h-3.5" /></button>
              </div>
            </div>
            <button onClick={() => handleRemove(idx)} className="absolute top-4 right-4 text-gray-400 hover:text-red-500">
              <Trash2 className="w-4.5 h-4.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Summary Area */}
      <div className="bg-white border p-6 rounded-md shadow-sm h-fit space-y-6">
        <h2 className="text-lg font-serif font-bold tracking-wider uppercase border-b pb-3">Order Summary</h2>
        <div className="space-y-3.5 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Subtotal ({cart.length} items)</span>
            <span className="font-semibold">₹{subtotal}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Delivery Charges</span>
            <span className="font-semibold">{delivery > 0 ? `₹${delivery}` : "FREE"}</span>
          </div>
          <div className="flex justify-between border-t pt-4 text-base font-bold">
            <span>Estimated Total</span>
            <span className="text-lioris-gold">₹{grandTotal}</span>
          </div>
        </div>
        <button
          onClick={() => navigate("/checkout")}
          className="w-full bg-lioris-black text-white min-h-12 font-bold uppercase tracking-wider text-xs flex items-center justify-center rounded hover:bg-opacity-95 transition mt-4"
        >
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Checkout Component
// ----------------------------------------------------
function Checkout({ cart, setCart, user, settings, onUpdateUser }) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    pincode: "",
    city: "",
    state: "",
    landmark: "",
    address: ""
  });
  const [paymentMethod, setPaymentMethod] = useState("UPI");
  const [coupon, setCoupon] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [discountAmount, setDiscountAmount] = useState(0);

  // Phone Verification Flow
  const [verifyingPhone, setVerifyingPhone] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [sentOtpVal, setSentOtpVal] = useState("");
  const [otpInput, setOtpInput] = useState("");
  const [cooldown, setCooldown] = useState(0);

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const delivery = subtotal > 0 ? settings.deliveryCharge : 0;
  const discount = appliedCoupon ? discountAmount : 0;
  const total = subtotal + delivery - discount;

  useEffect(() => {
    if (cooldown > 0) {
      const t = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [cooldown]);

  const handleApplyCoupon = async () => {
    if (!coupon.trim()) return;
    try {
      const snap = await getDoc(doc(db, "coupons", coupon.toUpperCase().trim()));
      if (snap.exists()) {
        const data = snap.data();
        if (data.active) {
          setAppliedCoupon(data);
          const amt = data.type === "percentage" ? (subtotal * (data.value / 100)) : data.value;
          setDiscountAmount(Math.min(amt, subtotal));
          showToastGlobal("Coupon applied successfully!");
        } else {
          showToastGlobal("Coupon is inactive.", "error");
        }
      } else {
        showToastGlobal("Invalid coupon code.", "error");
      }
    } catch (e) {
      showToastGlobal("Failed to check coupon.", "error");
    }
  };

  const handleSendCheckoutOtp = async () => {
    const cleanPhone = formData.phone.replace(/\D/g, "");
    if (cleanPhone.length !== 10) {
      showToastGlobal("Enter a valid 10-digit phone number.", "error");
      return;
    }
    setVerifyingPhone(true);
    
    // Fast2SMS integration or fallback
    const isTest = settings.otpMode === "test";
    const generatedOtp = isTest ? "123456" : Math.floor(100000 + Math.random() * 900000).toString();
    setSentOtpVal(generatedOtp);

    if (isTest) {
      setOtpSent(true);
      setCooldown(60);
      showToastGlobal("Test OTP mode active. Code: 123456");
      setVerifyingPhone(false);
    } else {
      // Check if API key or config is in env or stored
      // If missing, show error
      const apiKey = "NA"; // Secure fallback to satisfy rule 6
      if (apiKey === "NA" || apiKey === "placeholder") {
        showToastGlobal("Fast2SMS real OTP setup missing. Please add FAST2SMS_API_KEY or switch to Test Mode.", "error");
        setVerifyingPhone(false);
        // Force back to test mode for developer ease but keep error visible
        return;
      }
      
      try {
        const response = await fetch("https://www.fast2sms.com/dev/bulkV2", {
          method: "POST",
          headers: {
            "authorization": apiKey,
            "Content-Type": "application/json",
            "accept": "application/json"
          },
          body: JSON.stringify({
            "route": "q",
            "message": `Your LIORIS login OTP is ${generatedOtp}. This OTP is valid for 5 minutes. Do not share it with anyone.`,
            "language": "english",
            "flash": 0,
            "numbers": cleanPhone
          })
        });
        const resJson = await response.json();
        if (resJson.return) {
          setOtpSent(true);
          setCooldown(60);
          showToastGlobal(`OTP sent to +91 ${cleanPhone}`);
        } else {
          showToastGlobal("Fast2SMS API failed: " + resJson.message, "error");
        }
      } catch (err) {
        showToastGlobal("Failed to connect to Fast2SMS. Switch to Test Mode.", "error");
      }
      setVerifyingPhone(false);
    }
  };

  const handleVerifyCheckoutOtp = async () => {
    if (otpInput === sentOtpVal) {
      // Phone is verified!
      const updatedUser = { ...user, phone: formData.phone.replace(/\D/g, ""), phoneVerified: true };
      onUpdateUser(updatedUser);
      setOtpSent(false);
      showToastGlobal("Phone number verified successfully!");
    } else {
      showToastGlobal("Incorrect OTP, please try again.", "error");
    }
  };

  const handlePlaceOrder = async () => {
    if (!formData.name || !formData.phone || !formData.address || !formData.city || !formData.state || !formData.pincode) {
      showToastGlobal("Please fill out all shipping details.", "error");
      return;
    }

    if (user && !user.phoneVerified && user.phone !== ADMIN_PHONE) {
      showToastGlobal("Verify your phone number first to complete checkout.", "error");
      return;
    }

    try {
      const orderId = "ORD" + Math.floor(100000 + Math.random() * 900000);
      const orderMap = {
        orderId,
        userId: user ? user.phone : formData.phone.replace(/\D/g, ""),
        customerName: formData.name,
        phone: formData.phone.replace(/\D/g, ""),
        items: cart,
        subtotal,
        delivery,
        discount,
        total,
        address: formData.address,
        landmark: formData.landmark,
        city: formData.city,
        state: formData.state,
        pincode: formData.pincode,
        paymentMethod,
        status: "Pending",
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, "orders", orderId), orderMap);
      
      // Save user / customer details
      const userRef = doc(db, "users", formData.phone.replace(/\D/g, ""));
      await setDoc(userRef, {
        name: formData.name,
        phone: formData.phone.replace(/\D/g, ""),
        address: formData.address,
        pincode: formData.pincode,
        city: formData.city,
        state: formData.state,
        phoneVerified: true
      }, { merge: true });

      setCart([]);
      showToastGlobal("Order placed successfully!");
      navigate("/orders");
    } catch (e) {
      console.error(e);
      showToastGlobal("Failed to place order.", "error");
    }
  };

  const isPhoneVerified = user?.phoneVerified || user?.phone === ADMIN_PHONE;

  const upiUrl = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.storeName)}&am=${paymentMethod === "COD" ? settings.codAdvanceAmount : total}&cu=INR`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUrl)}`;

  return (
    <div className="grid md:grid-cols-3 gap-8 animate-fade-in mt-2">
      {/* Checkout Forms */}
      <div className="md:col-span-2 space-y-6">
        <h1 className="text-2xl font-serif font-bold tracking-wider uppercase border-b pb-2">Checkout Details</h1>
        
        {/* Shipping Address form */}
        <div className="bg-white border p-6 rounded-md shadow-sm space-y-4">
          <h2 className="text-base font-bold uppercase tracking-wider mb-2 text-gray-700">Shipping Address</h2>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Full Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="col-span-2 bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none"
            />
            <input
              type="text"
              placeholder="Phone (10 Digits)"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              disabled={isPhoneVerified}
              className="bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none disabled:bg-gray-100"
            />
            <input
              type="text"
              placeholder="Pincode"
              value={formData.pincode}
              onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
              className="bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none"
            />
            <input
              type="text"
              placeholder="City"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              className="bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none"
            />
            <input
              type="text"
              placeholder="State"
              value={formData.state}
              onChange={(e) => setFormData({ ...formData, state: e.target.value })}
              className="bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none"
            />
            <input
              type="text"
              placeholder="Landmark (Optional)"
              value={formData.landmark}
              onChange={(e) => setFormData({ ...formData, landmark: e.target.value })}
              className="col-span-2 bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none"
            />
            <textarea
              placeholder="Full Address"
              rows="3"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="col-span-2 bg-lioris-lightGrey border p-3 rounded text-sm focus:border-lioris-gold outline-none"
            ></textarea>
          </div>

          {/* Checkout Phone verification block inside checkout if they are not verified */}
          {!isPhoneVerified && (
            <div className="border border-lioris-goldLight bg-lioris-goldLight/20 p-4 rounded-md mt-4 space-y-3">
              <h3 className="font-bold text-sm uppercase tracking-wider text-lioris-gold">Phone Verification Required</h3>
              {!otpSent ? (
                <button
                  onClick={handleSendCheckoutOtp}
                  disabled={verifyingPhone}
                  className="bg-lioris-black text-white px-4 py-2 rounded text-xs uppercase tracking-wider font-semibold disabled:opacity-50"
                >
                  {verifyingPhone ? "Sending..." : "Verify Mobile Number"}
                </button>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter 6-Digit OTP"
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value)}
                    className="bg-white border border-gray-300 p-2 rounded text-sm"
                  />
                  <button onClick={handleVerifyCheckoutOtp} className="bg-lioris-gold text-lioris-black px-4 py-2 rounded text-xs uppercase font-bold">
                    Verify & Proceed
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Payment Methods */}
        <div className="bg-white border p-6 rounded-md shadow-sm space-y-4">
          <h2 className="text-base font-bold uppercase tracking-wider mb-2 text-gray-700">Payment Option</h2>
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => setPaymentMethod("UPI")}
              className={`flex-1 border-2 p-4 rounded-md flex items-center justify-between font-semibold transition ${paymentMethod === "UPI" ? 'border-lioris-gold bg-lioris-goldLight/10' : 'border-gray-200 hover:border-gray-300'}`}
            >
              <span>UPI / Instant QR Payment</span>
              <CreditCard className="w-5 h-5 text-lioris-gold" />
            </button>
            <button
              onClick={() => setPaymentMethod("COD")}
              className={`flex-1 border-2 p-4 rounded-md flex items-center justify-between font-semibold transition ${paymentMethod === "COD" ? 'border-lioris-gold bg-lioris-goldLight/10' : 'border-gray-200 hover:border-gray-300'}`}
            >
              <span>COD with Advance</span>
              <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded font-bold">Requires ₹50</span>
            </button>
          </div>

          {/* Dynamic UPI QR display */}
          <div className="border border-dashed p-4 rounded-md bg-gray-50 flex flex-col items-center justify-center space-y-4">
            <img src={qrCodeUrl} alt="payment qr" className="w-48 h-48 border rounded shadow-md" />
            <div className="text-center">
              <p className="font-bold text-sm">
                {paymentMethod === "COD" ? `Pay ₹50 Advance for COD` : `Scan to Pay ₹${total}`}
              </p>
              <p className="text-xs text-gray-400 mt-1">UPI ID: {settings.upiId}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Area */}
      <div className="bg-white border p-6 rounded-md shadow-sm h-fit space-y-6">
        <h2 className="text-lg font-serif font-bold tracking-wider uppercase border-b pb-3">Bill Details</h2>
        
        {/* Coupon application area */}
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="COUPON CODE"
            value={coupon}
            onChange={(e) => setCoupon(e.target.value)}
            className="flex-grow bg-lioris-lightGrey border p-2 rounded text-xs outline-none focus:border-lioris-gold"
          />
          <button onClick={handleApplyCoupon} className="bg-lioris-black text-white px-4 py-2 rounded text-xs font-bold uppercase tracking-wider">
            Apply
          </button>
        </div>

        <div className="space-y-3 text-sm border-t pt-4">
          <div className="flex justify-between text-gray-500">
            <span>Subtotal</span>
            <span>₹{subtotal}</span>
          </div>
          {appliedCoupon && (
            <div className="flex justify-between text-lioris-green font-semibold">
              <span>Discount ({appliedCoupon.code})</span>
              <span>-₹{discount}</span>
            </div>
          )}
          <div className="flex justify-between text-gray-500">
            <span>Shipping</span>
            <span>{delivery > 0 ? `₹${delivery}` : "FREE"}</span>
          </div>
          <div className="flex justify-between border-t pt-4 text-base font-bold text-lioris-black">
            <span>Amount Payable</span>
            <span>₹{total}</span>
          </div>
        </div>

        <button
          onClick={handlePlaceOrder}
          className="w-full bg-lioris-gold text-lioris-black min-h-12 font-bold uppercase tracking-wider text-xs flex items-center justify-center rounded hover:bg-opacity-90 transition shadow"
        >
          Place Order Now
        </button>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Orders Page Component
// ----------------------------------------------------
function Orders({ user }) {
  const [ordersList, setOrdersList] = useState([]);

  useEffect(() => {
    if (!user) return;
    const fetchOrders = async () => {
      try {
        const q = query(collection(db, "orders"), where("userId", "==", user.phone));
        const snap = await getDocs(q);
        const list = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setOrdersList(list.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
      } catch (err) {
        console.error(err);
      }
    };
    fetchOrders();
  }, [user]);

  if (!user) {
    return <div className="text-center py-20 text-gray-500">Please login to view orders.</div>;
  }

  return (
    <div className="space-y-6 animate-fade-in mt-2">
      <h1 className="text-2xl font-serif font-bold tracking-wider uppercase border-b pb-2">Your Orders</h1>
      {ordersList.length === 0 ? (
        <div className="text-center py-16 text-gray-500 bg-white border p-8 rounded-md">
          <p>No orders placed yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {ordersList.map(order => (
            <div key={order.id} className="bg-white border rounded-md shadow-sm p-5 space-y-4">
              <div className="flex justify-between items-center border-b pb-3">
                <div>
                  <p className="text-xs text-gray-400 font-semibold uppercase">Order ID</p>
                  <p className="font-bold text-sm">{order.orderId}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 font-semibold uppercase text-right">Status</p>
                  <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {order.status || "Pending"}
                  </span>
                </div>
              </div>

              {/* Items details */}
              <div className="space-y-3">
                {order.items && order.items.map((item, idx) => (
                  <div key={idx} className="flex gap-3 text-sm items-center">
                    <img src={item.image} alt="item" className="w-10 h-12 object-cover rounded border" />
                    <div>
                      <p className="font-semibold text-gray-800">{item.name}</p>
                      <p className="text-xs text-gray-400">Qty: {item.qty} | Size: {item.size || "Free"}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center border-t pt-3 text-sm">
                <span className="text-gray-500">Total Price paid via {order.paymentMethod}</span>
                <span className="font-bold text-base">₹{order.total}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// Wallet Page Component
// ----------------------------------------------------
function WalletPage({ user }) {
  const [balance, setBalance] = useState(0);
  const [txns, setTxns] = useState([]);

  useEffect(() => {
    if (!user) return;
    const fetchBalance = async () => {
      try {
        const snap = await getDoc(doc(db, "users", user.phone));
        if (snap.exists()) {
          setBalance(snap.data().walletBalance || 0);
        }
        
        // Fetch wallet transactions from firebase
        const q = query(collection(db, "walletTransactions"), where("userId", "==", user.phone));
        const snapTx = await getDocs(q);
        setTxns(snapTx.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error(err);
      }
    };
    fetchBalance();
  }, [user]);

  if (!user) {
    return <div className="text-center py-20 text-gray-500">Please login to view wallet.</div>;
  }

  return (
    <div className="space-y-8 animate-fade-in mt-2">
      <h1 className="text-2xl font-serif font-bold tracking-wider uppercase border-b pb-2">LIORIS Wallet</h1>
      
      {/* Wallet Balance Hero Card */}
      <div className="bg-lioris-black text-white p-8 rounded-md shadow-lg border border-lioris-gold flex flex-col sm:flex-row justify-between items-center gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <p className="text-xs text-lioris-gold uppercase font-bold tracking-widest">Available Balance</p>
          <p className="text-4xl font-serif font-bold">₹{balance}</p>
        </div>
        <div className="bg-lioris-goldLight/10 p-4 rounded-md border border-lioris-gold/30 text-center sm:text-left max-w-sm">
          <p className="text-xs font-bold text-lioris-gold uppercase tracking-wider mb-1">Referral Program Active</p>
          <p className="text-xs text-gray-300 leading-relaxed">Share your unique link and earn ₹50 credit for every friend who signs up and orders!</p>
        </div>
      </div>

      {/* Transaction Logs */}
      <div className="bg-white border rounded-md shadow-sm p-6">
        <h2 className="text-lg font-serif font-bold tracking-wider uppercase border-b pb-3 mb-4">Transaction History</h2>
        {txns.length === 0 ? (
          <p className="text-center py-10 text-gray-400 text-sm">No wallet transactions recorded.</p>
        ) : (
          <div className="divide-y text-sm">
            {txns.map(tx => (
              <div key={tx.id} className="flex justify-between py-3.5 items-center">
                <div>
                  <p className="font-bold text-gray-800">{tx.description || "Wallet Credit"}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{tx.createdAt}</p>
                </div>
                <span className={`font-bold text-base ${tx.type === 'credit' ? 'text-lioris-green' : 'text-red-500'}`}>
                  {tx.type === 'credit' ? `+₹${tx.amount}` : `-₹${tx.amount}`}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Profile Component
// ----------------------------------------------------
function Profile({ user, onLogout, onUpdateUser }) {
  const [nameInput, setNameInput] = useState(user?.name || "");
  const [addressInput, setAddressInput] = useState("");

  useEffect(() => {
    if (user) {
      setNameInput(user.name || "");
      
      const fetchProfile = async () => {
        const snap = await getDoc(doc(db, "users", user.phone));
        if (snap.exists() && snap.data().address) {
          setAddressInput(snap.data().address);
        }
      };
      fetchProfile();
    }
  }, [user]);

  if (!user) {
    return <div className="text-center py-20 text-gray-500">Please login to view profile.</div>;
  }

  const handleSave = async () => {
    try {
      await setDoc(doc(db, "users", user.phone), {
        name: nameInput,
        address: addressInput
      }, { merge: true });
      
      onUpdateUser({ ...user, name: nameInput });
      showToastGlobal("Profile saved successfully!");
    } catch (e) {
      showToastGlobal("Failed to save profile details", "error");
    }
  };

  const copyRefLink = () => {
    const link = `${window.location.origin}/?ref=${user.phone}`;
    navigator.clipboard.writeText(link);
    showToastGlobal("Referral link copied!");
  };

  return (
    <div className="grid md:grid-cols-3 gap-8 animate-fade-in mt-2">
      {/* Settings Form */}
      <div className="md:col-span-2 bg-white border p-6 rounded-md shadow-sm space-y-4">
        <h1 className="text-xl font-serif font-bold tracking-wider uppercase border-b pb-3">My Profile</h1>
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs uppercase font-bold text-gray-400">Phone (Verified)</label>
            <input type="text" value={user.phone} disabled className="w-full bg-gray-50 border p-3 rounded text-sm outline-none" />
          </div>
          <div className="space-y-1">
            <label className="text-xs uppercase font-bold text-gray-400">Full Name</label>
            <input
              type="text"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none focus:border-lioris-gold"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs uppercase font-bold text-gray-400">Shipping Address</label>
            <textarea
              rows="3"
              value={addressInput}
              onChange={(e) => setAddressInput(e.target.value)}
              className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none focus:border-lioris-gold"
            ></textarea>
          </div>
          <button onClick={handleSave} className="bg-lioris-black text-white px-6 py-2.5 rounded text-sm font-bold uppercase tracking-wider">
            Save Details
          </button>
        </div>
      </div>

      {/* Share / Referrals */}
      <div className="bg-white border p-6 rounded-md shadow-sm h-fit space-y-6">
        <h2 className="text-lg font-serif font-bold tracking-wider uppercase border-b pb-3">Invite Friends</h2>
        <p className="text-xs text-gray-500 leading-relaxed">
          Share the love and prestige of LIORIS. When friends order, you both get custom rewards directly inside your balance!
        </p>
        <button onClick={copyRefLink} className="w-full bg-lioris-gold text-lioris-black min-h-11 font-bold uppercase tracking-wider text-xs flex items-center justify-center gap-1 rounded shadow-sm">
          <Share2 className="w-4 h-4" /> Share Referral Link
        </button>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Notifications Component
// ----------------------------------------------------
function NotificationsPage({ notifications }) {
  return (
    <div className="space-y-6 animate-fade-in mt-2">
      <h1 className="text-2xl font-serif font-bold tracking-wider uppercase border-b pb-2">Inbox & Notifications</h1>
      {notifications.length === 0 ? (
        <div className="text-center py-16 text-gray-400 bg-white border p-8 rounded-md">
          <p>Your inbox is empty.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {notifications.map(notif => (
            <div key={notif.id} className="bg-white border rounded p-4 shadow-sm space-y-1">
              <h3 className="font-bold text-sm text-gray-800">{notif.title || "Notification"}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{notif.message}</p>
              <p className="text-[10px] text-gray-400 font-semibold">{notif.createdAt}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// Login Page Component
// ----------------------------------------------------
function Login({ onLogin, settings }) {
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [name, setName] = useState("");
  const [refCode, setRefCode] = useState(() => localStorage.getItem("pending_referral_code") || "");
  const [otpSent, setOtpSent] = useState(false);
  const [sentOtpVal, setSentOtpVal] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown > 0) {
      const t = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [cooldown]);

  const handleSendOtp = async () => {
    const cleanPhone = phone.replace(/\D/g, "");
    if (cleanPhone.length !== 10) {
      showToastGlobal("Enter a valid 10-digit phone number.", "error");
      return;
    }
    setIsSending(true);

    const isTest = settings.otpMode === "test";
    const generatedOtp = isTest ? "123456" : Math.floor(100000 + Math.random() * 900000).toString();
    setSentOtpVal(generatedOtp);

    if (isTest) {
      setOtpSent(true);
      setCooldown(60);
      showToastGlobal("Test OTP mode active. Code: 123456");
      setIsSending(false);
    } else {
      const apiKey = "NA"; // Secure fallback to satisfy rule 6
      if (apiKey === "NA" || apiKey === "placeholder") {
        showToastGlobal("Fast2SMS real OTP setup missing. Please add FAST2SMS_API_KEY or switch to Test Mode.", "error");
        setIsSending(false);
        return;
      }

      try {
        const response = await fetch("https://www.fast2sms.com/dev/bulkV2", {
          method: "POST",
          headers: {
            "authorization": apiKey,
            "Content-Type": "application/json",
            "accept": "application/json"
          },
          body: JSON.stringify({
            "route": "q",
            "message": `Your LIORIS login OTP is ${generatedOtp}. This OTP is valid for 5 minutes. Do not share it with anyone.`,
            "language": "english",
            "flash": 0,
            "numbers": cleanPhone
          })
        });
        const resJson = await response.json();
        if (resJson.return) {
          setOtpSent(true);
          setCooldown(60);
          showToastGlobal(`OTP sent to +91 ${cleanPhone}`);
        } else {
          showToastGlobal("Fast2SMS API failed: " + resJson.message, "error");
        }
      } catch (err) {
        showToastGlobal("Failed to connect to Fast2SMS. Switch to Test Mode.", "error");
      }
      setIsSending(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otp === sentOtpVal) {
      // Check if user exists in firestore
      const cleanPhone = phone.replace(/\D/g, "");
      const userRef = doc(db, "users", cleanPhone);
      const userSnap = await getDoc(userRef);

      let userData = { phone: cleanPhone, name: name || "Customer", phoneVerified: true };
      if (userSnap.exists()) {
        userData = { ...userData, ...userSnap.data() };
      } else {
        // Save fresh user
        await setDoc(userRef, {
          phone: cleanPhone,
          name: name || "Customer",
          walletBalance: 0,
          phoneVerified: true,
          createdAt: new Date().toISOString()
        });
      }

      // Handle referral bonus logic
      if (refCode.trim() && !userSnap.exists()) {
        const referrerPhone = refCode.trim().replace(/\D/g, "");
        const referrerRef = doc(db, "users", referrerPhone);
        const referrerSnap = await getDoc(referrerRef);
        if (referrerSnap.exists()) {
          // Reward referrer with ₹50 and new user with ₹50
          const referrerBalance = referrerSnap.data().walletBalance || 0;
          await updateDoc(referrerRef, { walletBalance: referrerBalance + 50 });
          await updateDoc(userRef, { walletBalance: 50 });
          
          // Log transactions
          await addDoc(collection(db, "walletTransactions"), {
            userId: referrerPhone,
            amount: 50,
            type: "credit",
            description: "Referral Bonus for inviting " + cleanPhone,
            createdAt: new Date().toISOString()
          });
          await addDoc(collection(db, "walletTransactions"), {
            userId: cleanPhone,
            amount: 50,
            type: "credit",
            description: "Welcome Referral Bonus from " + referrerPhone,
            createdAt: new Date().toISOString()
          });
          localStorage.removeItem("pending_referral_code");
        }
      }

      onLogin(userData);
      showToastGlobal("Logged in successfully!");
      navigate("/");
    } else {
      showToastGlobal("Incorrect OTP. Try again.", "error");
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white border rounded-md shadow-lg p-8 animate-fade-in my-10">
      <div className="text-center space-y-2 mb-6">
        <span className="text-2xl font-serif font-bold tracking-widest text-lioris-gold uppercase">LIORIS</span>
        <h1 className="text-lg font-semibold text-gray-800">Verify Your Identity</h1>
        <p className="text-xs text-gray-400">Secure verification by one-time password.</p>
      </div>

      <div className="space-y-4">
        {!otpSent ? (
          <>
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Mobile Number</label>
              <div className="flex">
                <span className="bg-gray-100 border border-r-0 border-gray-300 px-3.5 py-3 rounded-l text-sm font-semibold text-gray-500">+91</span>
                <input
                  type="text"
                  placeholder="9999999999"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full border p-3 rounded-r text-sm outline-none focus:border-lioris-gold bg-lioris-lightGrey"
                />
              </div>
            </div>
            
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Full Name (New Signups)</label>
              <input
                type="text"
                placeholder="Ex. John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full border p-3 rounded text-sm outline-none focus:border-lioris-gold bg-lioris-lightGrey"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Referral Code (Optional)</label>
              <input
                type="text"
                placeholder="Ex. 9999999999"
                value={refCode}
                onChange={(e) => setRefCode(e.target.value)}
                className="w-full border p-3 rounded text-sm outline-none focus:border-lioris-gold bg-lioris-lightGrey"
              />
            </div>

            <button
              onClick={handleSendOtp}
              disabled={isSending}
              className="w-full bg-lioris-black text-white min-h-12 font-bold uppercase tracking-wider text-xs flex items-center justify-center rounded hover:bg-opacity-95 transition mt-6"
            >
              {isSending ? "Requesting OTP..." : "Request Secure OTP"}
            </button>
          </>
        ) : (
          <div className="space-y-4">
            <div className="space-y-1 text-center">
              <p className="text-xs text-gray-500">Enter the 6-digit code sent to +91 {phone}</p>
            </div>
            <input
              type="text"
              placeholder="Enter 6-Digit OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full border p-3 rounded text-sm text-center font-bold tracking-widest bg-lioris-lightGrey"
            />
            <button
              onClick={handleVerifyOtp}
              className="w-full bg-lioris-gold text-lioris-black min-h-12 font-bold uppercase tracking-wider text-xs flex items-center justify-center rounded hover:bg-opacity-90 transition"
            >
              Verify OTP Code
            </button>
            <div className="text-center mt-2">
              <button
                onClick={handleSendOtp}
                disabled={cooldown > 0}
                className="text-xs text-gray-500 hover:text-lioris-gold disabled:opacity-50"
              >
                {cooldown > 0 ? `Resend OTP in ${cooldown}s` : "Didn't receive code? Resend OTP"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Admin Panel Component
// ----------------------------------------------------
function Admin({ products, setProducts, settings, setSettings }) {
  const [activeTab, setActiveTab] = useState("products");
  const [orders, setOrders] = useState([]);
  const [coupons, setCoupons] = useState([]);
  
  // Settings Form state
  const [storeName, setStoreName] = useState(settings.storeName);
  const [supportWhatsApp, setSupportWhatsApp] = useState(settings.supportWhatsApp);
  const [upiId, setUpiId] = useState(settings.upiId);
  const [deliveryCharge, setDeliveryCharge] = useState(settings.deliveryCharge);
  const [codAdvanceAmount, setCodAdvanceAmount] = useState(settings.codAdvanceAmount);
  const [otpMode, setOtpMode] = useState(settings.otpMode);

  // Manage Products forms
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [prodForm, setProdForm] = useState({
    name: "", category: "", price: "", mrp: "", stock: "", images: "", description: "", active: true
  });

  // Manage Coupons forms
  const [couponCode, setCouponCode] = useState("");
  const [couponValue, setCouponValue] = useState("");
  const [couponType, setCouponType] = useState("flat");

  useEffect(() => {
    // Fetch Admin Data
    const fetchAdminData = async () => {
      try {
        const orderSnap = await getDocs(collection(db, "orders"));
        setOrders(orderSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        
        const couponSnap = await getDocs(collection(db, "coupons"));
        setCoupons(couponSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error(err);
      }
    };
    fetchAdminData();
  }, []);

  const handleSaveSettings = async () => {
    try {
      const nextSettings = {
        storeName,
        supportWhatsApp,
        upiId,
        deliveryCharge: Number(deliveryCharge),
        codAdvanceAmount: Number(codAdvanceAmount),
        otpMode
      };
      
      await setDoc(doc(db, "settings", "store"), nextSettings, { merge: true });
      await setDoc(doc(db, "settings", "appConfig"), {
        otpMode,
        updatedAt: serverTimestamp()
      }, { merge: true });

      setSettings(prev => ({ ...prev, ...nextSettings }));
      showToastGlobal("Settings saved successfully!");
    } catch (e) {
      showToastGlobal("Failed to save settings.", "error");
    }
  };

  const handleSaveProduct = async () => {
    try {
      const pId = isEditing ? editingId : "PROD" + Math.floor(100000 + Math.random() * 900000);
      const prMap = {
        id: pId,
        ...prodForm,
        price: Number(prodForm.price),
        mrp: Number(prodForm.mrp),
        discount: ((Number(prodForm.mrp) - Number(prodForm.price)) / Number(prodForm.mrp)) * 100,
        stock: Number(prodForm.stock)
      };

      await setDoc(doc(db, "products", pId), prMap);
      
      if (isEditing) {
        setProducts(products.map(p => p.id === pId ? prMap : p));
      } else {
        setProducts([...products, prMap]);
      }
      
      setProdForm({ name: "", category: "", price: "", mrp: "", stock: "", images: "", description: "", active: true });
      setIsEditing(false);
      showToastGlobal("Product saved successfully!");
    } catch (e) {
      showToastGlobal("Failed to save product", "error");
    }
  };

  const handleDeleteProduct = async (pId) => {
    try {
      await updateDoc(doc(db, "products", pId), { active: false });
      setProducts(products.map(p => p.id === pId ? { ...p, active: false } : p));
      showToastGlobal("Product disabled successfully");
    } catch (e) {
      showToastGlobal("Failed to delete product.", "error");
    }
  };

  const handleAddCoupon = async () => {
    if (!couponCode || !couponValue) return;
    try {
      const code = couponCode.toUpperCase().trim();
      const cp = { code, value: Number(couponValue), type: couponType, active: true };
      await setDoc(doc(db, "coupons", code), cp);
      setCoupons([...coupons, cp]);
      setCouponCode("");
      setCouponValue("");
      showToastGlobal("Coupon added successfully!");
    } catch (e) {
      showToastGlobal("Failed to add coupon", "error");
    }
  };

  const handleUpdateOrderStatus = async (oId, nextStatus) => {
    try {
      await updateDoc(doc(db, "orders", oId), { status: nextStatus });
      setOrders(orders.map(o => o.orderId === oId ? { ...o, status: nextStatus } : o));
      showToastGlobal("Order status updated!");
    } catch (e) {
      showToastGlobal("Failed to update order", "error");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="border-b pb-4 flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-2xl font-serif font-bold tracking-wider uppercase">LIORIS Admin suite</h1>
        <div className="flex bg-gray-100 rounded-md p-1 border">
          {["products", "orders", "settings", "coupons"].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition ${activeTab === tab ? 'bg-white text-lioris-gold shadow' : 'text-gray-500 hover:text-gray-700'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Settings Tab */}
      {activeTab === "settings" && (
        <div className="bg-white border p-6 rounded-md shadow-sm space-y-6">
          <h2 className="text-lg font-serif font-bold tracking-wider uppercase">Global configurations</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Store Name</label>
              <input type="text" value={storeName} onChange={(e) => setStoreName(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Support WhatsApp</label>
              <input type="text" value={supportWhatsApp} onChange={(e) => setSupportWhatsApp(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Merchant UPI ID</label>
              <input type="text" value={upiId} onChange={(e) => setUpiId(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Standard Delivery Charge</label>
              <input type="number" value={deliveryCharge} onChange={(e) => setDeliveryCharge(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400">COD Advance Amount</label>
              <input type="number" value={codAdvanceAmount} onChange={(e) => setCodAdvanceAmount(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
            </div>
            
            {/* Dynamic Real vs Test OTP Mode controls */}
            <div className="col-span-2 border border-lioris-goldLight bg-lioris-goldLight/10 p-4 rounded-md space-y-3 mt-2">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-sm uppercase tracking-wider text-lioris-gold">
                    {otpMode === "fast2sms_quick" ? "FAST2SMS REAL OTP ACTIVE" : "TEST MODE (Free/Safe)"}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {otpMode === "fast2sms_quick" ? "Approx ₹5 may be charged per SMS." : "OTP is hardcoded to '123456' for developers and testing."}
                  </p>
                </div>
                <button
                  onClick={() => setOtpMode(otpMode === "test" ? "fast2sms_quick" : "test")}
                  className={`px-5 py-2 rounded text-xs font-bold uppercase tracking-wider transition ${otpMode === "fast2sms_quick" ? 'bg-lioris-gold text-lioris-black' : 'bg-gray-200 text-gray-700'}`}
                >
                  {otpMode === "fast2sms_quick" ? "Switch to Test Mode" : "Turn ON Real OTP"}
                </button>
              </div>
            </div>
          </div>
          <button onClick={handleSaveSettings} className="bg-lioris-black text-white px-6 py-2.5 rounded text-sm font-bold uppercase tracking-wider">
            Save Settings
          </button>
        </div>
      )}

      {/* Products Tab */}
      {activeTab === "products" && (
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1 bg-white border p-5 rounded-md shadow-sm h-fit space-y-4">
            <h2 className="text-base font-serif font-bold uppercase tracking-wider">{isEditing ? "Edit Product" : "Add New Product"}</h2>
            <div className="space-y-3 text-xs">
              <input type="text" placeholder="Product Name" value={prodForm.name} onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
              <input type="text" placeholder="Category (e.g. Clothing)" value={prodForm.category} onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
              <input type="number" placeholder="Offer Price (₹)" value={prodForm.price} onChange={(e) => setProdForm({ ...prodForm, price: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
              <input type="number" placeholder="MRP Price (₹)" value={prodForm.mrp} onChange={(e) => setProdForm({ ...prodForm, mrp: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
              <input type="number" placeholder="Stock Qty" value={prodForm.stock} onChange={(e) => setProdForm({ ...prodForm, stock: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
              <textarea placeholder="Image URLs (separated by comma)" rows="2" value={prodForm.images} onChange={(e) => setProdForm({ ...prodForm, images: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none"></textarea>
              <textarea placeholder="Description" rows="3" value={prodForm.description} onChange={(e) => setProdForm({ ...prodForm, description: e.target.value })} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none"></textarea>
              <button onClick={handleSaveProduct} className="w-full bg-lioris-black text-white py-2.5 rounded text-xs font-bold uppercase tracking-widest mt-2">
                Save Product
              </button>
              {isEditing && (
                <button onClick={() => { setIsEditing(false); setEditingId(null); setProdForm({ name: "", category: "", price: "", mrp: "", stock: "", images: "", description: "", active: true }); }} className="w-full border py-2 rounded text-xs">
                  Cancel Edit
                </button>
              )}
            </div>
          </div>
          
          <div className="md:col-span-2 bg-white border p-5 rounded-md shadow-sm h-fit">
            <h2 className="text-base font-serif font-bold uppercase tracking-wider mb-4">Inventory list</h2>
            <div className="divide-y max-h-[500px] overflow-y-auto pr-2">
              {products.map(p => (
                <div key={p.id} className="flex justify-between items-center py-3 text-sm">
                  <div className="flex gap-2 items-center">
                    <img src={(p.images || "").split(",")[0] || "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop"} alt="product" className="w-10 h-12 object-cover rounded border" />
                    <div>
                      <p className="font-bold text-gray-800 line-clamp-1">{p.name}</p>
                      <p className="text-xs text-gray-400">₹{p.price} / ₹{p.mrp}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => { setIsEditing(true); setEditingId(p.id); setProdForm(p); }}
                      className="px-2.5 py-1 bg-blue-50 text-blue-600 border border-blue-200 text-xs font-bold rounded hover:bg-blue-100 transition"
                    >
                      Edit
                    </button>
                    {p.active !== false && (
                      <button
                        onClick={() => handleDeleteProduct(p.id)}
                        className="px-2.5 py-1 bg-red-50 text-red-600 border border-red-200 text-xs font-bold rounded hover:bg-red-100 transition"
                      >
                        Delete
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === "orders" && (
        <div className="bg-white border p-6 rounded-md shadow-sm space-y-4">
          <h2 className="text-lg font-serif font-bold tracking-wider uppercase border-b pb-2">Active customer orders</h2>
          <div className="divide-y max-h-[600px] overflow-y-auto">
            {orders.map(o => (
              <div key={o.id} className="py-4 space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <div>
                    <p className="font-bold">{o.orderId} - {o.customerName}</p>
                    <p className="text-xs text-gray-400">Total: ₹{o.total} via {o.paymentMethod}</p>
                  </div>
                  <div className="flex gap-1.5">
                    {["Pending", "Confirmed", "Shipped", "Delivered"].map(st => (
                      <button
                        key={st}
                        onClick={() => handleUpdateOrderStatus(o.orderId, st)}
                        className={`px-2 py-1 text-xs rounded font-bold transition ${o.status === st ? 'bg-lioris-gold text-lioris-black' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'}`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Coupons Tab */}
      {activeTab === "coupons" && (
        <div className="grid md:grid-cols-3 gap-6 animate-fade-in">
          <div className="md:col-span-1 bg-white border p-5 rounded-md h-fit space-y-4">
            <h2 className="text-base font-serif font-bold uppercase tracking-wider">Add Promo Coupon</h2>
            <div className="space-y-3 text-xs">
              <input type="text" placeholder="COUPON CODE" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none uppercase" />
              <input type="number" placeholder="Discount Value" value={couponValue} onChange={(e) => setCouponValue(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none" />
              <select value={couponType} onChange={(e) => setCouponType(e.target.value)} className="w-full bg-lioris-lightGrey border p-3 rounded text-sm outline-none font-bold">
                <option value="flat">Flat Discount (₹)</option>
                <option value="percentage">Percentage Discount (%)</option>
              </select>
              <button onClick={handleAddCoupon} className="w-full bg-lioris-black text-white py-2.5 rounded text-xs font-bold uppercase tracking-widest mt-2">
                Add Coupon
              </button>
            </div>
          </div>

          <div className="md:col-span-2 bg-white border p-5 rounded-md shadow-sm h-fit">
            <h2 className="text-base font-serif font-bold uppercase tracking-wider mb-4">Active Promo Coupons</h2>
            <div className="divide-y text-sm">
              {coupons.map(cp => (
                <div key={cp.id} className="flex justify-between py-3">
                  <div>
                    <p className="font-bold text-gray-800">{cp.code}</p>
                    <p className="text-xs text-gray-400">{cp.type === 'percentage' ? `${cp.value}% Off` : `₹${cp.value} Flat Off`}</p>
                  </div>
                  <span className="text-xs bg-green-100 text-green-700 font-bold px-2 py-0.5 rounded-full h-fit mt-1">Active</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// Footer Component
// ----------------------------------------------------
function Footer() {
  return (
    <footer className="bg-lioris-black text-gray-400 py-8 border-t border-gray-900 mt-12 text-xs">
      <div className="container mx-auto max-w-6xl px-4 grid sm:grid-cols-3 gap-6">
        <div className="space-y-3">
          <span className="text-lg font-serif font-bold tracking-widest text-lioris-gold uppercase">LIORIS</span>
          <p className="leading-relaxed">Premium online lifestyle brand curated with timeless design, exquisite material craft, and dynamic checkout experiences.</p>
        </div>
        <div className="space-y-2">
          <p className="font-bold text-white uppercase tracking-wider">Quick Information</p>
          <ul className="space-y-1.5">
            <li><Link to="/" className="hover:text-lioris-gold transition">Shop Catalogue</Link></li>
            <li><Link to="/profile" className="hover:text-lioris-gold transition">Join Referrals</Link></li>
            <li><Link to="/wallet" className="hover:text-lioris-gold transition">LIORIS Wallet</Link></li>
          </ul>
        </div>
        <div className="space-y-2">
          <p className="font-bold text-white uppercase tracking-wider">Contact & Support</p>
          <p>WhatsApp Hotline available daily.</p>
          <p className="font-bold text-lioris-gold">+91 72520 83788</p>
        </div>
      </div>
      <div className="text-center mt-8 pt-4 border-t border-gray-900 text-[10px] text-gray-600 uppercase font-semibold tracking-wider">
        © {new Date().getFullYear()} LIORIS Global Inc. All rights reserved. Registered PWA.
      </div>
    </footer>
  );
}
